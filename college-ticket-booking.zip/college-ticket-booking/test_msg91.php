<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/Logger.php';

echo "<h1>MSG91 Integration Test</h1>";

// Test 1: Check if constants are defined
echo "<h2>1. Configuration Check:</h2>";
echo "MSG91_API_KEY: " . (defined('MSG91_API_KEY') ? "✓ Defined" : "✗ NOT DEFINED") . "<br>";
echo "MSG91_SENDER_ID: " . (defined('MSG91_SENDER_ID') ? "✓ Defined" : "✗ NOT DEFINED") . "<br>";
echo "MSG91_API_URL: " . (defined('MSG91_API_URL') ? "✓ Defined" : "✗ NOT DEFINED") . "<br>";

if (defined('MSG91_API_KEY')) {
    echo "API Key: " . substr(MSG91_API_KEY, 0, 10) . "..." . substr(MSG91_API_KEY, -5) . "<br>";
    echo "Sender ID: " . MSG91_SENDER_ID . "<br>";
    echo "API URL: " . MSG91_API_URL . "<br>";
}

// Test 2: Test curl connectivity
echo "<h2>2. Network & CURL Check:</h2>";
if (!extension_loaded('curl')) {
    echo "✗ CURL extension NOT loaded<br>";
} else {
    echo "✓ CURL extension loaded<br>";
    
    // Try to reach MSG91
    $testPhone = "919876543210"; // Test number format
    $testMessage = "Test OTP from EventPass";
    
    $params = [
        'authkey'  => MSG91_API_KEY,
        'mobiles'  => $testPhone,
        'message'  => $testMessage,
        'sender'   => MSG91_SENDER_ID,
        'route'    => '4',
        'response' => 'json'
    ];

    $queryString = http_build_query($params);
    $url = MSG91_API_URL . '?' . $queryString;

    echo "<br><strong>Test Request:</strong><br>";
    echo "URL: " . substr($url, 0, 100) . "...<br>";

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => false, // Disable for testing
        CURLOPT_USERAGENT      => 'EventPass-Test/1.0'
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    echo "<strong>Response:</strong><br>";
    echo "HTTP Code: " . $httpCode . "<br>";
    
    if ($curlError) {
        echo "✗ CURL Error: " . $curlError . "<br>";
    } else {
        echo "✓ No CURL error<br>";
    }
    
    echo "Response Body: <pre>" . htmlspecialchars($response) . "</pre>";
    
    if (!empty($response)) {
        $decoded = json_decode($response, true);
        echo "Decoded Response: <pre>" . print_r($decoded, true) . "</pre>";
        
        if (is_array($decoded)) {
            if (isset($decoded['type']) && $decoded['type'] === 'success') {
                echo "✓ SMS would be sent successfully<br>";
            } else if (isset($decoded['message'])) {
                echo "⚠ MSG91 Response: " . $decoded['message'] . "<br>";
            }
        }
    }
}

// Test 3: Check Logger
echo "<h2>3. Logger Check:</h2>";
if (class_exists('Logger')) {
    echo "✓ Logger class found<br>";
    Logger::info('TEST', 'This is a test log entry', ['test' => true]);
    echo "✓ Test log entry written<br>";
} else {
    echo "✗ Logger class NOT found<br>";
}

echo "<h2>✅ Test Complete</h2>";
echo "<p><strong>Next Steps:</strong></p>";
echo "<ol>";
echo "<li>If HTTP code is 200 and type='success': SMS sending works ✓</li>";
echo "<li>If you see an error: Check Auth Key and Sender ID in MSG91 dashboard</li>";
echo "<li>If CURL error: Check internet connection or firewall</li>";
echo "</ol>";
?>
