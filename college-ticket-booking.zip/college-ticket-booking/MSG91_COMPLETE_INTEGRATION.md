# ✅ MSG91 Complete Integration Guide

## Overview
Your system now has **complete MSG91 integration** with both:
- ✅ **Frontend Widget** - User enters OTP via MSG91 widget
- ✅ **Backend Verification** - Server verifies the widget token

---

## 🔑 Step 1: Get Your MSG91 Credentials

### Find Your Auth Key (API Key):
1. Log in to **https://www.msg91.com**
2. Go to **Settings → API Keys** or **Dashboard → API Info**
3. Copy your **Auth Key** (long alphanumeric string)
4. This is different from the widget token you already have

### You Should Have Two Things:
```
✓ Widget Token: 513951TEA34qlnAx069f8f158P1  (already in your code)
✓ Auth Key: abc123def456xyz789...            (need to find & add)
```

---

## 🔧 Step 2: Add Auth Key to Config

Edit **`config/config.php`** and add:

```php
// MSG91 SMS Configuration
define('MSG91_API_KEY', 'YOUR_AUTH_KEY_HERE');      // ← Paste your Auth Key
define('MSG91_SENDER_ID', 'EVENTAPP');
define('MSG91_ROUTE', '4');
define('MSG91_API_URL', 'https://api.msg91.com/api/sendhttp.php');
```

Replace `YOUR_AUTH_KEY_HERE` with your actual Auth Key from MSG91.

---

## 🔄 How It Works Now

### Complete OTP Flow:

```
┌─ USER ─────────────────────────────────────────────────────────┐
│                                                                 │
│  Step 1: User enters phone number                             │
│          ↓                                                      │
│  Step 2: Frontend calls send_otp.php                          │
│          ↓                                                      │
│  Step 3: Backend generates OTP                                │
│          ├─→ Sends SMS via MSG91 (using Auth Key)             │
│          └─→ Falls back to Email if SMS fails                 │
│          ↓                                                      │
│  Step 4: User receives OTP (SMS or Email)                     │
│          ↓                                                      │
│  Step 5: User enters OTP in MSG91 Widget                      │
│          ↓                                                      │
│  Step 6: Widget verifies with MSG91, returns JWT token        │
│          ↓                                                      │
│  Step 7: Frontend sends JWT token to verify_otp.php           │
│          ↓                                                      │
│  Step 8: Backend verifies JWT with MSG91 API                  │
│          ↓                                                      │
│  Step 9: Backend reserves tickets & proceeds to payment       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Two Integration Paths

### Path A: Widget-Based (Recommended)
```
1. User gets OTP via SMS
2. User enters in MSG91 Widget
3. Widget returns JWT token
4. Backend verifies JWT with MSG91
5. ✓ Most secure - verified by MSG91 directly
```

### Path B: Manual Entry (Fallback)
```
1. User gets OTP via SMS
2. User enters 4 digits manually
3. Backend verifies against stored hash
4. ✓ Works if widget fails
```

---

## 🧪 Testing

### In Development Mode:
```php
// In config/config.php, keep:
define('APP_ENV', 'development');
```

- OTP will be sent via SMS
- Browser console shows: `Development OTP: 1234`
- Widget token verification will work

### In Production Mode:
```php
// In config/config.php, change to:
define('APP_ENV', 'production');
```

- Only real SMS sent (no console display)
- Only real widget verification accepted
- Email fallback still active

---

## 📋 What Was Updated

### Frontend Changes:
- **`assets/js/app.js`**: Updated to send widget JWT token to backend

### Backend Changes:
- **`config/config.php`**: Added MSG91 Auth Key config (replace placeholder)
- **`includes/OTPService.php`**: 
  - Added `verifyMSG91WidgetToken()` method for backend JWT verification
  - Kept SMS sending via MSG91 API
- **`api/verify_otp.php`**: 
  - Now calls `verifyMSG91WidgetToken()` when widget token is present

---

## 🔍 Troubleshooting

### Users not getting SMS?
- ✅ Check Auth Key is correct in config.php
- ✅ Verify sender ID is approved in MSG91 dashboard
- ✅ Check logs: `logs/error.log`

### Widget not showing access token?
- ✅ Check browser console for errors
- ✅ Verify widget credentials in `index.php` are correct
- ✅ Check network tab in DevTools for MSG91 API calls

### "OTP verification failed" message?
- ✅ User might not have used widget - ask to re-enter manually
- ✅ Check if Auth Key is correct
- ✅ Verify JWT token not expired (typically 10 minutes)

### Manual OTP entry not working?
- ✅ Ensure SMS was received first
- ✅ Verify phone number formatting is correct
- ✅ Check if OTP has expired (default 10 minutes)

---

## 🔐 Security Checklist

- ✅ Never share your Auth Key
- ✅ In production, use environment variables instead of hardcoding
- ✅ OTP expires after 10 minutes (configurable)
- ✅ Rate limiting: max 5 OTP attempts per 10 minutes
- ✅ All OTP activities logged for audit trail

---

## 📞 Support

| Issue | Resource |
|-------|----------|
| MSG91 API Help | https://www.msg91.com/api |
| Widget Setup | MSG91 Dashboard → Settings → Widgets |
| Technical Support | MSG91 Support Portal |

---

## ✨ Complete Integration Checklist

- [ ] Got Auth Key from MSG91
- [ ] Added Auth Key to `config/config.php`
- [ ] Verified sender ID is approved in MSG91
- [ ] Tested in development mode
- [ ] SMS delivery confirmed
- [ ] Widget token verification working
- [ ] Switched to production mode
- [ ] Live testing with real users
