<?php
/**
 * Debug My Bookings - Check why bookings aren't showing
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Debug My Bookings</title>
    <style>
        body { font-family: system-ui; max-width: 1000px; margin: 40px auto; padding: 20px; background: #f5f5f5; }
        .card { background: white; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2 { color: #003087; margin-top: 0; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f5f5f5; font-weight: 600; }
        .code { font-family: monospace; background: #f5f5f5; padding: 2px 6px; border-radius: 4px; }
        .success { color: #2e7d32; font-weight: 600; }
        .error { color: #c62828; font-weight: 600; }
        .warning { color: #e65100; font-weight: 600; }
    </style>
</head>
<body>

<div class="card">
    <h2>🔍 My Bookings Debug Information</h2>
    
    <?php
    // Check if user is logged in
    if (empty($_SESSION['user_id'])) {
        echo '<p class="error">❌ User is NOT logged in</p>';
        echo '<p><a href="login.php">Go to Login</a></p>';
        exit;
    }
    
    echo '<p class="success">✅ User is logged in</p>';
    
    // Show session data
    echo '<h3>Session Data:</h3>';
    echo '<table>';
    echo '<tr><th>Key</th><th>Value</th></tr>';
    echo '<tr><td>user_id</td><td><span class="code">' . htmlspecialchars($_SESSION['user_id'] ?? 'NOT SET') . '</span></td></tr>';
    echo '<tr><td>user_email</td><td><span class="code">' . htmlspecialchars($_SESSION['user_email'] ?? 'NOT SET') . '</span></td></tr>';
    echo '<tr><td>user_name</td><td><span class="code">' . htmlspecialchars($_SESSION['user_name'] ?? 'NOT SET') . '</span></td></tr>';
    echo '</table>';
    
    $userEmail = $_SESSION['user_email'] ?? '';
    
    if (empty($userEmail)) {
        echo '<p class="error">❌ user_email is empty in session!</p>';
        exit;
    }
    
    // Check database
    $conn = getDBConnection();
    
    // Check all bookings in database
    echo '<h3>All Bookings in Database:</h3>';
    $result = $conn->query("SELECT booking_id, user_name, user_email, event_id, total_amount, status, confirmed_at FROM confirmed_bookings ORDER BY confirmed_at DESC LIMIT 20");
    
    if ($result->num_rows > 0) {
        echo '<table>';
        echo '<tr><th>Booking ID</th><th>Name</th><th>Email</th><th>Event ID</th><th>Amount</th><th>Status</th><th>Date</th></tr>';
        
        $matchFound = false;
        while ($row = $result->fetch_assoc()) {
            $isMatch = (strtolower($row['user_email']) === strtolower($userEmail));
            if ($isMatch) $matchFound = true;
            
            $rowClass = $isMatch ? 'style="background:#e8f5e9"' : '';
            echo '<tr ' . $rowClass . '>';
            echo '<td><span class="code">' . htmlspecialchars($row['booking_id']) . '</span></td>';
            echo '<td>' . htmlspecialchars($row['user_name']) . '</td>';
            echo '<td><span class="code">' . htmlspecialchars($row['user_email']) . '</span>';
            if ($isMatch) echo ' <span class="success">← MATCH!</span>';
            echo '</td>';
            echo '<td>' . $row['event_id'] . '</td>';
            echo '<td>₹' . number_format($row['total_amount'], 2) . '</td>';
            echo '<td>' . $row['status'] . '</td>';
            echo '<td>' . date('Y-m-d H:i', strtotime($row['confirmed_at'])) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
        
        if ($matchFound) {
            echo '<p class="success">✅ Found matching bookings for your email!</p>';
        } else {
            echo '<p class="warning">⚠️ No bookings found matching your email: <span class="code">' . htmlspecialchars($userEmail) . '</span></p>';
            echo '<p>This means either:</p>';
            echo '<ul>';
            echo '<li>You booked with a different email address</li>';
            echo '<li>Your bookings haven\'t been confirmed yet</li>';
            echo '<li>There\'s a case-sensitivity issue with the email</li>';
            echo '</ul>';
        }
    } else {
        echo '<p class="error">❌ No bookings found in database at all!</p>';
    }
    
    // Check the exact query used by my-bookings.php
    echo '<h3>Query Test (Same as my-bookings.php):</h3>';
    $stmt = $conn->prepare(
        "SELECT cb.*, e.name AS event_name, e.venue, e.event_date, e.department
         FROM confirmed_bookings cb
         JOIN events e ON cb.event_id = e.id
         WHERE cb.user_email = ?
         ORDER BY cb.confirmed_at DESC"
    );
    $stmt->bind_param('s', $userEmail);
    $stmt->execute();
    $result = $stmt->get_result();
    $bookings = [];
    while ($row = $result->fetch_assoc()) $bookings[] = $row;
    $stmt->close();
    
    echo '<p>Query: <span class="code">SELECT ... WHERE cb.user_email = \'' . htmlspecialchars($userEmail) . '\'</span></p>';
    echo '<p>Results: <strong>' . count($bookings) . '</strong> booking(s) found</p>';
    
    if (count($bookings) > 0) {
        echo '<p class="success">✅ Query returned bookings! They should show on my-bookings.php</p>';
        echo '<table>';
        echo '<tr><th>Booking ID</th><th>Event</th><th>Tickets</th><th>Amount</th></tr>';
        foreach ($bookings as $b) {
            echo '<tr>';
            echo '<td><span class="code">' . htmlspecialchars($b['booking_id']) . '</span></td>';
            echo '<td>' . htmlspecialchars($b['event_name']) . '</td>';
            echo '<td>' . $b['ticket_count'] . '</td>';
            echo '<td>₹' . number_format($b['total_amount'], 2) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo '<p class="error">❌ Query returned 0 results</p>';
        
        // Suggest solutions
        echo '<h3>Possible Solutions:</h3>';
        echo '<ol>';
        echo '<li><strong>Check if you\'re logged in with the correct email</strong><br>';
        echo 'Your session email: <span class="code">' . htmlspecialchars($userEmail) . '</span><br>';
        echo 'Make sure this matches the email you used when booking.</li>';
        
        echo '<li><strong>Try logging out and logging back in</strong><br>';
        echo '<a href="logout.php">Logout</a> then login again with the email you used for booking.</li>';
        
        echo '<li><strong>Check if bookings exist for other emails</strong><br>';
        echo 'Look at the "All Bookings" table above to see what emails have bookings.</li>';
        
        echo '<li><strong>Contact support</strong><br>';
        echo 'If you made a booking but can\'t see it, contact support with your booking ID.</li>';
        echo '</ol>';
    }
    
    // Check users table
    echo '<h3>User Account Check:</h3>';
    $stmt = $conn->prepare("SELECT id, name, email, created_at FROM users WHERE email = ?");
    $stmt->bind_param('s', $userEmail);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($user) {
        echo '<p class="success">✅ User account found in database</p>';
        echo '<table>';
        echo '<tr><th>ID</th><td>' . $user['id'] . '</td></tr>';
        echo '<tr><th>Name</th><td>' . htmlspecialchars($user['name']) . '</td></tr>';
        echo '<tr><th>Email</th><td><span class="code">' . htmlspecialchars($user['email']) . '</span></td></tr>';
        echo '<tr><th>Created</th><td>' . date('Y-m-d H:i', strtotime($user['created_at'])) . '</td></tr>';
        echo '</table>';
    } else {
        echo '<p class="warning">⚠️ No user account found for email: <span class="code">' . htmlspecialchars($userEmail) . '</span></p>';
    }
    ?>
</div>

<div style="text-align: center; margin-top: 20px;">
    <a href="my-bookings.php" style="color: #003087; text-decoration: none; font-weight: 600;">← Back to My Bookings</a> |
    <a href="index.php" style="color: #003087; text-decoration: none; font-weight: 600;">Home</a> |
    <a href="logout.php" style="color: #c62828; text-decoration: none; font-weight: 600;">Logout</a>
</div>

</body>
</html>
