<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/Logger.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name      = trim($_POST['name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $phone     = trim($_POST['phone'] ?? '');
    $bookingId = trim($_POST['booking_id'] ?? '');
    $subject   = trim($_POST['subject'] ?? '');
    $category  = trim($_POST['category'] ?? 'other');
    $message   = trim($_POST['message'] ?? '');

    $validCats = ['cancellation','payment','booking','technical','other','password'];

    if (strlen($name) < 2)                          $error = 'Please enter your name.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'Invalid email address.';
    elseif (strlen($subject) < 5)                   $error = 'Subject must be at least 5 characters.';
    elseif (strlen($message) < 20)                  $error = 'Message must be at least 20 characters.';
    elseif (!in_array($category, $validCats))        $error = 'Invalid category.';
    else {
        try {
            $conn = getDBConnection();
            $ticketId = 'ST' . date('Ymd') . strtoupper(bin2hex(random_bytes(4)));

            // Handle empty booking_id - set to NULL instead of empty string
            $bookingIdValue = !empty($bookingId) ? $bookingId : null;

            $stmt = $conn->prepare(
                "INSERT INTO support_tickets
                 (ticket_id, user_name, user_email, user_phone, booking_id, subject, category, message, status, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', NOW())"
            );
            $stmt->bind_param('ssssssss',
                $ticketId, $name, $email, $phone, $bookingIdValue, $subject, $category, $message
            );
            
            if ($stmt->execute()) {
                $stmt->close();
                Logger::info('Support', "Ticket created: $ticketId by $email");
                $success = $ticketId;
            } else {
                $stmt->close();
                Logger::error('Support', 'Failed to insert ticket: ' . $conn->error);
                $error = 'Failed to submit ticket. Database error: ' . $conn->error;
            }
        } catch (Exception $e) {
            Logger::error('Support', 'Exception creating ticket: ' . $e->getMessage());
            $error = 'Failed to submit ticket. Please try again. Error: ' . $e->getMessage();
        }
    }
}

// Pre-fill from session
$prefillName  = $_SESSION['user_name']  ?? '';
$prefillEmail = $_SESSION['user_email'] ?? '';
$prefillPhone = $_SESSION['user_phone'] ?? '';
$prefillBooking = preg_replace('/[^A-Z0-9]/', '', strtoupper($_GET['booking_id'] ?? ''));
$prefillCat   = $_GET['category'] ?? '';

session_write_close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Support – VelTech EventPass</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body { background:#f4f6fb; }
    .page-wrap { max-width:1000px; margin:30px auto; padding:0 16px 40px; }
    .page-title { font-size:24px; font-weight:800; color:#003087; margin-bottom:6px; }
    .page-sub   { font-size:14px; color:#666; margin-bottom:28px; }
    .support-grid { display:grid; grid-template-columns:1fr 340px; gap:24px; }
    .support-card { background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 4px 20px rgba(0,48,135,0.10); }
    .support-header { background:linear-gradient(135deg,#003087,#0055b3); color:#fff; padding:22px 24px; }
    .support-header h2 { font-size:18px; font-weight:700; margin-bottom:4px; }
    .support-header p  { font-size:12px; opacity:.85; }
    .support-body { padding:24px; }
    .faq-item { border-bottom:1px solid #eee; padding:14px 0; cursor:pointer; }
    .faq-item:last-child { border-bottom:none; }
    .faq-q { font-size:14px; font-weight:600; color:#003087; display:flex; justify-content:space-between; align-items:center; }
    .faq-a { font-size:13px; color:#555; margin-top:8px; line-height:1.7; display:none; }
    .faq-item.open .faq-a { display:block; }
    .faq-item.open .faq-arrow { transform:rotate(180deg); }
    .faq-arrow { transition:transform .2s; font-size:12px; }
    .contact-box { background:#fff; border-radius:14px; padding:20px; box-shadow:0 4px 20px rgba(0,48,135,0.10); margin-bottom:20px; }
    .contact-box h3 { font-size:15px; font-weight:700; color:#003087; margin-bottom:14px; }
    .contact-item { display:flex; align-items:flex-start; gap:12px; margin-bottom:14px; font-size:13px; }
    .contact-item .icon { font-size:20px; flex-shrink:0; }
    .contact-item .info .label { font-weight:600; color:#333; }
    .contact-item .info .val   { color:#666; margin-top:2px; }
    .quick-links { background:#fff; border-radius:14px; padding:20px; box-shadow:0 4px 20px rgba(0,48,135,0.10); }
    .quick-links h3 { font-size:15px; font-weight:700; color:#003087; margin-bottom:14px; }
    .quick-link { display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:8px; text-decoration:none; color:#333; font-size:13px; font-weight:500; transition:background .2s; margin-bottom:6px; border:1px solid #eee; }
    .quick-link:hover { background:#e6edf8; color:#003087; }
    .success-box { text-align:center; padding:30px 20px; }
    .ticket-id { font-size:20px; font-weight:800; color:#003087; letter-spacing:2px; background:#e6edf8; padding:10px 20px; border-radius:8px; display:inline-block; margin:12px 0; }
    @media(max-width:700px){ .support-grid { grid-template-columns:1fr; } }
  </style>
</head>
<body>
<?php require_once 'includes/navbar.php'; ?>

<div class="page-wrap">
  <h1 class="page-title">💬 Support Center</h1>
  <p class="page-sub">We're here to help. Submit a ticket or browse FAQs below.</p>

  <div class="support-grid">

    <!-- ── LEFT: Ticket Form ── -->
    <div>
      <div class="support-card">
        <div class="support-header">
          <h2>📩 Submit a Support Ticket</h2>
          <p>We typically respond within 24 hours on working days</p>
        </div>
        <div class="support-body">

          <?php if ($success): ?>
          <div class="success-box">
            <div style="font-size:52px;margin-bottom:12px">✅</div>
            <h2 style="color:#003087;font-size:20px;margin-bottom:8px">Ticket Submitted!</h2>
            <p style="color:#666;margin-bottom:8px">Your support ticket has been created.</p>
            <div class="ticket-id"><?= htmlspecialchars($success) ?></div>
            <p style="font-size:13px;color:#888;margin-top:10px">
              Save this Ticket ID. Our team will respond to <strong><?= htmlspecialchars($_POST['email']) ?></strong> within 24 hours.
            </p>
            <div style="display:flex;gap:12px;justify-content:center;margin-top:20px;flex-wrap:wrap">
              <a href="track-ticket.php?id=<?= urlencode($success) ?>" class="btn btn-primary" style="text-decoration:none">
                🔍 Track Ticket
              </a>
              <a href="index.php" class="btn btn-outline" style="text-decoration:none">Back to Events</a>
              <a href="support.php" class="btn btn-outline" style="text-decoration:none">New Ticket</a>
            </div>
          </div>

          <?php else: ?>

          <?php if ($error): ?>
          <div class="alert alert-danger" role="alert">⚠ <?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <form method="POST" novalidate>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
              <div class="form-group">
                <label class="form-label" for="name">Full Name *</label>
                <input type="text" id="name" name="name" class="form-control"
                  placeholder="Your name" required
                  value="<?= htmlspecialchars($_POST['name'] ?? $prefillName) ?>">
              </div>
              <div class="form-group">
                <label class="form-label" for="email">Email *</label>
                <input type="email" id="email" name="email" class="form-control"
                  placeholder="your@email.com" required
                  value="<?= htmlspecialchars($_POST['email'] ?? $prefillEmail) ?>">
              </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
              <div class="form-group">
                <label class="form-label" for="phone">Phone</label>
                <input type="tel" id="phone" name="phone" class="form-control"
                  placeholder="+91 9876543210"
                  value="<?= htmlspecialchars($_POST['phone'] ?? $prefillPhone) ?>">
              </div>
              <div class="form-group">
                <label class="form-label" for="booking_id">Booking ID (if applicable)</label>
                <input type="text" id="booking_id" name="booking_id" class="form-control"
                  placeholder="e.g. CB20260615XXXX"
                  style="text-transform:uppercase;font-family:monospace"
                  value="<?= htmlspecialchars($_POST['booking_id'] ?? $prefillBooking) ?>">
              </div>
            </div>

            <div class="form-group">
              <label class="form-label" for="category">Category *</label>
              <select id="category" name="category" class="form-control" required>
                <option value="cancellation" <?= ($prefillCat==='cancellation'||($_POST['category']??'')==='cancellation')?'selected':'' ?>>🔴 Ticket Cancellation / Refund</option>
                <option value="payment"      <?= ($prefillCat==='payment'||($_POST['category']??'')==='payment')?'selected':'' ?>>💳 Payment Issue</option>
                <option value="booking"      <?= ($prefillCat==='booking'||($_POST['category']??'')==='booking')?'selected':'' ?>>🎟 Booking Problem</option>
                <option value="technical"    <?= ($prefillCat==='technical'||($_POST['category']??'')==='technical')?'selected':'' ?>>⚙️ Technical Issue</option>
                <option value="password"     <?= ($prefillCat==='password'||($_POST['category']??'')==='password')?'selected':'' ?>>🔑 Password / Account</option>
                <option value="other"        <?= ($prefillCat==='other'||($_POST['category']??'')==='other')?'selected':'' ?>>💬 Other</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label" for="subject">Subject *</label>
              <input type="text" id="subject" name="subject" class="form-control"
                placeholder="Brief description of your issue" required
                value="<?= htmlspecialchars($_POST['subject'] ?? '') ?>">
            </div>

            <div class="form-group">
              <label class="form-label" for="message">Message *</label>
              <textarea id="message" name="message" class="form-control" rows="5"
                placeholder="Describe your issue in detail. Include booking ID, payment ID, or any error messages you saw."
                required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary btn-full" style="font-size:15px;padding:13px">
              📩 Submit Ticket
            </button>
          </form>
          <?php endif; ?>
        </div>
      </div>

      <!-- ── FAQ ── -->
      <div class="support-card" style="margin-top:20px">
        <div class="support-header" style="background:linear-gradient(135deg,#1a237e,#283593)">
          <h2>❓ Frequently Asked Questions</h2>
          <p>Quick answers to common questions</p>
        </div>
        <div class="support-body">
          <?php
          $faqs = [
            ['How do I cancel my ticket?',
             'Go to <strong>My Bookings</strong> → click <strong>Cancel Ticket</strong> next to your booking. Cancellations are accepted up to 24 hours before the event. Alternatively, use the Cancel Ticket page and enter your Booking ID and email.'],
            ['When will I get my refund?',
             'Refunds are processed within <strong>5–7 business days</strong> to your original payment method (UPI, card, net banking). You\'ll receive an email confirmation once processed.'],
            ['What is the refund amount?',
             '100% refund if cancelled 7+ days before event. 50% refund if cancelled 2–6 days before. No refund within 24 hours of the event.'],
            ['I paid but didn\'t receive a confirmation email.',
             'Check your spam/junk folder. If not found, visit <strong>My Bookings</strong> to see your booking status. You can also contact support with your Payment ID from Razorpay.'],
            ['Can I transfer my ticket to someone else?',
             'Ticket transfers are not supported currently. The ticket is linked to the registered name and email. Contact support for special cases.'],
            ['I entered the wrong email during booking.',
             'Contact support immediately with your Booking ID and Payment ID. We can verify and update your email within 24 hours.'],
            ['The payment was deducted but booking shows failed.',
             'This can happen due to network issues. Wait 10 minutes — the system auto-verifies via webhook. If still not resolved, contact support with your Payment ID from your bank statement.'],
            ['How do I get my receipt?',
             'Go to <strong>My Bookings</strong> and click <strong>Receipt</strong> next to your booking. Receipts are also emailed to your registered email.'],
          ];
          foreach ($faqs as $i => $faq): ?>
          <div class="faq-item" onclick="toggleFaq(this)">
            <div class="faq-q">
              <span><?= $faq[0] ?></span>
              <span class="faq-arrow">▼</span>
            </div>
            <div class="faq-a"><?= $faq[1] ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- ── RIGHT: Contact + Quick Links ── -->
    <div>
      <div class="contact-box">
        <h3>📞 Contact Us</h3>
        <div class="contact-item">
          <span class="icon">📧</span>
          <div class="info">
            <div class="label">Email Support</div>
            <div class="val"><a href="mailto:support@veltech.edu.in" style="color:#003087">support@veltech.edu.in</a></div>
          </div>
        </div>
        <div class="contact-item">
          <span class="icon">📞</span>
          <div class="info">
            <div class="label">Phone</div>
            <div class="val">+91 94455 68802</div>
            <div class="val" style="font-size:11px;color:#aaa">Mon–Sat, 9 AM – 5 PM</div>
          </div>
        </div>
        <div class="contact-item">
          <span class="icon">📍</span>
          <div class="info">
            <div class="label">Address</div>
            <div class="val">Vel Tech University, Avadi, Chennai – 600 062, Tamil Nadu</div>
          </div>
        </div>
        <div class="contact-item">
          <span class="icon">⏱</span>
          <div class="info">
            <div class="label">Response Time</div>
            <div class="val">Within 24 hours (working days)</div>
          </div>
        </div>
      </div>

      <div class="quick-links">
        <h3>🔗 Quick Links</h3>
        <a href="track-ticket.php" class="quick-link">🔍 Track a Ticket</a>
        <a href="cancel-ticket.php" class="quick-link">❌ Cancel a Ticket</a>
        <a href="my-bookings.php"   class="quick-link">🎟 My Bookings</a>
        <a href="index.php"         class="quick-link">🎉 Browse Events</a>
        <a href="login.php"         class="quick-link">🔑 Sign In / Account</a>
        <a href="register.php"      class="quick-link">✨ Create Account</a>
      </div>

      <div style="background:#e6edf8;border-radius:12px;padding:16px;margin-top:16px;font-size:13px;color:#003087">
        <strong>🎓 Vel Tech EventPass</strong><br>
        <span style="font-size:11px;color:#555">
          Owned &amp; Operated by<br>
          Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology
        </span>
      </div>
    </div>

  </div><!-- /support-grid -->
</div>

<?php require_once 'includes/footer.php'; ?>

<script>
function toggleFaq(el) {
  el.classList.toggle('open');
}
</script>
</body>
</html>
