/**
 * Firebase Authentication Integration for VelTech EventPass
 * Provides phone number verification using Firebase Authentication
 */

const FirebaseAuth = (() => {
  let initialized = false;
  let recaptchaVerifier = null;
  let confirmationResult = null;

  /**
   * Initialize Firebase (uses web SDK from CDN)
   */
  const init = async (firebaseConfig) => {
    if (initialized) return true;

    // Check if Firebase is loaded from CDN
    if (typeof firebase === 'undefined') {
      console.error('Firebase SDK not loaded. Include it in your HTML.');
      return false;
    }

    try {
      // Firebase is already initialized if it's included in HTML
      // Just verify the connection
      initialized = true;
      console.info('Firebase Auth ready');
      return true;
    } catch (err) {
      console.error('Firebase init error:', err);
      return false;
    }
  };

  /**
   * Send OTP via Firebase to phone number
   */
  const sendOtpToPhone = async (phoneNumber) => {
    try {
      if (!initialized) {
        throw new Error('Firebase not initialized');
      }

      if (typeof firebase === 'undefined' || !firebase.auth) {
        throw new Error('Firebase Auth SDK not available');
      }

      const auth = firebase.auth();
      
      // Format phone number (ensure +91 prefix for India)
      let phone = phoneNumber.replace(/[^\d+]/g, '');
      if (!phone.startsWith('+')) {
        if (phone.length === 10) {
          phone = '+91' + phone;
        } else if (phone.length === 12 && phone.startsWith('91')) {
          phone = '+' + phone;
        }
      }

      console.info('Sending OTP to:', phone);

      // Sign in with phone number (Firebase handles SMS delivery)
      confirmationResult = await auth.signInWithPhoneNumber(phone, recaptchaVerifier);
      
      console.info('OTP sent via Firebase');
      return {
        success: true,
        message: 'OTP sent to your phone via Firebase.',
        confirmationResult: confirmationResult
      };
    } catch (err) {
      console.error('Firebase OTP send error:', err);
      return {
        success: false,
        message: `Failed to send OTP: ${err.message}`,
        error: err
      };
    }
  };

  /**
   * Verify OTP entered by user
   */
  const verifyOtp = async (otpCode) => {
    try {
      if (!confirmationResult) {
        throw new Error('No pending OTP. Request OTP first.');
      }

      const credential = await confirmationResult.confirm(otpCode);
      const idToken = await credential.user.getIdToken();

      console.info('OTP verified via Firebase, got ID token');
      return {
        success: true,
        message: 'OTP verified successfully.',
        idToken: idToken,
        uid: credential.user.uid,
        phoneNumber: credential.user.phoneNumber
      };
    } catch (err) {
      console.error('Firebase OTP verification error:', err);
      return {
        success: false,
        message: `OTP verification failed: ${err.message}`,
        error: err
      };
    }
  };

  /**
   * Setup reCAPTCHA for phone verification
   */
  const setupRecaptcha = (containerId) => {
    try {
      if (typeof firebase === 'undefined' || !firebase.auth) {
        console.error('Firebase not loaded');
        return false;
      }

      recaptchaVerifier = new firebase.auth.RecaptchaVerifier(containerId, {
        size: 'invisible',
        callback: (response) => {
          console.info('reCAPTCHA verified');
        },
        'expired-callback': () => {
          console.warn('reCAPTCHA expired');
          recaptchaVerifier.render().then(widgetId => {
            window.grecaptcha.reset(widgetId);
          });
        }
      });

      console.info('reCAPTCHA setup complete');
      return true;
    } catch (err) {
      console.error('reCAPTCHA setup error:', err);
      return false;
    }
  };

  /**
   * Check if Firebase is ready
   */
  const isReady = () => initialized && typeof firebase !== 'undefined' && firebase.auth;

  return {
    init,
    sendOtpToPhone,
    verifyOtp,
    setupRecaptcha,
    isReady,
    getConfirmationResult: () => confirmationResult
  };
})();
