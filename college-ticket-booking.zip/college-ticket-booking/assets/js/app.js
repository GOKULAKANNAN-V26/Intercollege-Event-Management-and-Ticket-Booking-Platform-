/**
 * VelTech EventPass – Main Frontend Application
 */

const App = (() => {
  // ── State ──────────────────────────────────────────────────
  let state = {
    step: 1,
    selectedEvent: null,
    ticketCount: 1,
    bookingRef: null,
    totalAmount: 0,
    expiresAt: null,
    timerInterval: null,
    resendCooldown: null,
    teamMembers: [],
    otpProviderReady: false,
  };

  // ── DOM Helpers ────────────────────────────────────────────
  const qs = (sel, ctx = document) => ctx.querySelector(sel);
  const qsa = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];



  function normalizeBookingPhone(raw) {
    if (!raw) return '';
    let normalized = raw.replace(/[^\d+]/g, '');
    if (normalized.startsWith('00')) {
      normalized = '+' + normalized.slice(2);
    }
    if (normalized.startsWith('0') && !normalized.startsWith('00')) {
      normalized = normalized.slice(1);
    }
    if (!normalized.startsWith('+')) {
      if (normalized.length === 10) {
        normalized = '+91' + normalized;
      } else if (normalized.length === 12 && normalized.startsWith('91')) {
        normalized = '+' + normalized;
      }
    }
    return normalized;
  }

  // ── Init ───────────────────────────────────────────────────
  function init() {
    attachCardListeners(); // Attach to server-rendered cards first
    loadEvents();
    bindSearch();
    bindModal();
    bindBookingForm();
    bindTeamFields();
    bindOTPForm();
    loadOtpProvider();
    initToasts();

    // Welcome message after registration
    const params = new URLSearchParams(window.location.search);
    if (params.get('welcome') === '1') {
      showToast('Welcome to VelTech EventPass! 🎉 Browse and book events below.', 'success', 5000);
      history.replaceState({}, '', window.location.pathname);
    }
  }

  // ── Attach Listeners to Server-Rendered Cards ──────────────
  async function attachCardListeners() {
    // For server-rendered cards, fetch event data on click
    qsa('.btn-book').forEach(btn => {
      if (!btn.hasAttribute('data-listener-attached')) {
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const eventId = parseInt(btn.dataset.eventId);
          try {
            const res = await fetch(`api/events.php?id=${eventId}`);
            const data = await res.json();
            if (data.success && data.event) {
              openBookingModal(data.event);
            } else {
              showToast('Failed to load event details.', 'danger');
            }
          } catch (err) {
            showToast('Error loading event: ' + err.message, 'danger');
          }
        });
        btn.setAttribute('data-listener-attached', 'true');
      }
    });

    qsa('.event-card').forEach(card => {
      if (!card.hasAttribute('data-listener-attached')) {
        card.addEventListener('click', async () => {
          const eventId = parseInt(card.dataset.eventId);
          try {
            const res = await fetch(`api/events.php?id=${eventId}`);
            const data = await res.json();
            if (data.success && data.event) {
              openBookingModal(data.event);
            } else {
              showToast('Failed to load event details.', 'danger');
            }
          } catch (err) {
            showToast('Error loading event: ' + err.message, 'danger');
          }
        });
        card.setAttribute('data-listener-attached', 'true');
      }
    });
  }

  function showToast(message, type = 'info', duration = 3500) {
    const colors = {
      success: '#2e7d32',
      danger: '#c62828',
      warning: '#e65100',
      info: '#003087'
    };
    const icons = {
      success: '✅',
      danger: '❌',
      warning: '⚠️',
      info: 'ℹ️'
    };

    const toast = document.createElement('div');
    toast.style.cssText = `
      background:${colors[type] || colors.info};
      color:#fff;
      padding:12px 16px;
      border-radius:10px;
      font-size:13px;
      font-weight:500;
      box-shadow:0 4px 16px rgba(0,0,0,.2);
      display:flex;
      align-items:flex-start;
      gap:10px;
      animation:slideInRight .3s ease;
      cursor:pointer;
      line-height:1.4;
    `;
    toast.innerHTML = `<span style="flex-shrink:0;font-size:16px">${icons[type] || icons.info}</span><span>${message}</span>`;
    toast.onclick = () => toast.remove();

    const container = qs('#toastContainer');
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = 'fadeOut .3s ease forwards';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  // ── Events List ───────────────────────────────────────────
  async function loadEvents(params = {}) {
    const grid  = qs('#eventsGrid');
    const count = qs('#eventsCount');
    if (!grid) return;

    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:40px">
      <div class="spinner spinner-dark" style="width:36px;height:36px;margin:auto"></div>
      <p style="margin-top:12px;color:#888">Loading events...</p>
    </div>`;

    try {
      const qs2 = new URLSearchParams(params).toString();
      const res  = await fetch(`api/events.php${qs2 ? '?' + qs2 : ''}`);
      const data = await res.json();

      if (!data.success) throw new Error(data.message);

      const deptSelect = qs('#filterDept');
      if (deptSelect && data.departments) {
        const current = deptSelect.value;
        deptSelect.innerHTML = '<option value="">All Departments</option>' +
          data.departments.map(d => `<option value="${esc(d)}" ${d === current ? 'selected' : ''}>${esc(d)}</option>`).join('');
      }

      if (count) count.textContent = `${data.total} event${data.total !== 1 ? 's' : ''} found`;

      if (data.events.length === 0) {
        grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
          <div class="icon">🔍</div><h3>No events found</h3>
          <p>Try adjusting your search or filters.</p>
        </div>`;
        return;
      }

      grid.innerHTML = data.events.map(renderEventCard).join('');

      qsa('.btn-book').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const ev = data.events.find(ev => ev.id === parseInt(btn.dataset.eventId));
          openBookingModal(ev);
        });
      });

      qsa('.event-card').forEach(card => {
        card.addEventListener('click', () => {
          const ev = data.events.find(ev => ev.id === parseInt(card.dataset.eventId));
          openBookingModal(ev);
        });
      });

    } catch (err) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
        <div class="icon">⚠️</div><h3>Failed to load events</h3>
        <p>${esc(err.message)}</p>
      </div>`;
    }
  }

  function renderEventCard(ev) {
    const urgencyLabel = {
      available: `${ev.available_tickets} tickets left`,
      low:       `Only ${ev.available_tickets} left!`,
      critical:  `⚡ Only ${ev.available_tickets} left!`,
      sold_out:  'Sold Out'
    }[ev.urgency] || '';

    const emoji = getDeptEmoji(ev.department);
    const isSoldOut = ev.urgency === 'sold_out';

    return `
    <div class="event-card" data-event-id="${ev.id}" role="listitem" tabindex="0"
         onkeydown="if(event.key==='Enter')this.click()">
      <div class="event-card-img">
        ${ev.image ? `<img src="${esc(ev.image)}" alt="${esc(ev.name)}" loading="lazy">` : `<span>${emoji}</span>`}
        <span class="dept-badge">${esc(ev.department)}</span>
      </div>
      <div class="event-card-body">
        <h3 class="event-card-title">${esc(ev.name)}</h3>
        <div class="event-meta">
          <div class="event-meta-item"><span class="mi">📅</span><span>${esc(ev.event_date_formatted)}</span></div>
          <div class="event-meta-item"><span class="mi">🕐</span><span>${esc(ev.event_time_formatted)}</span></div>
          <div class="event-meta-item"><span class="mi">📍</span><span>${esc(ev.venue)}</span></div>
        </div>
        <div class="event-card-footer">
          <span class="ticket-price ${ev.ticket_price == 0 ? 'free' : ''}">${esc(ev.ticket_price_formatted)}</span>
          <span class="availability ${ev.urgency}">${urgencyLabel}</span>
        </div>
        <button class="btn-book" data-event-id="${ev.id}" ${isSoldOut ? 'disabled' : ''}>
          ${isSoldOut ? '🚫 Sold Out' : '🎟 Book Tickets'}
        </button>
      </div>
    </div>`;
  }

  function getDeptEmoji(dept) {
    const map = {
      'Computer Science': '💻',
      'Science': '🔬',
      'Arts & Culture': '🎭',
      'Management': '📊',
      'Sports': '⚽',
      'Engineering': '⚙️',
      'Medical': '🏥',
      'Law': '⚖️',
      'Commerce': '💰',
      'Information Technology': '🖥️',
      'Artificial Intelligence': '🤖',
      'Data Science': '📈',
    };
    return map[dept] || '🎓';
  }

  // ── Search & Filter ────────────────────────────────────────
  function bindSearch() {
    let debounceTimer;
    const searchInput = qs('#searchInput');
    const filterDept = qs('#filterDept');
    const filterDate = qs('#filterDate');

    function doSearch() {
      const params = {};
      if (searchInput?.value.trim()) params.search = searchInput.value.trim();
      if (filterDept?.value) params.department = filterDept.value;
      if (filterDate?.value) params.date = filterDate.value;
      loadEvents(params);
    }

    searchInput?.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(doSearch, 400);
    });
    filterDept?.addEventListener('change', doSearch);
    filterDate?.addEventListener('change', doSearch);
  }

  // ── Modal ──────────────────────────────────────────────────
  function bindModal() {
    const overlay = qs('#bookingModal');
    if (!overlay) return;
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal();
    });
    qs('#modalClose')?.addEventListener('click', closeModal);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeModal();
    });
  }

  function openBookingModal(event) {
    // Check if user is logged in (simple check, assuming session is set)
    // Since the page requires login, this should be fine, but adding a check
    if (!event || event.urgency === 'sold_out') return;
    state.selectedEvent = event;
    state.step = 1;
    state.ticketCount = 1;
    state.bookingRef = null;

    resetModal();
    showStep(1);
    updatePriceSummary();

    qs('#bookingModal').classList.add('active');
    document.body.style.overflow = 'hidden';

    qs('#modalEventName').textContent = event.name;
    qs('#modalEventDate').textContent = `${event.event_date_formatted} at ${event.event_time_formatted}`;
    qs('#modalEventVenue').textContent = event.venue;
    qs('#modalEventPrice').textContent = event.ticket_price_formatted;
    qs('#modalAvailable').textContent = `${event.available_tickets} available`;
    
    // Initialize registration validation with event data
    if (typeof window.RegistrationValidation !== 'undefined') {
      window.RegistrationValidation.initialize(event);
    }
  }

  function closeModal() {
    qs('#bookingModal')?.classList.remove('active');
    document.body.style.overflow = '';
    clearTimers();
    resetModal();
  }

  function resetModal() {
    qs('#bookingForm')?.reset();
    qs('#otpForm')?.reset();
    qsa('.otp-digit').forEach(d => {
      d.value = '';
      d.classList.remove('filled');
    });
    clearAlert('bookingAlert');
    clearAlert('otpAlert');
    clearAlert('paymentAlert');
    clearTimers();
  }

  // ── Steps ──────────────────────────────────────────────────
  function showStep(n) {
    state.step = n;
    qsa('.booking-step').forEach((el, i) => {
      el.style.display = (i + 1 === n) ? 'block' : 'none';
    });
    qsa('.step').forEach((el, i) => {
      el.classList.toggle('active', i + 1 === n);
      el.classList.toggle('done', i + 1 < n);
    });
  }

  // ── Booking Form (Step 1) ──────────────────────────────────
  function bindBookingForm() {
    qs('#ticketMinus')?.addEventListener('click', () => {
      let newCount = state.ticketCount - 1;
      
      // Validate with registration rules
      if (typeof window.RegistrationValidation !== 'undefined') {
        newCount = window.RegistrationValidation.validateTicketCount(newCount);
      } else {
        newCount = Math.max(1, newCount);
      }
      
      if (newCount !== state.ticketCount) {
        state.ticketCount = newCount;
        qs('#ticketCount').textContent = state.ticketCount;
        updatePriceSummary();
      }
    });
    
    qs('#ticketPlus')?.addEventListener('click', () => {
      const max = Math.min(10, state.selectedEvent?.available_tickets || 10);
      let newCount = state.ticketCount + 1;
      
      // Validate with registration rules
      if (typeof window.RegistrationValidation !== 'undefined') {
        newCount = window.RegistrationValidation.validateTicketCount(newCount);
      } else {
        newCount = Math.min(max, newCount);
      }
      
      if (newCount !== state.ticketCount && newCount <= max) {
        state.ticketCount = newCount;
        qs('#ticketCount').textContent = state.ticketCount;
        updatePriceSummary();
      }
    });
    
    qs('#bookingForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      // Validate registration form before submission
      if (typeof window.RegistrationValidation !== 'undefined') {
        if (!window.RegistrationValidation.validateForm()) {
          return; // Validation failed, don't submit
        }
      }
      
      await submitBookingDetails();
    });
  }

  function bindTeamFields() {
    const toggle = qs('#teamRegistrationToggle');
    const section = qs('#teamSection');
    const addBtn = qs('#btnAddTeammate');

    if (!toggle || !section || !addBtn) return;

    toggle.addEventListener('change', () => {
      const isChecked = toggle.checked;
      
      // Call registration validation handler
      if (typeof window.RegistrationValidation !== 'undefined') {
        window.RegistrationValidation.handleTeamToggle(isChecked);
      } else {
        // Fallback behavior
        section.style.display = isChecked ? 'block' : 'none';
        if (isChecked && qs('#teamMembersContainer')?.children.length === 0) {
          addTeammateRow();
        }
      }
    });

    addBtn.addEventListener('click', () => addTeammateRow());
  }

  function addTeammateRow() {
    const container = qs('#teamMembersContainer');
    if (!container) return;
    const row = document.createElement('div');
    row.style.display = 'grid';
    row.style.gridTemplateColumns = '1fr auto';
    row.style.gap = '10px';

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'form-control team-member-name';
    input.placeholder = 'Teammate name';
    input.maxLength = 100;

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'btn btn-outline';
    remove.style.minWidth = '120px';
    remove.textContent = 'Remove';
    remove.addEventListener('click', () => row.remove());

    row.appendChild(input);
    row.appendChild(remove);
    container.appendChild(row);
  }

  function loadOtpProvider() {
    // MSG91 OTP provider is loaded in HTML
    // Check if already loaded
    if (typeof window.initSendOTP === 'function') {
      state.otpProviderReady = true;
    } else {
      // Wait for it to load
      const checkLoaded = () => {
        if (typeof window.initSendOTP === 'function') {
          state.otpProviderReady = true;
        } else {
          setTimeout(checkLoaded, 100);
        }
      };
      checkLoaded();
    }
  }

  function startOtpWidget(phone, email) {
    const widgetContainer = qs('#otpWidgetContainer');
    qs('#otpFallback').style.display = 'block'; // Always show fallback for manual OTP entry
    const config = window.configuration || {
      widgetId: '366564734b65373038303032',
      tokenAuth: '513951TEA34qlnAx069f8f158P1',
      identifier: phone || email || '',
      exposeMethods: true,
      success: (data) => handleOtpWidgetSuccess(data),
      failure: (error) => handleOtpWidgetFailure(error),
      container: '#otpWidgetContainer'
    };

    config.identifier = phone || email || '';
    config.exposeMethods = true;
    config.success = (data) => handleOtpWidgetSuccess(data);
    config.failure = (error) => handleOtpWidgetFailure(error);
    config.container = '#otpWidgetContainer';
    window.configuration = config;

    if (!state.otpProviderReady || typeof window.initSendOTP !== 'function') {
      if (widgetContainer) widgetContainer.textContent = 'Loading OTP widget... Please wait.';
      const checkLoaded = setInterval(() => {
        if (typeof window.initSendOTP === 'function') {
          clearInterval(checkLoaded);
          state.otpProviderReady = true;
          startOtpWidget(phone, email);
        }
      }, 150);
      return;
    }

    try {
      if (widgetContainer) widgetContainer.innerHTML = '';
      console.info('Initializing OTP widget for', config.identifier);
      window.initSendOTP(config);
    } catch (err) {
      if (widgetContainer) widgetContainer.textContent = 'Failed to initialize OTP widget. Using manual OTP form.';
      console.error('OTP widget initialization error:', err);
    }
  }

  async function handleOtpWidgetSuccess(data) {
    console.log('OTP Widget Success - Received Data:', data);
    showToast('OTP verified by the widget! Proceeding to payment...', 'success');
    await verifyOtpWithWidget(data);
  }

  function handleOtpWidgetFailure(error) {
    showAlert('otpAlert', 'danger', 'OTP widget error. Please try again or use manual OTP.');
    console.error('OTP widget failure:', error);
    qs('#otpFallback').style.display = 'block';
  }

  async function verifyOtpWithWidget(widgetData) {
    const btn = qs('#btnVerifyOTP');
    setLoading(btn, true, 'Verifying...');
    clearAlert('otpAlert');

    try {
      // Extract access token from widget response
      // MSG91 widget can return access_token, accessToken, token, or jwt_token
      const accessToken = widgetData?.access_token || widgetData?.accessToken || widgetData?.token || widgetData?.jwt_token || null;
      console.info('MSG91 widget payload:', widgetData, 'resolved token:', accessToken);

      if (!accessToken) {
        showAlert('otpAlert', 'danger', 'Widget did not return an access token. Please retry OTP verification.');
        setLoading(btn, false, '✓ Verify OTP');
        return;
      }

      const res  = await fetch('api/verify_otp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          token: accessToken,
          widget_data: widgetData
        })
      });

      if (!res.ok) {
        const text = await res.text();
        console.error('verify_otp.php failed:', res.status, text);
        showAlert('otpAlert', 'danger', 'Server error verifying OTP. Please retry.');
        setLoading(btn, false, '✓ Verify OTP');
        return;
      }

      let data;
      try {
        data = await res.json();
      } catch (parseError) {
        const text = await res.text();
        console.error('verify_otp.php JSON parse failed:', parseError, text);
        showAlert('otpAlert', 'danger', 'Server response error during verification.');
        setLoading(btn, false, '✓ Verify OTP');
        return;
      }


      if (data.success) {
        state.bookingRef  = data.booking_ref;
        state.totalAmount = data.total_amount;
        state.expiresAt   = new Date(data.expires_at.replace(' ', 'T'));

        showStep(3);
        startBookingTimer();
        await initiatePayment();
        showToast('OTP verified! Tickets reserved for 15 minutes.', 'success');
      } else {
        showAlert('otpAlert', 'danger', data.message);
      }
    } catch (err) {
      showAlert('otpAlert', 'danger', 'Network error. Please try again.');
    } finally {
      setLoading(btn, false, '✓ Verify OTP');
    }
  }

  function updatePriceSummary() {
    const price = state.selectedEvent?.ticket_price || 0;
    const total = price * state.ticketCount;
    const fmt   = price === 0 ? 'FREE' : '₹' + total.toLocaleString('en-IN', { minimumFractionDigits: 2 });
    const el    = qs('#priceSummary');
    if (el) el.textContent = fmt;
  }

  async function submitBookingDetails() {
    const btn = qs('#btnSendOTP');
    const name = qs('#inputName')?.value.trim();
    const email = qs('#inputEmail')?.value.trim();
    const rawPhone = qs('#inputPhone')?.value.trim();
    const phone = normalizeBookingPhone(rawPhone);
    const teamName = qs('#inputTeamName')?.value.trim();
    const teammates = qsa('.team-member-name').map(el => el.value.trim()).filter(Boolean);

    if (!name || !email || !phone) {
      showAlert('bookingAlert', 'danger', 'Please fill in all fields.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showAlert('bookingAlert', 'danger', 'Invalid email address.');
      return;
    }
    if (!/^\+?[0-9]{10,15}$/.test(phone.replace(/[\s\-()]/g, ''))) {
      showAlert('bookingAlert', 'danger', 'Invalid phone number (10-15 digits).');
      return;
    }

    setLoading(btn, true, 'Sending OTP...');
    clearAlert('bookingAlert');

    try {
      const res = await fetch('api/send_otp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          event_id: state.selectedEvent.id,
          tickets: state.ticketCount,
          team_name: teamName,
          team_members: teammates
        })
      });

      if (!res.ok) {
        const text = await res.text();
        console.error('send_otp.php failed:', res.status, text);
        showAlert('bookingAlert', 'danger', 'Server error. Please refresh and try again.');
        return;
      }

      let data;
      try {
        data = await res.json();
      } catch (parseError) {
        const text = await res.text();
        console.error('send_otp.php JSON parse failed:', parseError, text);
        showAlert('bookingAlert', 'danger', 'Server response error. Please refresh and try again.');
        return;
      }

      if (data.success) {
        showStep(2);
        qs('#otpPhone').textContent = phone;
        qs('#otpEmail').textContent = email;
        qs('#otpFallback').style.display = 'block';
        startResendCooldown();
        
        // Show OTP in development mode
        if (data.dev_mode && data.otp_dev) {
          showAlert('otpAlert', 'success', 
            `🔓 DEVELOPMENT MODE: Your OTP is <strong style="font-size:20px;letter-spacing:3px;color:#2e7d32">${data.otp_dev}</strong>`, 
            false);
          console.log('🔓 DEV MODE - OTP:', data.otp_dev);
          
          // Auto-fill OTP in development mode
          const otpDigits = data.otp_dev.toString().split('');
          qsa('.otp-digit').forEach((input, idx) => {
            if (otpDigits[idx]) {
              input.value = otpDigits[idx];
            }
          });
        }
        
        setTimeout(() => qsa('.otp-digit')[0]?.focus(), 100);
        console.log('OTP sent, normalized phone:', phone);
        startOtpWidget(phone, email);
      } else {
        showAlert('bookingAlert', 'danger', data.message || 'Failed to send OTP.');
      }
    } catch (err) {
      console.error('send_otp fetch error:', err);
      showAlert('bookingAlert', 'danger', 'Network error. Please try again.');
    } finally {
      setLoading(btn, false, '📱 Send OTP');
    }
  }

  // ── OTP Form (Step 2) ──────────────────────────────────────
  function bindOTPForm() {
    qsa('.otp-digit').forEach((input, idx, arr) => {
      input.addEventListener('input', (e) => {
        const val = e.target.value.replace(/\D/g, '');
        e.target.value = val.slice(-1);
        e.target.classList.toggle('filled', !!e.target.value);
        if (val && idx < arr.length - 1) arr[idx + 1].focus();
        checkAutoSubmitOTP();
      });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !e.target.value && idx > 0) {
          arr[idx - 1].focus();
          arr[idx - 1].value = '';
          arr[idx - 1].classList.remove('filled');
        }
      });
      input.addEventListener('paste', (e) => {
        e.preventDefault();
        const pasted = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
        arr.forEach((inp, i) => {
          inp.value = pasted[i] || '';
          inp.classList.toggle('filled', !!inp.value);
        });
        arr[Math.min(pasted.length, arr.length - 1)]?.focus();
        checkAutoSubmitOTP();
      });
    });

    qs('#otpForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      await submitOTP();
    });
    qs('#btnResendOTP')?.addEventListener('click', async () => {
      await resendOTP();
    });
    qs('#btnBackToDetails')?.addEventListener('click', () => showStep(1));
  }

  function checkAutoSubmitOTP() {
    const digits = qsa('.otp-digit').map(d => d.value).join('');
    if (digits.length === 4) setTimeout(() => submitOTP(), 200);
  }

  async function submitOTP() {
    const digits = qsa('.otp-digit').map(d => d.value).join('');
    if (digits.length !== 4) {
      showAlert('otpAlert', 'danger', 'Please enter the complete 4-digit OTP.');
      return;
    }

    const btn = qs('#btnVerifyOTP');
    setLoading(btn, true, 'Verifying...');
    clearAlert('otpAlert');

    try {
      const res = await fetch('api/verify_otp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ otp: digits })
      });
      const data = await res.json();

      if (data.success) {
        state.bookingRef = data.booking_ref;
        state.totalAmount = data.total_amount;
        
        // Check if this is a free event
        if (data.is_free && data.redirect) {
          // Free event - redirect to confirmation
          showToast('✅ Free event booking confirmed!', 'success', 3000);
          setTimeout(() => {
            window.location.href = data.redirect;
          }, 1000);
          return;
        }
        
        // Paid event - proceed to payment
        // Parse server expiry time — this is the server-synced timer
        state.expiresAt = new Date(data.expires_at.replace(' ', 'T'));

        showStep(3);
        startBookingTimer();
        await initiatePayment();
        showToast('OTP verified! Tickets reserved for 15 minutes.', 'success');
      } else {
        showAlert('otpAlert', 'danger', data.message);
        qsa('.otp-digit').forEach(d => {
          d.value = '';
          d.classList.remove('filled');
        });
        qsa('.otp-digit')[0]?.focus();
      }
    } catch (err) {
      showAlert('otpAlert', 'danger', 'Network error. Please try again.');
    } finally {
      setLoading(btn, false, '✓ Verify OTP');
    }
  }

  async function resendOTP() {
    const btn = qs('#btnResendOTP');
    btn.disabled = true;
    const name = qs('#inputName')?.value.trim();
    const email = qs('#inputEmail')?.value.trim();
    const phone = qs('#inputPhone')?.value.trim();

    try {
      const res = await fetch('api/send_otp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          event_id: state.selectedEvent.id,
          tickets: state.ticketCount
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast('OTP resent!', 'success');
        
        // Show OTP in development mode
        if (data.dev_mode && data.otp_dev) {
          showAlert('otpAlert', 'success', 
            `🔓 DEVELOPMENT MODE: Your OTP is <strong style="font-size:20px;letter-spacing:3px;color:#2e7d32">${data.otp_dev}</strong>`, 
            false);
          console.log('🔓 DEV MODE - OTP:', data.otp_dev);
          
          // Auto-fill OTP in development mode
          const otpDigits = data.otp_dev.toString().split('');
          qsa('.otp-digit').forEach((input, idx) => {
            if (otpDigits[idx]) {
              input.value = otpDigits[idx];
            }
          });
        }
      } else {
        showAlert('otpAlert', 'danger', data.message);
      }
    } catch (err) {
      showAlert('otpAlert', 'danger', 'Failed to resend OTP.');
    }
    startResendCooldown();
  }

  function startResendCooldown() {
    const btn = qs('#btnResendOTP');
    const span = qs('#resendTimer');
    if (!btn) return;
    let seconds = 60;
    btn.disabled = true;
    if (span) span.textContent = ` (${seconds}s)`;
    clearInterval(state.resendCooldown);
    state.resendCooldown = setInterval(() => {
      seconds--;
      if (span) span.textContent = ` (${seconds}s)`;
      if (seconds <= 0) {
        clearInterval(state.resendCooldown);
        btn.disabled = false;
        if (span) span.textContent = '';
      }
    }, 1000);
  }

  // ── Payment (Step 3) ───────────────────────────────────────
  async function initiatePayment() {
    const btn = qs('#btnPay');
    setLoading(btn, true, 'Preparing payment...');
    clearAlert('paymentAlert');

    try {
      const res = await fetch('api/create_order.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ booking_ref: state.bookingRef })
      });
      const data = await res.json();

      if (!data.success) {
        showAlert('paymentAlert', 'danger', data.message);
        setLoading(btn, false, '💳 Pay Now');
        return;
      }

      const totalFmt = data.amount === 0 ? 'FREE' : '₹' + (data.amount / 100).toLocaleString('en-IN', { minimumFractionDigits: 2 });
      qs('#paymentTotal').textContent = totalFmt;
      qs('#paymentEventName').textContent = state.selectedEvent?.name || '';

      setLoading(btn, false, `💳 Pay ${totalFmt}`);
      btn.onclick = () => openRazorpay(data);

    } catch (err) {
      showAlert('paymentAlert', 'danger', 'Failed to initialize payment. Please try again.');
      setLoading(btn, false, '💳 Pay Now');
    }
  }

  function openRazorpay(orderData) {
    if (typeof Razorpay === 'undefined') {
      showAlert('paymentAlert', 'danger', 'Payment gateway not loaded. Please refresh and try again.');
      return;
    }

    const rzp = new Razorpay({
      key:         orderData.key_id,
      amount:      orderData.amount,
      currency:    orderData.currency,
      name:        'VelTech EventPass',
      description: state.selectedEvent?.name || 'Event Ticket',
      image:       'assets/images/veltech-logo.svg',
      order_id:    orderData.order_id,
      prefill:     { 
        name: orderData.user_name, 
        email: orderData.user_email, 
        contact: orderData.user_phone 
      },
      theme:       { color: '#003087' },
      modal: {
        ondismiss: () => showAlert('paymentAlert', 'warning', 'Payment cancelled. Your tickets are still reserved. Click Pay Now to try again.'),
        confirm_close: true,
        escape: false,
        backdropclose: false
      },
      handler: async (response) => { await verifyPayment(response, orderData.booking_ref); },
      config: {
        display: {
          language: 'en',
          hide: [
            // Hide EMI and Pay Later options for event tickets
            { method: 'emi' },
            { method: 'paylater' }
          ],
          preferences: {
            show_default_blocks: true
          }
        }
      },
      // Enable all payment methods including UPI
      method: {
        upi: true,           // Enable UPI (Google Pay, PhonePe, Paytm, BHIM)
        card: true,          // Enable Cards
        netbanking: true,    // Enable Net Banking
        wallet: true,        // Enable Wallets (Paytm, PhonePe, etc.)
        qr: true            // Enable QR Code scanning
      },
      // UPI specific options
      upi: {
        flow: 'collect',     // collect | intent | qr
        apps: ['google_pay', 'phonepe', 'paytm', 'bhim']
      },
      notes: {
        event_name: state.selectedEvent?.name || 'Event',
        booking_ref: orderData.booking_ref,
        ticket_count: state.ticketCount
      }
    });
    
    rzp.on('payment.failed', (r) => {
      console.error('Payment failed:', r.error);
      showAlert('paymentAlert', 'danger', `Payment failed: ${r.error.description || 'Please try again'}`);
    });
    
    rzp.open();
  }

  async function verifyPayment(response, bookingRef) {
    showLoading('Confirming your booking...');
    try {
      const res  = await fetch('api/verify_payment.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          razorpay_order_id:   response.razorpay_order_id,
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_signature:  response.razorpay_signature,
          booking_ref:         bookingRef,
        })
      });
      const data = await res.json();
      hideLoading();
      if (data.success) { closeModal(); window.location.href = data.redirect; }
      else showAlert('paymentAlert', 'danger', data.message || 'Payment verification failed. Please contact support.');
    } catch (err) {
      hideLoading();
      showAlert('paymentAlert', 'danger', 'Verification failed. Please contact support with your payment ID.');
    }
  }

  // ── Server-Synced Timer ────────────────────────────────────
  function startBookingTimer() {
    const timerEl = qs('#bookingTimer');
    if (!timerEl || !state.expiresAt) return;
    clearInterval(state.timerInterval);

    function tick() {
      const remaining = Math.max(0, Math.floor((state.expiresAt - Date.now()) / 1000));
      const mins = Math.floor(remaining / 60);
      const secs = remaining % 60;
      timerEl.textContent = `${mins}:${secs.toString().padStart(2, '0')}`;

      const wrap = timerEl.closest('.booking-timer');
      if (remaining <= 60) wrap?.classList.add('timer-urgent');
      else wrap?.classList.remove('timer-urgent');

      if (remaining === 0) {
        clearInterval(state.timerInterval);
        const btn = qs('#btnPay');
        if (btn) { btn.disabled = true; btn.textContent = '⏱ Expired'; }
        showAlert('paymentAlert', 'danger', '⏱ Booking expired. Please close and start again.');
        showToast('Booking expired — please start a new booking.', 'danger', 6000);
      }
    }

    tick();
    state.timerInterval = setInterval(tick, 1000);
  }

  function clearTimers() {
    clearInterval(state.timerInterval);
    clearInterval(state.resendCooldown);
  }

  // ── UI Helpers ─────────────────────────────────────────────
  function showAlert(id, type, message) {
    const el = qs(`#${id}`);
    if (!el) return;
    el.className = `alert alert-${type}`;
    el.innerHTML = `<span>${message}</span>`;
    el.style.display = 'flex';
  }

  function clearAlert(id) {
    const el = qs(`#${id}`);
    if (el) el.style.display = 'none';
  }

  function setLoading(btn, loading, text) {
    if (!btn) return;
    btn.disabled = loading;
    btn.innerHTML = loading ? `<span class="spinner"></span> ${text}` : text;
  }

  function showLoading(text = 'Processing...') {
    const overlay = qs('#loadingOverlay');
    if (overlay) { overlay.classList.add('active'); const t = overlay.querySelector('.loading-text'); if (t) t.textContent = text; }
  }

  function hideLoading() { qs('#loadingOverlay')?.classList.remove('active'); }

  // Expose widget callbacks for third-party OTP provider
  window.handleOtpWidgetSuccess = handleOtpWidgetSuccess;
  window.handleOtpWidgetFailure = handleOtpWidgetFailure;

  function esc(str) {
    if (str == null) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  return { init, loadEvents };
})();

// Toast animation styles
const style = document.createElement('style');
style.textContent = `
  @keyframes slideInRight { from { transform:translateX(110%); opacity:0; } to { transform:translateX(0); opacity:1; } }
  @keyframes fadeOut { from { opacity:1; } to { opacity:0; transform:translateY(-8px); } }
`;
document.head.appendChild(style);

document.addEventListener('DOMContentLoaded', () => App.init());
