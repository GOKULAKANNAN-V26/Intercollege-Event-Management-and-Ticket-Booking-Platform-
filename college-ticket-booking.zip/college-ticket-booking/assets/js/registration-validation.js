/**
 * Registration Type Validation Logic
 * Handles Solo/Team event registration rules
 */

// Global variable to store current event registration rules
let currentEventRules = {
    registrationType: 'Individual',
    minTeamMembers: 2,
    maxTeamMembers: 0
};

/**
 * Initialize registration validation when event is selected
 */
function initializeRegistrationValidation(eventData) {
    currentEventRules = {
        registrationType: eventData.registration_type || 'Individual',
        minTeamMembers: parseInt(eventData.min_team_members) || 2,
        maxTeamMembers: parseInt(eventData.max_team_members) || 0
    };
    
    console.log('Registration rules initialized:', currentEventRules);
    
    // Apply rules to the booking form
    applyRegistrationRules();
}

/**
 * Apply registration rules to the booking form
 */
function applyRegistrationRules() {
    const regType = currentEventRules.registrationType;
    const minTeam = currentEventRules.minTeamMembers;
    const maxTeam = currentEventRules.maxTeamMembers;
    
    const teamToggle = document.getElementById('teamRegistrationToggle');
    const teamSection = document.getElementById('teamSection');
    const ticketCount = document.getElementById('ticketCount');
    const ticketPlus = document.getElementById('ticketPlus');
    const ticketMinus = document.getElementById('ticketMinus');
    
    if (!teamToggle || !teamSection) return;
    
    // Reset state
    teamToggle.checked = false;
    teamSection.style.display = 'none';
    
    // Clear any previous alerts
    const bookingAlert = document.getElementById('bookingAlert');
    if (bookingAlert) {
        bookingAlert.style.display = 'none';
    }
    
    if (regType === 'Individual') {
        // SOLO EVENT: Restrict to exactly 1 ticket
        ticketCount.textContent = '1';
        ticketPlus.disabled = true;
        ticketMinus.disabled = true;
        
        // Hide team registration option
        if (teamToggle.parentElement) {
            teamToggle.parentElement.style.display = 'none';
        }
        
        // Show info message
        showRegistrationInfo('👤 This is a Solo Entry event. Only 1 ticket per booking.', 'info');
        
    } else if (regType === 'Team') {
        // TEAM EVENT: Enforce minimum team size
        const minTickets = Math.max(minTeam, 2);
        ticketCount.textContent = minTickets.toString();
        
        // Enable team registration by default
        teamToggle.checked = true;
        teamToggle.disabled = true; // Cannot uncheck for team events
        teamSection.style.display = 'block';
        
        // Show team registration option (but disabled)
        if (teamToggle.parentElement) {
            teamToggle.parentElement.style.display = 'block';
        }
        
        // Set minimum ticket count
        ticketMinus.disabled = true; // Can't go below minimum
        
        // Add validation for maximum if specified
        if (maxTeam > 0) {
            showRegistrationInfo(`👥 Team Entry: ${minTeam}-${maxTeam} members required.`, 'info');
        } else {
            showRegistrationInfo(`👥 Team Entry: Minimum ${minTeam} members required.`, 'info');
        }
        
        // Pre-populate team member fields
        populateTeamMemberFields(minTickets);
        
    } else if (regType === 'Both') {
        // BOTH: Allow user to choose
        ticketCount.textContent = '1';
        
        // Show team registration option
        if (teamToggle.parentElement) {
            teamToggle.parentElement.style.display = 'block';
        }
        teamToggle.disabled = false;
        
        showRegistrationInfo('👤👥 You can register as Solo or Team for this event.', 'info');
    }
    
    // Update price summary (call parent function if available)
    if (typeof updatePriceSummary === 'function') {
        updatePriceSummary();
    }
}

/**
 * Validate ticket count based on registration type
 */
function validateTicketCount(newCount) {
    const regType = currentEventRules.registrationType;
    const minTeam = currentEventRules.minTeamMembers;
    const maxTeam = currentEventRules.maxTeamMembers;
    const teamToggle = document.getElementById('teamRegistrationToggle');
    
    if (regType === 'Individual') {
        // Solo events: always 1
        return 1;
    }
    
    if (regType === 'Team') {
        // Team events: enforce min/max
        if (newCount < minTeam) {
            showRegistrationInfo(`Team events require at least ${minTeam} members.`, 'warning');
            return minTeam;
        }
        if (maxTeam > 0 && newCount > maxTeam) {
            showRegistrationInfo(`Team events allow maximum ${maxTeam} members.`, 'warning');
            return maxTeam;
        }
        return newCount;
    }
    
    if (regType === 'Both') {
        // If team registration is enabled, enforce team rules
        if (teamToggle && teamToggle.checked) {
            if (newCount < minTeam) {
                showRegistrationInfo(`Team registration requires at least ${minTeam} members.`, 'warning');
                return minTeam;
            }
            if (maxTeam > 0 && newCount > maxTeam) {
                showRegistrationInfo(`Team registration allows maximum ${maxTeam} members.`, 'warning');
                return maxTeam;
            }
        } else {
            // Solo mode - allow only 1
            if (newCount !== 1) {
                return 1;
            }
        }
        return newCount;
    }
    
    return newCount;
}

/**
 * Handle team registration toggle
 */
function handleTeamToggle(isChecked) {
    const regType = currentEventRules.registrationType;
    const minTeam = currentEventRules.minTeamMembers;
    const teamSection = document.getElementById('teamSection');
    const ticketCount = document.getElementById('ticketCount');
    
    if (regType === 'Team') {
        // Team events: always team registration
        return;
    }
    
    if (regType === 'Both') {
        if (isChecked) {
            // Enable team registration
            teamSection.style.display = 'block';
            
            // Set minimum ticket count
            const currentCount = parseInt(ticketCount.textContent);
            if (currentCount < minTeam) {
                ticketCount.textContent = minTeam.toString();
                // Update price summary if function is available
                if (typeof updatePriceSummary === 'function') {
                    updatePriceSummary();
                }
            }
            
            // Populate team member fields
            populateTeamMemberFields(parseInt(ticketCount.textContent));
            
        } else {
            // Disable team registration
            teamSection.style.display = 'none';
            
            // Reset to 1 ticket for solo
            ticketCount.textContent = '1';
            // Update price summary if function is available
            if (typeof updatePriceSummary === 'function') {
                updatePriceSummary();
            }
        }
    }
}

/**
 * Populate team member input fields
 */
function populateTeamMemberFields(count) {
    const container = document.getElementById('teamMembersContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    // Subtract 1 because the main registrant is already counted
    const teammateCount = Math.max(0, count - 1);
    
    for (let i = 1; i <= teammateCount; i++) {
        const row = document.createElement('div');
        row.style.display = 'grid';
        row.style.gridTemplateColumns = '1fr auto';
        row.style.gap = '10px';
        row.style.marginBottom = '10px';

        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'form-control team-member-name';
        input.placeholder = `Teammate ${i} name`;
        input.maxLength = 100;

        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'btn btn-outline';
        remove.style.minWidth = '120px';
        remove.textContent = 'Remove';
        remove.addEventListener('click', () => row.remove());

        row.appendChild(input);
        row.appendChild(remove);
        container.appendChild(row);
    }
}

/**
 * Show registration info message
 */
function showRegistrationInfo(message, type = 'info') {
    const alert = document.getElementById('bookingAlert');
    if (!alert) return;
    
    alert.className = 'alert alert-' + type;
    alert.textContent = message;
    alert.style.display = 'block';
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        alert.style.display = 'none';
    }, 5000);
}

/**
 * Validate form before submission
 */
function validateRegistrationForm() {
    const regType = currentEventRules.registrationType;
    const minTeam = currentEventRules.minTeamMembers;
    const maxTeam = currentEventRules.maxTeamMembers;
    const teamToggle = document.getElementById('teamRegistrationToggle');
    const ticketCount = parseInt(document.getElementById('ticketCount').textContent);
    const teamName = document.getElementById('inputTeamName')?.value.trim();
    const teamMemberInputs = document.querySelectorAll('#teamMembersContainer .team-member-name');
    
    // Solo event validation
    if (regType === 'Individual') {
        if (ticketCount !== 1) {
            showRegistrationInfo('Solo events allow only 1 ticket.', 'danger');
            return false;
        }
    }
    
    // Team event validation
    if (regType === 'Team') {
        if (ticketCount < minTeam) {
            showRegistrationInfo(`Team events require at least ${minTeam} members.`, 'danger');
            return false;
        }
        
        if (maxTeam > 0 && ticketCount > maxTeam) {
            showRegistrationInfo(`Team events allow maximum ${maxTeam} members.`, 'danger');
            return false;
        }
        
        if (!teamName) {
            showRegistrationInfo('Please enter a team name.', 'danger');
            return false;
        }
        
        // Validate team member names (need at least minTeam - 1 teammates since main registrant counts)
        let filledMembers = 0;
        teamMemberInputs.forEach(input => {
            if (input.value.trim()) filledMembers++;
        });
        
        const requiredTeammates = minTeam - 1; // Subtract main registrant
        if (filledMembers < requiredTeammates) {
            showRegistrationInfo(`Please enter at least ${requiredTeammates} teammate name(s).`, 'danger');
            return false;
        }
    }
    
    // Both type with team registration enabled
    if (regType === 'Both' && teamToggle && teamToggle.checked) {
        if (ticketCount < minTeam) {
            showRegistrationInfo(`Team registration requires at least ${minTeam} members.`, 'danger');
            return false;
        }
        
        if (maxTeam > 0 && ticketCount > maxTeam) {
            showRegistrationInfo(`Team registration allows maximum ${maxTeam} members.`, 'danger');
            return false;
        }
        
        if (!teamName) {
            showRegistrationInfo('Please enter a team name for team registration.', 'danger');
            return false;
        }
        
        // Validate team member names
        let filledMembers = 0;
        teamMemberInputs.forEach(input => {
            if (input.value.trim()) filledMembers++;
        });
        
        const requiredTeammates = minTeam - 1;
        if (filledMembers < requiredTeammates) {
            showRegistrationInfo(`Please enter at least ${requiredTeammates} teammate name(s).`, 'danger');
            return false;
        }
    }
    
    return true;
}

/**
 * Get team member names as array
 */
function getTeamMemberNames() {
    const inputs = document.querySelectorAll('#teamMembersContainer input');
    const names = [];
    
    inputs.forEach(input => {
        const name = input.value.trim();
        if (name) names.push(name);
    });
    
    return names;
}

// Export functions for use in app.js
window.RegistrationValidation = {
    initialize: initializeRegistrationValidation,
    validateTicketCount: validateTicketCount,
    handleTeamToggle: handleTeamToggle,
    validateForm: validateRegistrationForm,
    getTeamMembers: getTeamMemberNames,
    getCurrentRules: () => currentEventRules
};
