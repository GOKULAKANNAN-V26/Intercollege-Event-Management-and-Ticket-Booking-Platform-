<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) session_start();

// Already logged in
if (!empty($_SESSION['user_id'])) {
    session_write_close();
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$errors   = [];
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = strtolower(trim($_POST['email'] ?? ''));
    $phone   = trim($_POST['phone'] ?? '');
    $dept    = trim($_POST['department'] ?? '');
    $roll    = trim($_POST['roll_number'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $formData = compact('name', 'email', 'phone', 'dept', 'roll');

    // Validate
    if (strlen($name) < 2)
        $errors[] = 'Name must be at least 2 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        $errors[] = 'Invalid email address.';
    $cleanPhone = preg_replace('/[\s\-\(\)\+]/', '', $phone);
    if (!preg_match('/^[0-9]{10,15}$/', $cleanPhone))
        $errors[] = 'Phone must be 10–15 digits (numbers only).';
    if (strlen($pass) < 8)
        $errors[] = 'Password must be at least 8 characters.';
    if ($pass !== $confirm)
        $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        try {
            $conn = getDBConnection();

            // Check duplicate email
            $chk = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $chk->bind_param('s', $email);
            $chk->execute();
            $chk->store_result();
            $exists = $chk->num_rows > 0;
            $chk->close();

            if ($exists) {
                $errors[] = 'This email is already registered. <a href="login.php" style="color:#2c3e50;font-weight:600;text-decoration:none;">Sign in instead</a>.';
            } else {
                $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost' => 10]);
                $isVerified = 1;

                $ins = $conn->prepare(
                    "INSERT INTO users (name, email, phone, password_hash, department, roll_number, is_verified)
                     VALUES (?, ?, ?, ?, ?, ?, ?)"
                );
                // s=name, s=email, s=phone, s=hash, s=dept, s=roll, i=is_verified
                $ins->bind_param('ssssssi',
                    $name, $email, $phone, $hash, $dept, $roll, $isVerified
                );
                $ins->execute();
                $uid = $conn->insert_id;
                $ins->close();

                if ($uid > 0) {
                    session_regenerate_id(true);
                    $_SESSION['user_id']    = $uid;
                    $_SESSION['user_name']  = $name;
                    $_SESSION['user_email'] = $email;
                    $_SESSION['user_phone'] = $phone;
                    session_write_close();

                    header('Location: ' . APP_URL . '/index.php?welcome=1');
                    exit;
                } else {
                    $errors[] = 'Registration failed. Please try again.';
                }
            }
        } catch (Exception $e) {
            $errors[] = 'Registration error: ' . htmlspecialchars($e->getMessage());
        }
    }
}
session_write_close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up – VelTech EventPass</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    .auth-wrap { max-width: 540px; margin: 24px auto; padding: 0 16px 40px; }
    .auth-card { background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.1); border: 1px solid rgba(255,255,255,0.2); }
    .auth-hdr  { background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%); color: #fff; padding: 30px 28px; text-align: center; position: relative; }
    .auth-hdr::before { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%); }
    .auth-hdr > * { position: relative; z-index: 1; }
    .auth-hdr img { height: 50px; filter: brightness(0) invert(1); margin: 0 auto 12px; display: block; }
    .auth-hdr h1 { font-size: 23px; font-weight: 700; margin-bottom: 5px; letter-spacing: -0.5px; }
    .auth-hdr p  { font-size: 14px; opacity: .9; font-weight: 400; }
    .auth-body { padding: 30px 28px; }
    .form-row  { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .pw-wrap   { position: relative; }
    .pw-eye    { position: absolute; right: 13px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; font-size: 17px; color: #6c757d; transition: color 0.2s; padding: 0; }
    .pw-eye:hover { color: #495057; }
    .bar       { height: 4px; border-radius: 2px; margin-top: 5px; background: #e9ecef; transition: all .3s; }
    .bar.w { background: linear-gradient(90deg, #dc3545, #fd7e14); width: 33%; }
    .bar.m { background: linear-gradient(90deg, #fd7e14, #ffc107); width: 66%; }
    .bar.s { background: linear-gradient(90deg, #28a745, #20c997); width: 100%; }
    .divider { text-align: center; margin: 16px 0; color: #adb5bd; font-size: 14px; position: relative; }
    .divider::before, .divider::after { content: ''; position: absolute; top: 50%; width: 45%; height: 1px; background: #e9ecef; }
    .divider::before { left: 0; } .divider::after { right: 0; }
    @media(max-width:480px) { .form-row { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
<?php require_once 'includes/navbar.php'; ?>

<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-hdr">
      <img src="assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <h1>Create Account</h1>
      <p>Join VelTech EventPass — book &amp; manage event tickets</p>
    </div>
    <div class="auth-body">

      <?php if (!empty($errors)): ?>
      <div class="alert alert-danger" role="alert">
        <?php foreach ($errors as $err): ?>
          <div>⚠ <?= $err ?></div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <form method="POST" novalidate>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Full Name *</label>
            <input type="text" name="name" class="form-control" placeholder="Your full name"
              value="<?= htmlspecialchars($formData['name'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">Phone Number *</label>
            <input type="tel" name="phone" class="form-control" placeholder="9876543210"
              value="<?= htmlspecialchars($formData['phone'] ?? '') ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Email Address *</label>
          <input type="email" name="email" class="form-control" placeholder="your@email.com"
            value="<?= htmlspecialchars($formData['email'] ?? '') ?>" required>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Department</label>
            <select name="department" class="form-control">
              <option value="">Select Department</option>
              <?php
              $depts = ['Computer Science','Electronics & Communication','Electrical & Electronics',
                        'Mechanical Engineering','Civil Engineering','Information Technology',
                        'Artificial Intelligence','Data Science','Management','Law','Arts & Science','Other'];
              foreach ($depts as $d):
                $sel = ($formData['dept'] ?? '') === $d ? 'selected' : '';
              ?>
              <option value="<?= htmlspecialchars($d) ?>" <?= $sel ?>><?= htmlspecialchars($d) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Roll Number</label>
            <input type="text" name="roll_number" class="form-control" placeholder="22CSE001"
              value="<?= htmlspecialchars($formData['roll'] ?? '') ?>">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Password *</label>
          <div class="pw-wrap">
            <input type="password" id="pw" name="password" class="form-control"
              placeholder="Min. 8 characters" required>
            <button type="button" class="pw-eye" onclick="togglePw('pw',this)">👁</button>
          </div>
          <div class="bar" id="pwBar"></div>
          <div id="pwTxt" style="font-size:11px;color:#888;margin-top:2px"></div>
        </div>

        <div class="form-group">
          <label class="form-label">Confirm Password *</label>
          <div class="pw-wrap">
            <input type="password" id="pw2" name="confirm_password" class="form-control"
              placeholder="Re-enter password" required>
            <button type="button" class="pw-eye" onclick="togglePw('pw2',this)">👁</button>
          </div>
          <div id="matchTxt" style="font-size:11px;margin-top:2px"></div>
        </div>

        <div style="background:#f8f9fa;border-radius:8px;padding:10px 13px;font-size:12px;color:#6c757d;margin-bottom:14px;border:1px solid #e9ecef;">
          🔒 Your data is used only for event booking at Vel Tech University.
        </div>

        <button type="submit" class="btn btn-primary btn-full" style="font-size:15px;padding:13px">
          Create Account →
        </button>
      </form>

      <div class="divider">or</div>
      <p style="text-align:center;font-size:14px">
        Already have an account?
        <a href="login.php" style="color:#2c3e50;font-weight:600;text-decoration:none;">Sign In</a>
      </p>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>

<script>
function togglePw(id, btn) {
  const el = document.getElementById(id);
  el.type = el.type === 'password' ? 'text' : 'password';
  btn.textContent = el.type === 'password' ? '👁' : '🙈';
}

document.getElementById('pw').addEventListener('input', function() {
  const v = this.value;
  const bar = document.getElementById('pwBar');
  const txt = document.getElementById('pwTxt');
  let s = 0;
  if (v.length >= 8) s++;
  if (/[A-Z]/.test(v)) s++;
  if (/[0-9]/.test(v)) s++;
  if (/[^A-Za-z0-9]/.test(v)) s++;
  if (s <= 1) { bar.className = 'bar w'; txt.textContent = 'Weak — add uppercase, numbers, symbols'; txt.style.color = '#f44336'; }
  else if (s <= 2) { bar.className = 'bar m'; txt.textContent = 'Medium'; txt.style.color = '#ff9800'; }
  else { bar.className = 'bar s'; txt.textContent = 'Strong ✓'; txt.style.color = '#4caf50'; }
  checkMatch();
});

document.getElementById('pw2').addEventListener('input', checkMatch);

function checkMatch() {
  const p1 = document.getElementById('pw').value;
  const p2 = document.getElementById('pw2').value;
  const el = document.getElementById('matchTxt');
  if (!p2) { el.textContent = ''; return; }
  if (p1 === p2) { el.textContent = '✓ Passwords match'; el.style.color = '#4caf50'; }
  else           { el.textContent = '✗ Passwords do not match'; el.style.color = '#f44336'; }
}
</script>
</body>
</html>
