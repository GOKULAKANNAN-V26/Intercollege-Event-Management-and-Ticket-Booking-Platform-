<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (!empty($_SESSION['admin_id'])) {
    header('Location: admin/dashboard.php'); exit;
}
if (!empty($_SESSION['user_id'])) {
    header('Location: index.php'); exit;
}

$error   = '';
$success = '';

// Timeout message
if (!empty($_GET['timeout'])) $error = 'Your session expired. Please sign in again.';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');
    $password   = $_POST['password'] ?? '';
    $redirect   = trim($_POST['redirect'] ?? 'index.php');

    // Basic sanitize redirect
    if (!preg_match('/^[a-zA-Z0-9\-_.\/]+\.php(\?[^<>"]*)?$/', $redirect)) {
        $redirect = 'index.php';
    }

    if (empty($identifier) || empty($password)) {
        $error = 'Please enter your email/username and password.';
    } else {
        try {
            $conn = getDBConnection();

            // Try admin login first by username
            $stmt = $conn->prepare("SELECT id, username, password_hash FROM admins WHERE username = ?");
            $stmt->bind_param('s', $identifier);
            $stmt->execute();
            $admin = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($admin && password_verify($password, $admin['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id']   = $admin['id'];
                $_SESSION['admin_user'] = $admin['username'];
                $_SESSION['admin_ts']   = time();

                $stmt = $conn->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?");
                $stmt->bind_param('i', $admin['id']);
                $stmt->execute();
                $stmt->close();

                session_write_close();
                header('Location: ' . APP_URL . '/admin/dashboard.php');
                exit;
            }

            // If the identifier looks like an email, attempt user login
            if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
                $stmt = $conn->prepare(
                    "SELECT id, name, email, phone, password_hash FROM users WHERE email = ?"
                );
                $stmt->bind_param('s', $identifier);
                $stmt->execute();
                $result = $stmt->get_result();
                $user   = $result->fetch_assoc();
                $stmt->close();

                if ($user && password_verify($password, $user['password_hash'])) {
                    session_regenerate_id(true);
                    $_SESSION['user_id']    = $user['id'];
                    $_SESSION['user_name']  = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_phone'] = $user['phone'];
                    $_SESSION['user_ts']    = time();
                    session_write_close();
                    header('Location: ' . $redirect);
                    exit;
                }
            }

            $error = 'Invalid credentials. Use your registered email for user login or admin username for admin login.';
        } catch (Exception $e) {
            $error = 'Login failed. Please try again.';
        }
    }
}

$redirect = htmlspecialchars($_GET['redirect'] ?? 'index.php');
session_write_close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In – VelTech EventPass</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    .auth-wrap { max-width:440px; margin:40px auto; padding:0 16px 40px; }
    .auth-card { background:#fff; border-radius:16px; overflow:hidden; box-shadow:0 20px 40px rgba(0,0,0,0.1); border:1px solid rgba(255,255,255,0.2); }
    .auth-header { background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%); color:#fff; padding:32px 30px; text-align:center; position:relative; }
    .auth-header::before { content:''; position:absolute; top:0; left:0; right:0; bottom:0; background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%); }
    .auth-header > * { position:relative; z-index:1; }
    .auth-header img { height:52px; filter: brightness(0) invert(1); margin-bottom:12px; }
    .auth-header h1 { font-size:24px; font-weight:700; margin-bottom:6px; letter-spacing:-0.5px; }
    .auth-header p { font-size:14px; opacity:.9; font-weight:400; }
    .auth-body { padding:32px 30px; }
    .pw-wrap { position:relative; }
    .pw-toggle { position:absolute; right:14px; top:50%; transform:translateY(-50%); background:none; border:none; cursor:pointer; font-size:18px; color:#6c757d; transition:color 0.2s; }
    .pw-toggle:hover { color:#495057; }
    .divider { text-align:center; margin:18px 0; color:#adb5bd; font-size:14px; position:relative; }
    .divider::before,.divider::after { content:''; position:absolute; top:50%; width:45%; height:1px; background:#e9ecef; }
    .divider::before { left:0; } .divider::after { right:0; }
  </style>
</head>
<body>
<?php require_once 'includes/navbar.php'; ?>

<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-header">
      <img src="assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <h1>Welcome Back</h1>
      <p>Sign in to VelTech EventPass to manage your bookings</p>
    </div>
    <div class="auth-body">

      <?php if ($redirect === 'index.php'): ?>
      <div class="alert alert-info" role="status">
        ℹ️ Please sign in as a student/user to view upcoming events.
      </div>
      <?php endif; ?>

      <?php if ($error): ?>
      <div class="alert alert-danger" role="alert">⚠ <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <?php if (!empty($_GET['registered'])): ?>
      <div class="alert alert-success" role="alert">
        ✅ Account created! Please sign in.
      </div>
      <?php endif; ?>

      <form method="POST" novalidate>
        <input type="hidden" name="redirect" value="<?= $redirect ?>">

        <div class="form-group">
          <label class="form-label" for="identifier">Email or Admin Username</label>
          <input type="text" id="identifier" name="identifier" class="form-control"
            placeholder="your@email.com or admin username" required
            value="<?= htmlspecialchars($_POST['identifier'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <div class="pw-wrap">
            <input type="password" id="password" name="password" class="form-control"
              placeholder="••••••••" required autocomplete="current-password">
            <button type="button" class="pw-toggle" onclick="togglePw()">👁</button>
          </div>
        </div>

      <div style="text-align:right;margin-bottom:16px">
          <a href="support.php?category=password" style="font-size:13px;color:#2c3e50;font-weight:500;text-decoration:none;">
            Forgot password?
          </a>
        </div>

        <button type="submit" class="btn btn-primary btn-full" style="font-size:15px;padding:13px">
          Sign In →
        </button>
      </form>

      <div class="divider">or</div>
      <p style="text-align:center;font-size:14px">
        New to EventPass?
        <a href="register.php" style="color:#2c3e50;font-weight:600;text-decoration:none;">Create Account</a>
      </p>

      <div style="background:#f8f9fa;border-radius:8px;padding:12px 14px;font-size:12px;color:#6c757d;margin-top:16px;text-align:center;border:1px solid #e9ecef;">
        🎓 For Vel Tech students, staff &amp; faculty only.<br>
        Need help? <a href="support.php" style="color:#2c3e50;font-weight:500;text-decoration:none;">Contact Support</a>
      </div>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>

<script>
function togglePw() {
  const el = document.getElementById('password');
  el.type = el.type === 'password' ? 'text' : 'password';
}
</script>
</body>
</html>
