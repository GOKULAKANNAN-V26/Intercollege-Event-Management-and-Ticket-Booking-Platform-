# 🔓 OTP Testing Guide - Development Mode

## ✅ What I Fixed

Your OTP system now **shows the OTP code directly on screen** in development mode!

### Changes Made:

1. **Backend (`includes/OTPService.php`):**
   - Now returns OTP in response when `APP_ENV = 'development'`
   - Always shows OTP for testing, regardless of SMS sending status

2. **Frontend (`assets/js/app.js`):**
   - Displays OTP in a green alert box
   - Auto-fills the OTP input fields
   - Shows OTP in browser console
   - Works for both "Send OTP" and "Resend OTP"

---

## 🎯 How to Test OTP Now

### Step 1: Make Sure Development Mode is ON

Check `config/config.php` line 7:
```php
define('APP_ENV', 'development'); // ✅ Should be 'development'
```

### Step 2: Book a Ticket

1. Go to: `http://localhost/college-ticket-booking/`
2. Click **"Book Tickets"** on any event
3. Fill in the form:
   - Name: Your name
   - Email: your@email.com
   - Phone: 9876543210
   - Tickets: 1

4. Click **"Send OTP"**

### Step 3: See the OTP!

You'll now see **3 places** where the OTP appears:

#### 1. **Green Alert Box** (Most Visible)
```
🔓 DEVELOPMENT MODE: Your OTP is 1234
```

#### 2. **Auto-filled in Input Boxes**
The 4 OTP digit boxes will be automatically filled!

#### 3. **Browser Console** (F12)
```
🔓 DEV MODE - OTP: 1234
```

### Step 4: Verify OTP

The OTP is already filled in! Just click **"Verify OTP"** button.

---

## 📸 What You'll See

### Before (Old Behavior):
```
✅ OTP sent successfully
[Empty OTP boxes]
[No OTP shown anywhere]
```

### After (New Behavior):
```
✅ OTP sent successfully

🔓 DEVELOPMENT MODE: Your OTP is 1234
[OTP boxes auto-filled: 1 2 3 4]
```

---

## 🔄 Testing Resend OTP

1. After sending OTP, wait for cooldown (60 seconds)
2. Click **"Resend OTP"**
3. **New OTP will be shown** in the same green alert box
4. OTP boxes will be **auto-filled with new OTP**

---

## 🚀 Production Mode (When Going Live)

When you're ready to deploy:

### Step 1: Configure MSG91

1. Get your MSG91 API key from: https://msg91.com/user/api
2. Update `config/config.php`:
   ```php
   define('MSG91_API_KEY', 'YOUR_REAL_API_KEY');
   define('MSG91_SENDER_ID', 'EVENTP'); // Must be approved by MSG91
   ```

### Step 2: Switch to Production Mode

In `config/config.php` line 7:
```php
define('APP_ENV', 'production'); // Change from 'development'
```

### Step 3: Test with Real Phone

1. Book a ticket with your real phone number
2. OTP will be sent via SMS (no longer shown on screen)
3. Enter the OTP you receive via SMS
4. Complete booking

---

## 🔍 Troubleshooting

### Issue: OTP still not showing

**Solution 1: Clear Browser Cache**
```
Press Ctrl + Shift + R (Windows)
or Cmd + Shift + R (Mac)
```

**Solution 2: Check Browser Console**
```
Press F12 → Console tab
Look for: 🔓 DEV MODE - OTP: 1234
```

**Solution 3: Check Response**
```
Press F12 → Network tab
Click "send_otp.php"
Look for: "otp_dev": "1234"
```

### Issue: OTP boxes not auto-filling

**Solution:** The OTP is still shown in the green alert box. Just copy it manually.

### Issue: "OTP sent successfully" but no green alert

**Solution:** 
1. Make sure `APP_ENV` is set to `'development'`
2. Clear browser cache (Ctrl + Shift + R)
3. Check browser console for the OTP

---

## 📝 Example Test Flow

```
1. Open: http://localhost/college-ticket-booking/
2. Click "Book Tickets"
3. Fill form → Click "Send OTP"
4. See green alert: "🔓 DEVELOPMENT MODE: Your OTP is 1234"
5. OTP boxes auto-filled: [1] [2] [3] [4]
6. Click "Verify OTP"
7. Proceed to payment
8. Complete booking!
```

---

## 🎉 Summary

✅ **Development Mode:** OTP shown on screen + auto-filled  
✅ **Production Mode:** OTP sent via SMS (when MSG91 configured)  
✅ **Works for:** Send OTP and Resend OTP  
✅ **Visible in:** Alert box, input fields, and console  

**You can now test OTP without needing SMS!** 🚀

---

## 💡 Tips

1. **Keep development mode ON** while testing locally
2. **Switch to production mode** only when deploying to live server
3. **Test with real phone** before going live to verify MSG91 works
4. **Check logs** at `logs/error.log` if issues occur

---

## 🔐 Security Note

The OTP is only shown when:
- `APP_ENV = 'development'` in config
- Running on localhost

In production mode:
- OTP is never shown on screen
- OTP is only sent via SMS
- More secure for real users

---

**Happy Testing! 🎉**
