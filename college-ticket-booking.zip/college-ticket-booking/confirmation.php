<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/BookingService.php';

$bookingId = trim($_GET['id'] ?? '');

if (empty($bookingId)) {
    header('Location: index.php');
    exit;
}

// Sanitize
$bookingId = preg_replace('/[^A-Z0-9]/', '', strtoupper($bookingId));
$booking = BookingService::getConfirmedBooking($bookingId);

if (!$booking) {
    header('Location: index.php');
    exit;
}

$eventDate = date('D, d M Y', strtotime($booking['event_date']));
$eventTime = date('h:i A', strtotime($booking['event_date']));
$confirmedAt = date('d M Y, h:i A', strtotime($booking['confirmed_at']));
$total = '₹' . number_format($booking['total_amount'], 2);
$receiptUrl = APP_URL . '/' . ($booking['receipt_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Booking Confirmed – <?= htmlspecialchars($booking['booking_id']) ?> | VelTech EventPass</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    .vt-header-bar {
      background: #003087;
      padding: 6px 20px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .vt-header-bar img { height: 32px; filter: brightness(0) invert(1); }
    .vt-header-bar span { color: #FFD700; font-size: 11px; font-weight: 600; letter-spacing: 0.5px; }
  </style>
</head>
<body>

<nav class="navbar">
  <div class="navbar-inner">
    <a href="index.php" class="navbar-brand">
      <img src="assets/images/veltech-logo.svg" alt="Vel Tech Logo" style="height:40px">
      <span style="font-size:16px;font-weight:700;color:#003087">EventPass</span>
    </a>
    <div class="navbar-links">
      <a href="index.php">← Back to Events</a>
    </div>
  </div>
</nav>

<div class="confirmation-wrap">
  <div class="confirmation-card">
    <div class="confirmation-header">
      <div style="margin-bottom:12px">
        <img src="assets/images/veltech-logo.svg" alt="Vel Tech" style="height:44px;filter:brightness(0) invert(1)">
      </div>
      <div class="confirmation-icon" aria-hidden="true">✓</div>
      <h1 style="font-size:26px;margin-bottom:8px">Booking Confirmed!</h1>
      <p style="opacity:.85">Your tickets have been reserved successfully</p>
      <p style="font-size:11px;opacity:.7;margin-top:6px">VelTech EventPass · Vel Tech R&amp;D Institute</p>
    </div>

    <div class="confirmation-body">
      <!-- Booking ID -->
      <div style="text-align:center;background:#f8f9ff;border:2px dashed #6c63ff;border-radius:10px;padding:16px;margin-bottom:24px">
        <p style="font-size:12px;color:#888;margin-bottom:4px">BOOKING ID</p>
        <p style="font-size:24px;font-weight:800;color:#6c63ff;letter-spacing:2px">
          <?= htmlspecialchars($booking['booking_id']) ?>
        </p>
        <p style="font-size:12px;color:#888;margin-top:4px">Confirmed on <?= $confirmedAt ?></p>
      </div>

      <!-- Event Details -->
      <h3 style="font-size:13px;text-transform:uppercase;color:#888;letter-spacing:1px;margin-bottom:12px">
        Event Details
      </h3>
      <div class="detail-row">
        <span class="key">Event</span>
        <span class="val"><?= htmlspecialchars($booking['event_name']) ?></span>
      </div>
      <div class="detail-row">
        <span class="key">Department</span>
        <span class="val"><?= htmlspecialchars($booking['department']) ?></span>
      </div>
      <div class="detail-row">
        <span class="key">Date</span>
        <span class="val"><?= $eventDate ?></span>
      </div>
      <div class="detail-row">
        <span class="key">Time</span>
        <span class="val"><?= $eventTime ?></span>
      </div>
      <div class="detail-row">
        <span class="key">Venue</span>
        <span class="val"><?= htmlspecialchars($booking['venue']) ?></span>
      </div>

      <!-- Attendee Details -->
      <h3 style="font-size:13px;text-transform:uppercase;color:#888;letter-spacing:1px;margin:20px 0 12px">
        Attendee Details
      </h3>
      <div class="detail-row">
        <span class="key">Name</span>
        <span class="val"><?= htmlspecialchars($booking['user_name']) ?></span>
      </div>
      <div class="detail-row">
        <span class="key">Email</span>
        <span class="val"><?= htmlspecialchars($booking['user_email']) ?></span>
      </div>
      <div class="detail-row">
        <span class="key">Phone</span>
        <span class="val"><?= htmlspecialchars($booking['user_phone']) ?></span>
      </div>

      <!-- Payment Details -->
      <h3 style="font-size:13px;text-transform:uppercase;color:#888;letter-spacing:1px;margin:20px 0 12px">
        Payment Details
      </h3>
      <div class="detail-row">
        <span class="key">Tickets</span>
        <span class="val"><?= (int)$booking['ticket_count'] ?></span>
      </div>
      <div class="detail-row">
        <span class="key">Payment ID</span>
        <span class="val" style="font-size:12px"><?= htmlspecialchars($booking['payment_id']) ?></span>
      </div>
      <div class="detail-row" style="background:#f8f9ff;border-radius:8px;padding:12px 0;margin-top:8px">
        <span class="key" style="font-size:16px;font-weight:700;padding-left:12px">Total Paid</span>
        <span class="val" style="font-size:22px;font-weight:800;color:#6c63ff;padding-right:12px"><?= $total ?></span>
      </div>

      <!-- Actions -->
      <div style="display:flex;gap:12px;margin-top:24px;flex-wrap:wrap">
        <?php if ($booking['receipt_path']): ?>
        <a href="<?= htmlspecialchars($booking['receipt_path']) ?>" target="_blank"
           class="btn btn-primary" style="flex:1;justify-content:center;text-decoration:none">
          📄 View Receipt
        </a>
        <?php endif; ?>
        <a href="index.php" class="btn btn-outline" style="flex:1;justify-content:center;text-decoration:none">
          🎟 Book More
        </a>
      </div>

      <p style="text-align:center;font-size:12px;color:#888;margin-top:16px">
        A confirmation has been sent to <strong><?= htmlspecialchars($booking['user_email']) ?></strong>
        and your WhatsApp.
      </p>
    </div>
  </div>
</div>

<footer>
  <p>
    <img src="assets/images/veltech-logo.svg" alt="Vel Tech" style="height:24px;vertical-align:middle;margin-right:6px">
    © <?= date('Y') ?> <strong>VelTech EventPass</strong> – Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute
  </p>
  <p style="margin-top:4px">For support: support@veltech.edu.in</p>
</footer>

</body>
</html>
