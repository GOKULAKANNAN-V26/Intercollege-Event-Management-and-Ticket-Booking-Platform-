<?php
/**
 * Quick Test Script for Support Tickets and Payment
 * Run this to verify both functions work
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

echo "<h1>Testing Support Ticket & Payment Fixes</h1>";
echo "<hr>";

// Test 1: Database Connection
echo "<h2>Test 1: Database Connection</h2>";
try {
    $conn = getDBConnection();
    echo "✅ Database connected successfully<br>";
} catch (Exception $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "<br>";
    exit;
}

// Test 2: Support Tickets Table
echo "<h2>Test 2: Support Tickets Table</h2>";
try {
    $result = $conn->query("DESCRIBE support_tickets");
    if ($result) {
        echo "✅ support_tickets table exists<br>";
        echo "<details><summary>Show columns</summary><pre>";
        while ($row = $result->fetch_assoc()) {
            echo $row['Field'] . " - " . $row['Type'] . "\n";
        }
        echo "</pre></details>";
    }
} catch (Exception $e) {
    echo "❌ Error checking support_tickets: " . $e->getMessage() . "<br>";
}

// Test 3: Create Test Support Ticket
echo "<h2>Test 3: Create Test Support Ticket</h2>";
try {
    $ticketId = 'TEST' . time();
    $stmt = $conn->prepare(
        "INSERT INTO support_tickets
         (ticket_id, user_name, user_email, user_phone, booking_id, subject, category, message, status, created_at)
         VALUES (?, 'Test User', 'test@test.com', '9876543210', '', 'Test Subject', 'technical', 'Test message', 'open', NOW())"
    );
    $stmt->bind_param('s', $ticketId);
    
    if ($stmt->execute()) {
        $insertId = $stmt->insert_id;
        echo "✅ Test ticket created successfully! ID: $ticketId<br>";
        
        // Clean up
        $conn->query("DELETE FROM support_tickets WHERE id = $insertId");
        echo "✅ Test ticket cleaned up<br>";
    } else {
        echo "❌ Failed to create test ticket: " . $stmt->error . "<br>";
    }
    $stmt->close();
} catch (Exception $e) {
    echo "❌ Exception creating test ticket: " . $e->getMessage() . "<br>";
}

// Test 4: Payments Table
echo "<h2>Test 4: Payments Table</h2>";
try {
    $result = $conn->query("DESCRIBE payments");
    if ($result) {
        echo "✅ payments table exists<br>";
        echo "<details><summary>Show columns</summary><pre>";
        while ($row = $result->fetch_assoc()) {
            echo $row['Field'] . " - " . $row['Type'] . "\n";
        }
        echo "</pre></details>";
    }
} catch (Exception $e) {
    echo "❌ Error checking payments: " . $e->getMessage() . "<br>";
}

// Test 5: Test Payment Insert (without Razorpay)
echo "<h2>Test 5: Test Payment Record Insert</h2>";
try {
    $testOrderId = 'order_TEST' . time();
    $testBookingRef = 'BK_TEST' . time();
    $amount = 100.50;
    
    $stmt = $conn->prepare(
        "INSERT INTO payments (razorpay_order_id, booking_ref, amount, currency, status, created_at)
         VALUES (?, ?, ?, 'INR', 'CREATED', NOW())"
    );
    $stmt->bind_param('ssd', $testOrderId, $testBookingRef, $amount);
    
    if ($stmt->execute()) {
        $insertId = $stmt->insert_id;
        echo "✅ Test payment record created successfully!<br>";
        echo "   Order ID: $testOrderId<br>";
        echo "   Amount: ₹$amount<br>";
        
        // Clean up
        $conn->query("DELETE FROM payments WHERE id = $insertId");
        echo "✅ Test payment record cleaned up<br>";
    } else {
        echo "❌ Failed to create test payment: " . $stmt->error . "<br>";
    }
    $stmt->close();
} catch (Exception $e) {
    echo "❌ Exception creating test payment: " . $e->getMessage() . "<br>";
}

// Test 6: Razorpay Configuration
echo "<h2>Test 6: Razorpay Configuration</h2>";
if (defined('RAZORPAY_KEY_ID') && !empty(RAZORPAY_KEY_ID)) {
    echo "✅ RAZORPAY_KEY_ID is configured: " . substr(RAZORPAY_KEY_ID, 0, 10) . "...<br>";
    
    if (RAZORPAY_KEY_ID === 'rzp_test_SlPoCiiwiPBArC') {
        echo "⚠️ Using default test key. Update with your own key for production.<br>";
    }
} else {
    echo "❌ RAZORPAY_KEY_ID not configured<br>";
}

if (defined('RAZORPAY_KEY_SECRET') && !empty(RAZORPAY_KEY_SECRET)) {
    echo "✅ RAZORPAY_KEY_SECRET is configured<br>";
} else {
    echo "❌ RAZORPAY_KEY_SECRET not configured<br>";
}

// Test 7: Check for common issues
echo "<h2>Test 7: Common Issues Check</h2>";

// Check if events table has registration_type column
try {
    $result = $conn->query("SHOW COLUMNS FROM events LIKE 'registration_type'");
    if ($result && $result->num_rows > 0) {
        echo "✅ events.registration_type column exists<br>";
    } else {
        echo "⚠️ events.registration_type column missing (not critical)<br>";
    }
} catch (Exception $e) {
    echo "⚠️ Could not check events.registration_type<br>";
}

// Check if confirmed_bookings has all required columns
try {
    $requiredColumns = ['team_name', 'team_members', 'qr_code_path', 'checked_in', 'checked_in_at', 'refund_status', 'refund_amount'];
    $result = $conn->query("DESCRIBE confirmed_bookings");
    $existingColumns = [];
    while ($row = $result->fetch_assoc()) {
        $existingColumns[] = $row['Field'];
    }
    
    $missingColumns = array_diff($requiredColumns, $existingColumns);
    if (empty($missingColumns)) {
        echo "✅ confirmed_bookings has all required columns<br>";
    } else {
        echo "⚠️ confirmed_bookings missing columns: " . implode(', ', $missingColumns) . "<br>";
        echo "   Run: database/UPDATE_DATABASE.sql<br>";
    }
} catch (Exception $e) {
    echo "⚠️ Could not check confirmed_bookings columns<br>";
}

echo "<hr>";
echo "<h2>Summary</h2>";
echo "<p>If all tests passed ✅, your system is ready!</p>";
echo "<p>If any tests failed ❌, check the error messages above.</p>";
echo "<hr>";
echo "<p><strong>Next Steps:</strong></p>";
echo "<ol>";
echo "<li>Try submitting a support ticket: <a href='support.php'>support.php</a></li>";
echo "<li>Try booking a ticket and completing payment</li>";
echo "<li>Delete this file before going to production: <code>test_fixes.php</code></li>";
echo "</ol>";
?>
