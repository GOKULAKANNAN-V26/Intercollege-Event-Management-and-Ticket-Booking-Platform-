<?php
require_once __DIR__ . '/config/config.php';
$phone = '919876543210';
$message = 'Test MSG91 from EventPass';
$params = [
    'authkey'  => MSG91_API_KEY,
    'mobiles'  => $phone,
    'message'  => $message,
    'sender'   => MSG91_SENDER_ID,
    'route'    => '4',
    'country'  => '91',
    'response' => 'json'
];
$url = MSG91_API_URL . '?' . http_build_query($params);
$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_USERAGENT      => 'EventPass-Test/1.0'
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);
echo "URL={$url}\nHTTP={$httpCode}\nERR={$curlError}\nRESP={$response}\n";
