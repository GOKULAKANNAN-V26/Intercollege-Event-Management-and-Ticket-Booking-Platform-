# 🔧 MSG91 OTP Integration - Setup Guide

## ✅ What Was Fixed
The backend OTP service has been updated to use **MSG91 API** instead of the incorrect Twilio integration.

## 📋 Setup Steps

### Step 1: Get MSG91 Credentials
1. Go to https://www.msg91.com
2. Sign up or log in to your account
3. Navigate to **Settings → API Keys** (or **Dashboard → API**)
4. Copy your **API Key** (also called Auth Key)
5. Note your **Sender ID** (must be approved - contact MSG91 support if needed)

### Step 2: Update Configuration
Edit `config/config.php` and add your credentials:

```php
// MSG91 SMS Configuration
define('MSG91_API_KEY', 'YOUR_MSG91_API_KEY'); // ← Replace with your API key
define('MSG91_SENDER_ID', 'EVENTAPP');        // ← Replace with your approved sender ID
define('MSG91_ROUTE', '4');                   // 4 = Transactional (for OTP)
define('MSG91_API_URL', 'https://api.msg91.com/api/sendhttp.php');
```

### Step 3: Approve Sender ID (Important!)
⚠️ **MSG91 requires an approved Sender ID:**
1. In MSG91 Dashboard → Settings → Sender IDs
2. Add your sender ID (e.g., "EVENTAPP" or your college name)
3. Wait for approval (usually 2-4 hours for India)
4. Update `MSG91_SENDER_ID` with the approved ID once confirmed

### Step 4: Switch to Production Mode
Once everything is working:
- Edit `config/config.php`
- Change: `define('APP_ENV', 'production');`

## 🧪 Testing

### Test Mode (Development)
1. Keep `APP_ENV = 'development'` in config.php
2. The system will still show the OTP in development mode
3. Check browser console for: `Development OTP: XXXX`

### Production Mode
1. Set `APP_ENV = 'production'`
2. OTP will be sent ONLY via MSG91 SMS
3. No OTP displayed in browser console
4. Email fallback still available if SMS fails

## 📱 OTP Flow
```
User enters phone → Backend generates OTP → MSG91 sends SMS → User receives SMS
                                              ↓
                                        (if SMS fails) → Email fallback
```

## 🔍 Debugging

### Check logs:
- Error log: `logs/error.log`
- Look for MSG91 errors or delivery failures

### Test SMS manually:
Use this curl command to verify MSG91 is working:
```bash
curl "https://api.msg91.com/api/sendhttp.php?authkey=YOUR_API_KEY&mobiles=919876543210&message=Test&sender=EVENTAPP&route=4&response=json"
```

### Common Issues:

| Issue | Solution |
|-------|----------|
| "API Key invalid" | Check API key in MSG91 dashboard |
| SMS not delivered | Verify sender ID is approved |
| Wrong phone number | System auto-detects +91 country code for 10-digit numbers |
| "Too many requests" | OTP rate limiting is active (max 5 per 10 mins) |

## 📞 MSG91 Support
- Documentation: https://www.msg91.com/api
- Support: https://www.msg91.com/support

## 🔗 Frontend Configuration
The MSG91 widget in your frontend (index.php) uses:
- **widgetId**: `366564734b65373038303032`
- **tokenAuth**: `513951TEA34qlnAx069f8f158P1`

This is for the **widget-based OTP entry**. If users prefer manual OTP entry, they can skip the widget and type the code themselves.

## ✨ After Integration Works
1. Users receive SMS with OTP instantly
2. They can enter OTP manually OR use MSG91 widget
3. System automatically retries with email if SMS fails
4. All OTP attempts are logged for audit trail
