<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['user_id'])) {
    session_write_close();
    header('Location: login.php?redirect=modify-booking.php');
    exit;
}

$bookingId = trim($_GET['booking_id'] ?? '');
if (empty($bookingId)) {
    header('Location: my-bookings.php');
    exit;
}

$userEmail = $_SESSION['user_email'];

// Get booking details
$conn = getDBConnection();
$stmt = $conn->prepare(
    "SELECT cb.*, e.name AS event_name, e.venue, e.event_date, e.department, e.ticket_price
     FROM confirmed_bookings cb
     JOIN events e ON cb.event_id = e.id
     WHERE cb.booking_id = ? AND cb.user_email = ?"
);
$stmt->bind_param('ss', $bookingId, $userEmail);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    session_write_close();
    header('Location: my-bookings.php');
    exit;
}

// Check if event is in the past
$isPast = strtotime($booking['event_date']) < time();
$canModify = ($booking['status'] === 'PAID' || $booking['status'] === 'CONFIRMED') && !$isPast;

// Handle form submission
$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $canModify) {
    $newName = trim($_POST['name'] ?? '');
    $newPhone = trim($_POST['phone'] ?? '');
    $newTeamName = trim($_POST['team_name'] ?? '');
    $newTeamMembers = trim($_POST['team_members'] ?? '');
    
    if (empty($newName) || empty($newPhone)) {
        $error = 'Name and phone are required.';
    } else {
        // Update booking
        $stmt = $conn->prepare(
            "UPDATE confirmed_bookings 
             SET user_name = ?, user_phone = ?, team_name = ?, team_members = ?
             WHERE booking_id = ? AND user_email = ?"
        );
        $stmt->bind_param('ssssss', $newName, $newPhone, $newTeamName, $newTeamMembers, $bookingId, $userEmail);
        
        if ($stmt->execute()) {
            $success = true;
            // Refresh booking data
            $booking['user_name'] = $newName;
            $booking['user_phone'] = $newPhone;
            $booking['team_name'] = $newTeamName;
            $booking['team_members'] = $newTeamMembers;
        } else {
            $error = 'Failed to update booking. Please try again.';
        }
        $stmt->close();
    }
}

session_write_close();

$eventDate = date('D, d M Y', strtotime($booking['event_date']));
$eventTime = date('h:i A', strtotime($booking['event_date']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Modify Booking – VelTech EventPass</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body { background:#f4f6fb; }
    .page-wrap { max-width:700px; margin:30px auto; padding:0 16px 40px; }
    .page-title { font-size:22px; font-weight:800; color:#003087; margin-bottom:20px; }
    .card { background:#fff; border-radius:12px; padding:24px; box-shadow:0 2px 12px rgba(0,48,135,0.08); margin-bottom:20px; }
    .event-info { background:#f8f9ff; border-radius:8px; padding:16px; margin-bottom:20px; }
    .event-info h3 { font-size:16px; font-weight:700; color:#003087; margin-bottom:8px; }
    .event-info p { font-size:13px; color:#666; margin:4px 0; }
    .form-group { margin-bottom:16px; }
    .form-group label { display:block; font-size:13px; font-weight:600; color:#333; margin-bottom:6px; }
    .form-group input, .form-group textarea { width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:8px; font-size:14px; }
    .form-group textarea { min-height:80px; resize:vertical; font-family:inherit; }
    .form-group small { display:block; font-size:12px; color:#888; margin-top:4px; }
    .alert { padding:12px 16px; border-radius:8px; margin-bottom:16px; }
    .alert-success { background:#e8f5e9; color:#2e7d32; border:1px solid #a5d6a7; }
    .alert-error { background:#fce4ec; color:#c62828; border:1px solid #f48fb1; }
    .alert-warning { background:#fff3e0; color:#e65100; border:1px solid #ffcc80; }
    .btn-group { display:flex; gap:12px; margin-top:20px; }
    .btn-group .btn { flex:1; justify-content:center; }
  </style>
</head>
<body>
<?php require_once 'includes/navbar.php'; ?>

<div class="page-wrap">
  <h1 class="page-title">✏️ Modify Booking</h1>

  <div class="card">
    <?php if ($success): ?>
    <div class="alert alert-success">
      ✅ Booking updated successfully! Your changes have been saved.
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-error">
      ⚠️ <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <?php if (!$canModify): ?>
    <div class="alert alert-warning">
      ⚠️ This booking cannot be modified. <?= $isPast ? 'The event has already passed.' : 'Only confirmed bookings can be modified.' ?>
    </div>
    <?php endif; ?>

    <div class="event-info">
      <h3><?= htmlspecialchars($booking['event_name']) ?></h3>
      <p>📅 <?= $eventDate ?> at <?= $eventTime ?></p>
      <p>📍 <?= htmlspecialchars($booking['venue']) ?></p>
      <p>🎫 Booking ID: <strong><?= htmlspecialchars($booking['booking_id']) ?></strong></p>
      <p>💰 Amount: <strong>₹<?= number_format($booking['total_amount'], 2) ?></strong></p>
    </div>

    <?php if ($canModify): ?>
    <form method="POST" action="">
      <div class="form-group">
        <label for="name">Full Name *</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($booking['user_name']) ?>" required>
        <small>Update the name of the primary attendee</small>
      </div>

      <div class="form-group">
        <label for="phone">Phone Number *</label>
        <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($booking['user_phone']) ?>" required pattern="[0-9]{10}">
        <small>10-digit mobile number for contact</small>
      </div>

      <div class="form-group">
        <label for="team_name">Team Name (Optional)</label>
        <input type="text" id="team_name" name="team_name" value="<?= htmlspecialchars($booking['team_name'] ?? '') ?>">
        <small>If this is a team booking, update the team name</small>
      </div>

      <div class="form-group">
        <label for="team_members">Team Members (Optional)</label>
        <textarea id="team_members" name="team_members"><?= htmlspecialchars($booking['team_members'] ?? '') ?></textarea>
        <small>One member per line or comma-separated</small>
      </div>

      <div style="background:#fff3e0;border:1px solid #ffcc80;border-radius:8px;padding:12px;margin-bottom:16px">
        <p style="font-size:13px;color:#e65100;margin:0">
          <strong>Note:</strong> You cannot change the email address, ticket count, or event. For major changes, please cancel this booking and create a new one.
        </p>
      </div>

      <div class="btn-group">
        <a href="my-bookings.php" class="btn btn-outline" style="text-decoration:none">Cancel</a>
        <button type="submit" class="btn btn-primary">💾 Save Changes</button>
      </div>
    </form>
    <?php else: ?>
    <div class="btn-group">
      <a href="my-bookings.php" class="btn btn-primary" style="text-decoration:none">← Back to My Bookings</a>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
</body>
</html>
