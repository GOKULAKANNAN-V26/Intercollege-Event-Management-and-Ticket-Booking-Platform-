-- ============================================================
-- DATABASE VERIFICATION AND FIX SCRIPT
-- Run this to ensure all tables and columns exist
-- ============================================================

USE college_events;

-- ============================================================
-- 1. VERIFY AND ADD MISSING COLUMNS TO confirmed_bookings
-- ============================================================

-- Check if team_name column exists, if not add it
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'confirmed_bookings' 
  AND COLUMN_NAME = 'team_name';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE confirmed_bookings ADD COLUMN team_name VARCHAR(255) DEFAULT NULL AFTER user_phone',
    'SELECT "team_name column already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if team_members column exists, if not add it
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'confirmed_bookings' 
  AND COLUMN_NAME = 'team_members';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE confirmed_bookings ADD COLUMN team_members TEXT DEFAULT NULL AFTER team_name',
    'SELECT "team_members column already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if qr_code_path column exists, if not add it
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'confirmed_bookings' 
  AND COLUMN_NAME = 'qr_code_path';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE confirmed_bookings ADD COLUMN qr_code_path VARCHAR(500) DEFAULT NULL AFTER receipt_path',
    'SELECT "qr_code_path column already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if checked_in column exists, if not add it
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'confirmed_bookings' 
  AND COLUMN_NAME = 'checked_in';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE confirmed_bookings ADD COLUMN checked_in TINYINT(1) NOT NULL DEFAULT 0 AFTER qr_code_path',
    'SELECT "checked_in column already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if checked_in_at column exists, if not add it
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'confirmed_bookings' 
  AND COLUMN_NAME = 'checked_in_at';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE confirmed_bookings ADD COLUMN checked_in_at DATETIME DEFAULT NULL AFTER checked_in',
    'SELECT "checked_in_at column already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if refund_status column exists, if not add it
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'confirmed_bookings' 
  AND COLUMN_NAME = 'refund_status';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE confirmed_bookings ADD COLUMN refund_status ENUM(\'none\',\'pending\',\'processed\') NOT NULL DEFAULT \'none\' AFTER checked_in_at',
    'SELECT "refund_status column already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if refund_amount column exists, if not add it
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'confirmed_bookings' 
  AND COLUMN_NAME = 'refund_amount';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE confirmed_bookings ADD COLUMN refund_amount DECIMAL(10,2) DEFAULT NULL AFTER refund_status',
    'SELECT "refund_amount column already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================
-- 2. VERIFY AND ADD MISSING COLUMNS TO pending_bookings
-- ============================================================

-- Check if team_name column exists in pending_bookings
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'pending_bookings' 
  AND COLUMN_NAME = 'team_name';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE pending_bookings ADD COLUMN team_name VARCHAR(255) DEFAULT NULL AFTER user_phone',
    'SELECT "team_name column already exists in pending_bookings" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if team_members column exists in pending_bookings
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'pending_bookings' 
  AND COLUMN_NAME = 'team_members';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE pending_bookings ADD COLUMN team_members TEXT DEFAULT NULL AFTER team_name',
    'SELECT "team_members column already exists in pending_bookings" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================
-- 3. REMOVE FOREIGN KEY CONSTRAINT FROM support_tickets (if exists)
-- ============================================================

SET @fk_exists = 0;
SELECT COUNT(*) INTO @fk_exists
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = 'college_events'
  AND TABLE_NAME = 'support_tickets'
  AND CONSTRAINT_NAME = 'support_tickets_ibfk_1'
  AND CONSTRAINT_TYPE = 'FOREIGN KEY';

SET @sql = IF(@fk_exists > 0,
    'ALTER TABLE support_tickets DROP FOREIGN KEY support_tickets_ibfk_1',
    'SELECT "Foreign key support_tickets_ibfk_1 does not exist" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================
-- 4. ADD MISSING STATUS TO pending_bookings IF NEEDED
-- ============================================================

-- Update enum to include PAID status if not present
ALTER TABLE pending_bookings 
MODIFY COLUMN status ENUM('OTP_PENDING','OTP_VERIFIED','RESERVED','PAYMENT_INITIATED','PAID','FAILED','EXPIRED','CANCELLED') NOT NULL DEFAULT 'OTP_PENDING';

-- ============================================================
-- 5. VERIFY INDEXES
-- ============================================================

-- Add index on user_email in confirmed_bookings if not exists
SET @index_exists = 0;
SELECT COUNT(*) INTO @index_exists
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = 'college_events'
  AND TABLE_NAME = 'confirmed_bookings'
  AND INDEX_NAME = 'idx_user_email';

SET @sql = IF(@index_exists = 0,
    'CREATE INDEX idx_user_email ON confirmed_bookings(user_email)',
    'SELECT "Index idx_user_email already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add index on checked_in in confirmed_bookings if not exists
SET @index_exists = 0;
SELECT COUNT(*) INTO @index_exists
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = 'college_events'
  AND TABLE_NAME = 'confirmed_bookings'
  AND INDEX_NAME = 'idx_checked_in';

SET @sql = IF(@index_exists = 0,
    'CREATE INDEX idx_checked_in ON confirmed_bookings(checked_in)',
    'SELECT "Index idx_checked_in already exists" AS status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================
-- 6. VERIFICATION SUMMARY
-- ============================================================

SELECT 'DATABASE VERIFICATION COMPLETE' AS status;

-- Show table structure
SELECT 
    'confirmed_bookings' AS table_name,
    COUNT(*) AS total_columns
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'college_events' 
  AND TABLE_NAME = 'confirmed_bookings';

-- Show confirmed bookings count
SELECT 
    'Total Confirmed Bookings' AS metric,
    COUNT(*) AS count
FROM confirmed_bookings;

-- Show pending bookings by status
SELECT 
    status,
    COUNT(*) AS count
FROM pending_bookings
GROUP BY status;

-- Show events
SELECT 
    'Active Events' AS metric,
    COUNT(*) AS count
FROM events
WHERE status = 'active';

SELECT '✓ All database checks complete!' AS message;
