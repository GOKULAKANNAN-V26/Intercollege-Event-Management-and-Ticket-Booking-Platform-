-- ============================================================
-- MIGRATION: Cancellation Requests → Support Tickets
-- ============================================================
-- This script migrates existing cancellation_requests to the
-- support_tickets system for unified tracking.
--
-- Date: 2026-05-06
-- Purpose: Consolidate cancellation tracking under support tickets
-- ============================================================

-- Step 1: Migrate existing cancellation_requests to support_tickets
-- ============================================================
INSERT INTO support_tickets (
    ticket_id,
    user_name,
    user_email,
    user_phone,
    booking_id,
    subject,
    category,
    message,
    status,
    admin_reply,
    created_at,
    updated_at
)
SELECT 
    -- Convert CR (Cancellation Request) ID to ST (Support Ticket) ID
    CONCAT('ST', SUBSTRING(request_id, 3)) as ticket_id,
    user_name,
    user_email,
    user_phone,
    booking_id,
    CONCAT('Cancellation Request - ', event_name) as subject,
    'cancellation' as category,
    -- Build message from cancellation request data
    CONCAT(
        'CANCELLATION REQUEST\n\n',
        'Booking ID: ', booking_id, '\n',
        'Event: ', event_name, '\n',
        'Tickets: ', ticket_count, '\n',
        'Amount Paid: ₹', FORMAT(total_amount, 2), '\n\n',
        'Reason: ', REPLACE(reason, '_', ' '), '\n',
        CASE 
            WHEN reason_detail IS NOT NULL AND reason_detail != '' 
            THEN CONCAT('Additional Details: ', reason_detail, '\n')
            ELSE ''
        END,
        '\n---\n',
        'Migrated from legacy cancellation_requests table.'
    ) as message,
    -- Map cancellation status to support ticket status
    CASE status
        WHEN 'pending' THEN 'open'
        WHEN 'approved' THEN 'resolved'
        WHEN 'rejected' THEN 'closed'
        WHEN 'refunded' THEN 'resolved'
        ELSE 'open'
    END as status,
    -- Include admin note and refund info in reply
    CASE 
        WHEN admin_note IS NOT NULL OR refund_amount IS NOT NULL THEN
            CONCAT(
                COALESCE(admin_note, 'Cancellation processed.'),
                CASE 
                    WHEN refund_amount IS NOT NULL 
                    THEN CONCAT('\n\nRefund Amount: ₹', FORMAT(refund_amount, 2))
                    ELSE ''
                END,
                CASE 
                    WHEN refund_id IS NOT NULL 
                    THEN CONCAT('\nRefund ID: ', refund_id)
                    ELSE ''
                END
            )
        ELSE NULL
    END as admin_reply,
    requested_at as created_at,
    COALESCE(processed_at, requested_at) as updated_at
FROM cancellation_requests
WHERE NOT EXISTS (
    -- Avoid duplicates if script is run multiple times
    SELECT 1 FROM support_tickets st 
    WHERE st.booking_id = cancellation_requests.booking_id 
    AND st.category = 'cancellation'
);

-- Step 2: Verify migration
-- ============================================================
SELECT 
    '✅ Migration Summary' as Status,
    (SELECT COUNT(*) FROM cancellation_requests) as 'Total Cancellation Requests',
    (SELECT COUNT(*) FROM support_tickets WHERE category = 'cancellation') as 'Migrated to Support Tickets',
    (SELECT COUNT(*) FROM support_tickets WHERE category = 'cancellation' AND status = 'open') as 'Open Cancellations',
    (SELECT COUNT(*) FROM support_tickets WHERE category = 'cancellation' AND status = 'resolved') as 'Resolved Cancellations',
    (SELECT COUNT(*) FROM support_tickets WHERE category = 'cancellation' AND status = 'closed') as 'Rejected Cancellations';

-- Step 3: Add note to cancellation_requests table (optional)
-- ============================================================
-- You can keep the cancellation_requests table for historical reference
-- or drop it after verifying the migration is successful.

-- To keep it as read-only historical data:
-- ALTER TABLE cancellation_requests COMMENT = 'DEPRECATED: Migrated to support_tickets. Keep for historical reference only.';

-- To drop it (only after verifying migration):
-- DROP TABLE cancellation_requests;

-- ============================================================
-- NOTES FOR DEVELOPERS
-- ============================================================
-- 1. The cancel-ticket.php now creates support tickets instead of cancellation_requests
-- 2. Admin cancellations.php now shows support tickets with category='cancellation'
-- 3. All new cancellations will have ticket_id format: ST20260506ABCD1234
-- 4. Users can track cancellations using the ticket_id in the support system
-- 5. Admins process cancellations through the unified support ticket interface
--
-- BENEFITS:
-- ✅ Unified tracking system (one ticket_id for all requests)
-- ✅ Better user experience (track cancellations like any support request)
-- ✅ Simplified admin workflow (one interface for all support)
-- ✅ Consistent communication (admin replies work the same way)
-- ✅ Historical data preserved (can keep old cancellation_requests table)
-- ============================================================

SELECT '✅ Migration complete! Cancellations are now tracked as support tickets.' as Status;
