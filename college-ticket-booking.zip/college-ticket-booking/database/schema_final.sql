-- ============================================================
-- VelTech EventPass — COMPLETE FINAL SCHEMA
-- Drop old DB and import ONLY this file
-- Compatible: MySQL 5.6+ / MariaDB 10.1+ / XAMPP
-- ============================================================

DROP DATABASE IF EXISTS college_events;
CREATE DATABASE college_events CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE college_events;

-- ============================================================
-- USERS TABLE (with auth fields built-in)
-- ============================================================
CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL DEFAULT '',
    is_verified TINYINT(1) NOT NULL DEFAULT 1,
    department VARCHAR(100) DEFAULT NULL,
    roll_number VARCHAR(50) DEFAULT NULL,
    profile_pic VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_email (email),
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- EVENTS TABLE
-- ============================================================
CREATE TABLE events (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    department VARCHAR(100) NOT NULL,
    venue VARCHAR(255) NOT NULL,
    event_date DATETIME NOT NULL,
    ticket_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    total_tickets INT UNSIGNED NOT NULL DEFAULT 0,
    available_tickets INT UNSIGNED NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    registration_type ENUM('Individual','Team','Both') NOT NULL DEFAULT 'Individual',
    min_team_members INT UNSIGNED DEFAULT NULL,
    max_team_members INT UNSIGNED DEFAULT NULL,
    status ENUM('active','inactive','cancelled') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_event_date (event_date),
    INDEX idx_department (department)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- OTP VERIFICATION TABLE
-- ============================================================
CREATE TABLE otp_verification (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(255) NOT NULL,
    otp_hash VARCHAR(255) NOT NULL,
    purpose VARCHAR(50) NOT NULL DEFAULT 'booking',
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    last_sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    verified TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    INDEX idx_phone_email (phone, email),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- PENDING BOOKINGS TABLE
-- ============================================================
CREATE TABLE pending_bookings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_ref VARCHAR(50) NOT NULL UNIQUE,
    event_id INT UNSIGNED NOT NULL,
    user_name VARCHAR(255) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    user_phone VARCHAR(20) NOT NULL,
    team_name VARCHAR(255) DEFAULT NULL,
    team_members TEXT DEFAULT NULL,
    ticket_count INT UNSIGNED NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    razorpay_order_id VARCHAR(100) DEFAULT NULL,
    status ENUM('OTP_PENDING','OTP_VERIFIED','RESERVED','PAYMENT_INITIATED','FAILED','EXPIRED','CANCELLED') NOT NULL DEFAULT 'OTP_PENDING',
    expiry_timestamp DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_event_id (event_id),
    INDEX idx_expiry (expiry_timestamp),
    INDEX idx_status (status),
    INDEX idx_razorpay_order (razorpay_order_id),
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- CONFIRMED BOOKINGS TABLE (with QR + check-in + refund)
-- ============================================================
CREATE TABLE confirmed_bookings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_id VARCHAR(50) NOT NULL UNIQUE,
    pending_booking_ref VARCHAR(50) NOT NULL,
    event_id INT UNSIGNED NOT NULL,
    user_name VARCHAR(255) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    user_phone VARCHAR(20) NOT NULL,
    team_name VARCHAR(255) DEFAULT NULL,
    team_members TEXT DEFAULT NULL,
    ticket_count INT UNSIGNED NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_id VARCHAR(100) NOT NULL,
    razorpay_order_id VARCHAR(100) NOT NULL,
    status ENUM('PAID','CONFIRMED','REFUNDED','CANCELLED') NOT NULL DEFAULT 'PAID',
    receipt_path VARCHAR(500) DEFAULT NULL,
    qr_code_path VARCHAR(500) DEFAULT NULL,
    checked_in TINYINT(1) NOT NULL DEFAULT 0,
    checked_in_at DATETIME DEFAULT NULL,
    refund_status ENUM('none','pending','processed') NOT NULL DEFAULT 'none',
    refund_amount DECIMAL(10,2) DEFAULT NULL,
    email_sent TINYINT(1) NOT NULL DEFAULT 0,
    whatsapp_sent TINYINT(1) NOT NULL DEFAULT 0,
    confirmed_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_event_id (event_id),
    INDEX idx_payment_id (payment_id),
    INDEX idx_user_email (user_email),
    INDEX idx_checked_in (checked_in),
    UNIQUE KEY uq_payment_id (payment_id),
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- PAYMENTS TABLE
-- ============================================================
CREATE TABLE payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    razorpay_order_id VARCHAR(100) NOT NULL,
    razorpay_payment_id VARCHAR(100) DEFAULT NULL,
    razorpay_signature VARCHAR(500) DEFAULT NULL,
    booking_ref VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'INR',
    status ENUM('CREATED','ATTEMPTED','PAID','FAILED','REFUNDED') NOT NULL DEFAULT 'CREATED',
    webhook_verified TINYINT(1) NOT NULL DEFAULT 0,
    raw_response TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_order_id (razorpay_order_id),
    INDEX idx_payment_id (razorpay_payment_id),
    INDEX idx_booking_ref (booking_ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- ADMINS TABLE
-- ============================================================
CREATE TABLE admins (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    last_login DATETIME NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- CANCELLATION REQUESTS TABLE
-- ============================================================
CREATE TABLE cancellation_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id VARCHAR(50) NOT NULL UNIQUE,
    booking_id VARCHAR(50) NOT NULL,
    user_id INT UNSIGNED DEFAULT NULL,
    user_name VARCHAR(255) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    user_phone VARCHAR(20) NOT NULL,
    event_name VARCHAR(255) NOT NULL,
    event_id INT UNSIGNED NOT NULL DEFAULT 0,
    ticket_count INT UNSIGNED NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    reason ENUM('event_cancelled','schedule_conflict','personal_emergency','duplicate_booking','other') NOT NULL DEFAULT 'other',
    reason_detail TEXT DEFAULT NULL,
    status ENUM('pending','approved','rejected','refunded') NOT NULL DEFAULT 'pending',
    refund_amount DECIMAL(10,2) DEFAULT NULL,
    refund_id VARCHAR(100) DEFAULT NULL,
    admin_note TEXT DEFAULT NULL,
    requested_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    processed_at DATETIME DEFAULT NULL,
    INDEX idx_booking_id (booking_id),
    INDEX idx_user_email (user_email),
    INDEX idx_status (status),
    FOREIGN KEY (booking_id) REFERENCES confirmed_bookings(booking_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SUPPORT TICKETS TABLE
-- ============================================================
CREATE TABLE support_tickets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id VARCHAR(50) NOT NULL UNIQUE,
    user_name VARCHAR(255) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    user_phone VARCHAR(20) DEFAULT NULL,
    booking_id VARCHAR(50) DEFAULT NULL,
    subject VARCHAR(255) NOT NULL,
    category ENUM('cancellation','payment','booking','technical','password','other') NOT NULL DEFAULT 'other',
    message TEXT NOT NULL,
    status ENUM('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
    admin_reply TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_email (user_email),
    INDEX idx_status (status),
    INDEX idx_booking_id (booking_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- JOBS TABLE
-- ============================================================
CREATE TABLE jobs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_type ENUM('send_email','send_whatsapp','generate_receipt','generate_qr') NOT NULL,
    payload TEXT NOT NULL,
    status ENUM('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    max_attempts INT UNSIGNED NOT NULL DEFAULT 3,
    last_error TEXT DEFAULT NULL,
    scheduled_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    processed_at DATETIME NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status_scheduled (status, scheduled_at),
    INDEX idx_job_type (job_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- LOGS TABLE
-- ============================================================
CREATE TABLE logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    level ENUM('info','warning','error','debug') NOT NULL DEFAULT 'info',
    context VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    data TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_level (level),
    INDEX idx_context (context),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- RATE LIMITS TABLE
-- ============================================================
CREATE TABLE rate_limits (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(255) NOT NULL,
    action VARCHAR(100) NOT NULL,
    attempts INT UNSIGNED NOT NULL DEFAULT 1,
    window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_identifier_action (identifier, action),
    INDEX idx_window_start (window_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TRIGGERS
-- ============================================================
DELIMITER $

CREATE TRIGGER users_before_insert
BEFORE INSERT ON users FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
END$

CREATE TRIGGER events_before_insert
BEFORE INSERT ON events FOR EACH ROW
BEGIN
    IF NEW.created_at = '2000-01-01 00:00:00' THEN
        SET NEW.created_at = NOW();
    END IF;
END$

CREATE TRIGGER otp_before_insert
BEFORE INSERT ON otp_verification FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
END$

CREATE TRIGGER pending_bookings_before_insert
BEFORE INSERT ON pending_bookings FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
END$

CREATE TRIGGER confirmed_bookings_before_insert
BEFORE INSERT ON confirmed_bookings FOR EACH ROW
BEGIN
    SET NEW.confirmed_at = NOW();
END$

CREATE TRIGGER payments_before_insert
BEFORE INSERT ON payments FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
END$

CREATE TRIGGER jobs_before_insert
BEFORE INSERT ON jobs FOR EACH ROW
BEGIN
    SET NEW.scheduled_at = NOW();
END$

CREATE TRIGGER cancellation_before_insert
BEFORE INSERT ON cancellation_requests FOR EACH ROW
BEGIN
    SET NEW.requested_at = NOW();
END$

CREATE TRIGGER support_ticket_before_insert
BEFORE INSERT ON support_tickets FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
END$

DELIMITER ;

-- ============================================================
-- SAMPLE DATA
-- ============================================================
INSERT INTO admins (username, password_hash, email) VALUES
('admin', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@veltech.edu.in');
-- Password: password

INSERT INTO events (name, description, department, venue, event_date, ticket_price, total_tickets, available_tickets, status) VALUES
('Tech Fest 2026', 'Annual technology festival with workshops, hackathons, and competitions.', 'Computer Science', 'Main Auditorium', '2026-06-15 09:00:00', 150.00, 500, 500, 'active'),
('Cultural Night', 'A spectacular evening of music, dance, and drama performances.', 'Arts & Culture', 'Open Air Theatre', '2026-06-20 18:00:00', 100.00, 300, 300, 'active'),
('Science Expo', 'Showcase of innovative science projects and research by students.', 'Science', 'Science Block Hall', '2026-07-05 10:00:00', 50.00, 200, 200, 'active'),
('Management Summit', 'Industry leaders and students discuss future business trends.', 'Management', 'Conference Hall A', '2026-07-10 09:30:00', 200.00, 150, 150, 'active'),
('Sports Day', 'Annual inter-department sports competition and prize distribution.', 'Sports', 'College Ground', '2026-07-25 08:00:00', 0.00, 1000, 1000, 'active');
