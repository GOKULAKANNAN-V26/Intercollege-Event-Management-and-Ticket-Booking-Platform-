-- ============================================================
-- SCHEMA UPDATE: User Accounts + Cancellation Requests
-- Run this AFTER the main schema.sql
-- ============================================================
USE college_events;

-- ============================================================
-- ALTER USERS TABLE: Add password + account fields
-- ============================================================
ALTER TABLE users
  ADD COLUMN password_hash VARCHAR(255) NOT NULL DEFAULT '' AFTER phone,
  ADD COLUMN is_verified TINYINT(1) NOT NULL DEFAULT 0 AFTER password_hash,
  ADD COLUMN profile_pic VARCHAR(255) DEFAULT NULL AFTER is_verified,
  ADD COLUMN department VARCHAR(100) DEFAULT NULL AFTER profile_pic,
  ADD COLUMN roll_number VARCHAR(50) DEFAULT NULL AFTER department,
  ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- ============================================================
-- CANCELLATION REQUESTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS cancellation_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id VARCHAR(50) NOT NULL UNIQUE,
    booking_id VARCHAR(50) NOT NULL,
    user_id INT UNSIGNED DEFAULT NULL,
    user_name VARCHAR(255) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    user_phone VARCHAR(20) NOT NULL,
    event_name VARCHAR(255) NOT NULL,
    ticket_count INT UNSIGNED NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    reason ENUM(
        'event_cancelled',
        'schedule_conflict',
        'personal_emergency',
        'duplicate_booking',
        'other'
    ) NOT NULL DEFAULT 'other',
    reason_detail TEXT DEFAULT NULL,
    status ENUM('pending','approved','rejected','refunded') NOT NULL DEFAULT 'pending',
    refund_amount DECIMAL(10,2) DEFAULT NULL,
    refund_id VARCHAR(100) DEFAULT NULL,
    admin_note TEXT DEFAULT NULL,
    requested_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    processed_at DATETIME DEFAULT NULL,
    INDEX idx_booking_id (booking_id),
    INDEX idx_user_email (user_email),
    INDEX idx_status (status),
    FOREIGN KEY (booking_id) REFERENCES confirmed_bookings(booking_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SUPPORT TICKETS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS support_tickets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id VARCHAR(50) NOT NULL UNIQUE,
    user_name VARCHAR(255) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    user_phone VARCHAR(20) DEFAULT NULL,
    booking_id VARCHAR(50) DEFAULT NULL,
    subject VARCHAR(255) NOT NULL,
    category ENUM('cancellation','payment','booking','technical','other') NOT NULL DEFAULT 'other',
    message TEXT NOT NULL,
    status ENUM('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
    admin_reply TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT '2000-01-01 00:00:00',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_email (user_email),
    INDEX idx_status (status),
    INDEX idx_booking_id (booking_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- TRIGGERS for new tables
-- ============================================================
DELIMITER $

CREATE TRIGGER cancellation_before_insert
BEFORE INSERT ON cancellation_requests FOR EACH ROW
BEGIN
    SET NEW.requested_at = NOW();
END$

CREATE TRIGGER support_ticket_before_insert
BEFORE INSERT ON support_tickets FOR EACH ROW
BEGIN
    SET NEW.created_at = NOW();
END$

DELIMITER ;
