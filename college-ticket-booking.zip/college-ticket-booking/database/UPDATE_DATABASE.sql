-- ============================================================
-- CRITICAL DATABASE UPDATE FOR EXISTING DATABASE
-- This adds ALL missing columns to your confirmed_bookings table
-- Safe to run multiple times - checks if columns exist first
-- ============================================================

USE college_events;

-- Temporarily disable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

-- Add team_name column (for team registrations)
SET @s = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA=DATABASE() 
     AND TABLE_NAME='confirmed_bookings' 
     AND COLUMN_NAME='team_name') > 0,
    "SELECT 'team_name already exists' AS msg",
    "ALTER TABLE confirmed_bookings ADD COLUMN team_name VARCHAR(255) DEFAULT NULL AFTER user_phone"
));
PREPARE stmt FROM @s;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add team_members column (for team registrations)
SET @s = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA=DATABASE() 
     AND TABLE_NAME='confirmed_bookings' 
     AND COLUMN_NAME='team_members') > 0,
    "SELECT 'team_members already exists' AS msg",
    "ALTER TABLE confirmed_bookings ADD COLUMN team_members TEXT DEFAULT NULL AFTER team_name"
));
PREPARE stmt FROM @s;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add qr_code_path column (for QR code tickets)
SET @s = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA=DATABASE() 
     AND TABLE_NAME='confirmed_bookings' 
     AND COLUMN_NAME='qr_code_path') > 0,
    "SELECT 'qr_code_path already exists' AS msg",
    "ALTER TABLE confirmed_bookings ADD COLUMN qr_code_path VARCHAR(500) DEFAULT NULL AFTER receipt_path"
));
PREPARE stmt FROM @s;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add checked_in column (for event check-in)
SET @s = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA=DATABASE() 
     AND TABLE_NAME='confirmed_bookings' 
     AND COLUMN_NAME='checked_in') > 0,
    "SELECT 'checked_in already exists' AS msg",
    "ALTER TABLE confirmed_bookings ADD COLUMN checked_in TINYINT(1) NOT NULL DEFAULT 0 AFTER qr_code_path"
));
PREPARE stmt FROM @s;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add checked_in_at column (timestamp of check-in)
SET @s = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA=DATABASE() 
     AND TABLE_NAME='confirmed_bookings' 
     AND COLUMN_NAME='checked_in_at') > 0,
    "SELECT 'checked_in_at already exists' AS msg",
    "ALTER TABLE confirmed_bookings ADD COLUMN checked_in_at DATETIME DEFAULT NULL AFTER checked_in"
));
PREPARE stmt FROM @s;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add refund_status column (for cancellation refunds)
SET @s = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA=DATABASE() 
     AND TABLE_NAME='confirmed_bookings' 
     AND COLUMN_NAME='refund_status') > 0,
    "SELECT 'refund_status already exists' AS msg",
    "ALTER TABLE confirmed_bookings ADD COLUMN refund_status ENUM('none','pending','processed') NOT NULL DEFAULT 'none' AFTER checked_in_at"
));
PREPARE stmt FROM @s;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add refund_amount column (refund amount)
SET @s = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA=DATABASE() 
     AND TABLE_NAME='confirmed_bookings' 
     AND COLUMN_NAME='refund_amount') > 0,
    "SELECT 'refund_amount already exists' AS msg",
    "ALTER TABLE confirmed_bookings ADD COLUMN refund_amount DECIMAL(10,2) DEFAULT NULL AFTER refund_status"
));
PREPARE stmt FROM @s;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Display success message
SELECT '✅ Database update completed successfully!' AS Status;
SELECT 'All missing columns have been added to confirmed_bookings table.' AS Message;

-- Show updated table structure
SELECT 'Updated table structure:' AS Info;
DESCRIBE confirmed_bookings;
