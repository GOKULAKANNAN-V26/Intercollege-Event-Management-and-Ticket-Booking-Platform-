-- ============================================================
-- FIX: Remove Foreign Key Constraint from support_tickets
-- This allows users to submit tickets without a booking ID
-- ============================================================

USE college_events;

-- Drop the foreign key constraint
ALTER TABLE support_tickets 
DROP FOREIGN KEY support_tickets_ibfk_1;

-- Keep the index for performance
-- (The index idx_booking_id is still there, just no constraint)

-- Verify the constraint is removed
SHOW CREATE TABLE support_tickets;

SELECT '✅ Foreign key constraint removed! Support tickets can now be submitted without booking ID.' AS Status;
