# 💰 Payment Reconciliation System

## Problem Statement

**Issue**: Transaction was successfully captured at the gateway level (Razorpay), but the `is_paid` status failed to update in the bookings table. Consequently:
- Ticket generation script was not triggered
- Record is missing from user's "My Bookings" view
- Payment succeeded but booking wasn't confirmed

This creates "orphaned payments" - payments that succeeded at Razorpay but have no corresponding confirmed booking.

---

## Root Causes

### 1. **bind_param() Error** ✅ FIXED
- **Issue**: PHP error when trying to pass expressions by reference
- **Location**: `includes/BookingService.php` line 158
- **Impact**: Payment succeeded, but booking confirmation failed
- **Fix**: Store values in variables before passing to `bind_param()`

### 2. **Database Errors**
- Missing columns in `confirmed_bookings` table
- Foreign key constraints blocking inserts
- Transaction rollbacks

### 3. **PHP Exceptions**
- Uncaught exceptions during booking confirmation
- Memory limits or timeouts
- Code bugs

### 4. **Network Issues**
- Webhook delivery failures
- Client-side callback failures
- Server timeouts

---

## Solution Implemented

### 1. Enhanced Error Handling ✅

**File**: `includes/PaymentService.php`

**Changes**:
- Added comprehensive try-catch blocks
- Payment marked as PAID **before** attempting booking confirmation
- Detailed logging at each step
- Graceful failure handling
- Idempotency checks improved

**Key Improvement**:
```php
// Update payment record FIRST (before attempting booking confirmation)
$stmt = $conn->prepare(
    "UPDATE payments 
     SET razorpay_payment_id = ?, status = 'PAID', webhook_verified = 1, raw_response = ?
     WHERE razorpay_order_id = ?"
);
$stmt->execute();

// Then attempt booking confirmation
$confirmResult = BookingService::confirmBooking($payment['booking_ref'], $paymentId, $orderId);

if (!$confirmResult['success']) {
    // Payment is marked as PAID, but booking failed
    // This creates an "orphaned payment" that can be reconciled later
    Logger::error('PaymentService', "Booking confirmation FAILED after payment success", [
        'action_required' => 'Use payment reconciliation tool in admin panel'
    ]);
}
```

### 2. Improved BookingService ✅

**File**: `includes/BookingService.php`

**Changes**:
- Better error messages
- Detailed logging with context
- Separate try-catch for notifications (non-critical)
- Check for both 'RESERVED' and 'PAYMENT_INITIATED' statuses
- Explicit error handling for INSERT failures

### 3. Payment Reconciliation Tool ✅

**File**: `admin/payment-reconciliation.php` (NEW)

**Features**:
- Automatically finds orphaned payments
- Shows payment details, customer info, and amounts
- One-click reconciliation
- Idempotent (safe to run multiple times)
- Detailed statistics and reporting

**How It Works**:
1. Queries database for payments with status='PAID' that have no corresponding confirmed_bookings
2. Displays them in an admin interface
3. Admin clicks "Reconcile" button
4. System attempts to create the confirmed booking
5. Updates all related tables
6. Triggers notifications (receipt, email, WhatsApp)

---

## How to Use

### For Admins: Finding Orphaned Payments

1. **Access the tool**:
   ```
   https://your-domain.com/admin/payment-reconciliation.php
   ```

2. **Review orphaned payments**:
   - See list of all payments that succeeded but have no booking
   - View customer details, event, amount, date

3. **Reconcile payments**:
   - Click "🔄 Reconcile" button for each orphaned payment
   - System will attempt to create the booking
   - Success message shows booking ID created

4. **Verify**:
   - Check "My Bookings" for the user
   - Verify booking appears in admin bookings list
   - Confirm receipt was generated

### For Developers: Monitoring

**Check logs for orphaned payments**:
```bash
grep "Booking confirmation FAILED after payment success" logs/error.log
```

**Query database directly**:
```sql
-- Find orphaned payments
SELECT 
    p.razorpay_payment_id,
    p.booking_ref,
    p.amount,
    p.created_at,
    pb.user_email,
    pb.user_name
FROM payments p
JOIN pending_bookings pb ON p.booking_ref = pb.booking_ref
LEFT JOIN confirmed_bookings cb ON p.razorpay_payment_id = cb.payment_id
WHERE p.status = 'PAID' 
  AND cb.booking_id IS NULL
ORDER BY p.created_at DESC;
```

---

## Prevention Measures

### 1. Database Schema Verification

Run this before deployment:
```sql
SOURCE database/VERIFY_AND_FIX_DATABASE.sql;
```

This ensures:
- All required columns exist
- No foreign key constraints blocking inserts
- Proper indexes are in place

### 2. Error Monitoring

**Set up alerts for**:
- Any "Booking confirmation FAILED" log entries
- Orphaned payment count > 0
- Payment success rate < 95%

**Check regularly**:
```bash
# Check for recent failures
tail -100 logs/error.log | grep "Booking confirmation FAILED"

# Count orphaned payments
mysql -u root -p college_events -e "
SELECT COUNT(*) as orphaned_count
FROM payments p
LEFT JOIN confirmed_bookings cb ON p.razorpay_payment_id = cb.payment_id
WHERE p.status = 'PAID' AND cb.booking_id IS NULL;
"
```

### 3. Webhook Configuration

**Razorpay Dashboard Settings**:
1. Go to Settings → Webhooks
2. Add webhook URL: `https://your-domain.com/api/webhook.php`
3. Enable events:
   - `payment.captured`
   - `payment.failed`
4. Set webhook secret in `config/config.php`:
   ```php
   define('RAZORPAY_WEBHOOK_SECRET', 'your_webhook_secret');
   ```

**Why webhooks are important**:
- More reliable than client-side callbacks
- Server-to-server communication
- Automatic retries by Razorpay
- Works even if user closes browser

### 4. Regular Reconciliation

**Schedule daily checks**:
```bash
# Add to cron (Linux)
0 9 * * * /usr/bin/php /path/to/admin/payment-reconciliation.php --auto-reconcile

# Or Windows Task Scheduler
# Run daily at 9 AM
```

---

## Testing

### Test Orphaned Payment Scenario

1. **Create a test payment**:
   - Book an event
   - Complete payment at Razorpay
   - Payment succeeds

2. **Simulate failure**:
   - Temporarily rename `confirmed_bookings` table
   - Payment will succeed but booking will fail
   - This creates an orphaned payment

3. **Verify orphaned payment**:
   - Go to `admin/payment-reconciliation.php`
   - Should see the orphaned payment listed

4. **Reconcile**:
   - Restore `confirmed_bookings` table
   - Click "Reconcile" button
   - Verify booking is created

5. **Check user view**:
   - Login as the user
   - Go to "My Bookings"
   - Booking should now appear

---

## API Flow

### Normal Flow (Success)

```
1. User completes payment at Razorpay
   ↓
2. Razorpay sends webhook to api/webhook.php
   ↓
3. PaymentService::processSuccessfulPayment()
   ↓
4. Update payments table: status = 'PAID'
   ↓
5. BookingService::confirmBooking()
   ↓
6. Insert into confirmed_bookings
   ↓
7. Update pending_bookings: status = 'PAID'
   ↓
8. Queue notifications (receipt, email, WhatsApp)
   ↓
9. ✅ Booking appears in "My Bookings"
```

### Failure Flow (Orphaned Payment)

```
1. User completes payment at Razorpay
   ↓
2. Razorpay sends webhook to api/webhook.php
   ↓
3. PaymentService::processSuccessfulPayment()
   ↓
4. Update payments table: status = 'PAID' ✅
   ↓
5. BookingService::confirmBooking()
   ↓
6. ❌ INSERT fails (bind_param error, DB error, etc.)
   ↓
7. Error logged: "Booking confirmation FAILED after payment success"
   ↓
8. Payment is PAID but no confirmed_bookings record
   ↓
9. ⚠️ ORPHANED PAYMENT created
   ↓
10. Admin uses reconciliation tool
   ↓
11. System retries BookingService::confirmBooking()
   ↓
12. ✅ Booking created, appears in "My Bookings"
```

---

## Files Modified

### Core Files
- ✅ `includes/PaymentService.php` - Enhanced error handling
- ✅ `includes/BookingService.php` - Better logging and error handling

### New Files
- ✅ `admin/payment-reconciliation.php` - Reconciliation tool
- ✅ `PAYMENT_RECONCILIATION_GUIDE.md` - This documentation

---

## Monitoring Dashboard

### Key Metrics to Track

1. **Payment Success Rate**
   ```sql
   SELECT 
       COUNT(*) as total_payments,
       SUM(CASE WHEN status = 'PAID' THEN 1 ELSE 0 END) as successful,
       ROUND(SUM(CASE WHEN status = 'PAID' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as success_rate
   FROM payments
   WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY);
   ```

2. **Orphaned Payment Count**
   ```sql
   SELECT COUNT(*) as orphaned_count
   FROM payments p
   LEFT JOIN confirmed_bookings cb ON p.razorpay_payment_id = cb.payment_id
   WHERE p.status = 'PAID' AND cb.booking_id IS NULL;
   ```

3. **Booking Confirmation Rate**
   ```sql
   SELECT 
       COUNT(DISTINCT p.razorpay_payment_id) as paid_payments,
       COUNT(DISTINCT cb.booking_id) as confirmed_bookings,
       ROUND(COUNT(DISTINCT cb.booking_id) * 100.0 / COUNT(DISTINCT p.razorpay_payment_id), 2) as confirmation_rate
   FROM payments p
   LEFT JOIN confirmed_bookings cb ON p.razorpay_payment_id = cb.payment_id
   WHERE p.status = 'PAID'
     AND p.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY);
   ```

### Alert Thresholds

- ⚠️ **Warning**: Orphaned payments > 0
- 🚨 **Critical**: Orphaned payments > 5
- 🚨 **Critical**: Booking confirmation rate < 95%
- 🚨 **Critical**: Payment success rate < 90%

---

## FAQ

### Q: Will reconciliation create duplicate bookings?
**A**: No. The system checks for existing bookings by payment_id before creating a new one. It's idempotent.

### Q: What if reconciliation fails?
**A**: Check the error message. Common issues:
- Pending booking expired or deleted
- Database constraints
- Missing event or user data

### Q: Can users see orphaned payments?
**A**: No. They only see confirmed bookings in "My Bookings". Orphaned payments are only visible in admin panel.

### Q: Should I refund orphaned payments?
**A**: No! Use the reconciliation tool to create the booking. Only refund if the event is cancelled or sold out.

### Q: How often should I check for orphaned payments?
**A**: Daily is recommended. Set up automated alerts for immediate notification.

### Q: What about old orphaned payments?
**A**: They can be reconciled at any time, as long as the pending booking still exists and the event hasn't passed.

---

## Support

### If You Encounter Issues

1. **Check logs**:
   ```bash
   tail -100 logs/error.log
   ```

2. **Verify database**:
   ```
   http://your-domain.com/check_database.php
   ```

3. **Run reconciliation**:
   ```
   http://your-domain.com/admin/payment-reconciliation.php
   ```

4. **Contact support** with:
   - Payment ID (razorpay_payment_id)
   - Order ID (razorpay_order_id)
   - Booking reference
   - Error logs
   - Screenshots

---

## Summary

✅ **Problem**: Payments succeeded but bookings weren't created  
✅ **Root Cause**: bind_param() error and lack of error handling  
✅ **Solution**: Enhanced error handling + reconciliation tool  
✅ **Prevention**: Database verification + monitoring + webhooks  
✅ **Recovery**: Admin reconciliation tool for orphaned payments  

**Status**: PRODUCTION READY with full reconciliation support

---

**Last Updated**: May 6, 2026  
**Version**: 2.0.0  
**Priority**: CRITICAL - Payment integrity
