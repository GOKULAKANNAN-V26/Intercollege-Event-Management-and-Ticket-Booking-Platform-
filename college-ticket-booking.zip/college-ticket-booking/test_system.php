<?php
/**
 * System Health Check & Function Test
 * Run this script to verify all critical functions are working
 * Access: http://yourdomain.com/test_system.php
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

// Security: Only allow in development mode
if (APP_ENV !== 'development') {
    die('❌ This test script only runs in development mode. Set APP_ENV to "development" in config.php');
}

$results = [];
$allPassed = true;

function testResult($name, $passed, $message = '') {
    global $results, $allPassed;
    $results[] = [
        'name' => $name,
        'passed' => $passed,
        'message' => $message
    ];
    if (!$passed) $allPassed = false;
}

// ============================================================
// TEST 1: Database Connection
// ============================================================
try {
    $conn = getDBConnection();
    testResult('Database Connection', true, 'Connected to ' . DB_NAME);
} catch (Exception $e) {
    testResult('Database Connection', false, $e->getMessage());
    $conn = null;
}

// ============================================================
// TEST 2: Required Tables Exist
// ============================================================
if ($conn) {
    $requiredTables = [
        'users', 'events', 'otp_verification', 'pending_bookings',
        'confirmed_bookings', 'payments', 'admins', 'cancellation_requests',
        'support_tickets', 'jobs', 'logs', 'rate_limits'
    ];
    
    $result = $conn->query("SHOW TABLES");
    $existingTables = [];
    while ($row = $result->fetch_array()) {
        $existingTables[] = $row[0];
    }
    
    $missingTables = array_diff($requiredTables, $existingTables);
    if (empty($missingTables)) {
        testResult('Database Tables', true, 'All ' . count($requiredTables) . ' tables exist');
    } else {
        testResult('Database Tables', false, 'Missing tables: ' . implode(', ', $missingTables));
    }
}

// ============================================================
// TEST 3: Confirmed Bookings Table Structure
// ============================================================
if ($conn) {
    $result = $conn->query("DESCRIBE confirmed_bookings");
    $columns = [];
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    
    $requiredColumns = ['team_name', 'team_members'];
    $missingColumns = array_diff($requiredColumns, $columns);
    
    if (empty($missingColumns)) {
        testResult('Team Columns', true, 'team_name and team_members columns exist');
    } else {
        testResult('Team Columns', false, 'Missing columns: ' . implode(', ', $missingColumns) . '. Run migration_add_team_columns.sql');
    }
}

// ============================================================
// TEST 4: Admin Account Exists
// ============================================================
if ($conn) {
    $result = $conn->query("SELECT COUNT(*) as count FROM admins");
    $row = $result->fetch_assoc();
    if ($row['count'] > 0) {
        testResult('Admin Account', true, $row['count'] . ' admin account(s) found');
    } else {
        testResult('Admin Account', false, 'No admin accounts found. Create one in database.');
    }
}

// ============================================================
// TEST 5: File Permissions
// ============================================================
$writableDirs = ['uploads', 'uploads/receipts', 'uploads/qrcodes', 'logs'];
$permissionIssues = [];
foreach ($writableDirs as $dir) {
    if (!is_writable($dir)) {
        $permissionIssues[] = $dir;
    }
}
if (empty($permissionIssues)) {
    testResult('File Permissions', true, 'All directories writable');
} else {
    testResult('File Permissions', false, 'Not writable: ' . implode(', ', $permissionIssues) . '. Run: chmod 755 ' . implode(' ', $permissionIssues));
}

// ============================================================
// TEST 6: Configuration Check
// ============================================================
$configIssues = [];
if (RAZORPAY_KEY_ID === 'rzp_test_SlPoCiiwiPBArC') {
    $configIssues[] = 'Update RAZORPAY_KEY_ID in config.php';
}
if (MSG91_API_KEY === '513951AVg51wznUF69fa2343P1') {
    $configIssues[] = 'Update MSG91_API_KEY in config.php';
}
if (SMTP_USER === 'your_email@gmail.com') {
    $configIssues[] = 'Update SMTP credentials in config.php';
}
if (APP_URL === 'http://localhost/college-ticket-booking') {
    $configIssues[] = 'Update APP_URL to your production domain';
}

if (empty($configIssues)) {
    testResult('Configuration', true, 'All config values updated');
} else {
    testResult('Configuration', false, implode('; ', $configIssues));
}

// ============================================================
// TEST 7: OTP Service Class
// ============================================================
if (file_exists('includes/OTPService.php')) {
    require_once 'includes/OTPService.php';
    if (class_exists('OTPService')) {
        $methods = get_class_methods('OTPService');
        $requiredMethods = ['sendOTP', 'verifyOTP', 'verifyMSG91WidgetToken', 'verifyFirebaseToken'];
        $missingMethods = array_diff($requiredMethods, $methods);
        
        if (empty($missingMethods)) {
            testResult('OTP Service', true, 'All OTP methods exist');
        } else {
            testResult('OTP Service', false, 'Missing methods: ' . implode(', ', $missingMethods));
        }
    } else {
        testResult('OTP Service', false, 'OTPService class not found');
    }
} else {
    testResult('OTP Service', false, 'includes/OTPService.php not found');
}

// ============================================================
// TEST 8: Booking Service Class
// ============================================================
if (file_exists('includes/BookingService.php')) {
    require_once 'includes/BookingService.php';
    if (class_exists('BookingService')) {
        $methods = get_class_methods('BookingService');
        $requiredMethods = ['reserveTickets', 'confirmBooking', 'getConfirmedBooking'];
        $missingMethods = array_diff($requiredMethods, $methods);
        
        if (empty($missingMethods)) {
            testResult('Booking Service', true, 'All booking methods exist');
        } else {
            testResult('Booking Service', false, 'Missing methods: ' . implode(', ', $missingMethods));
        }
    } else {
        testResult('Booking Service', false, 'BookingService class not found');
    }
} else {
    testResult('Booking Service', false, 'includes/BookingService.php not found');
}

// ============================================================
// TEST 9: Critical Pages Exist
// ============================================================
$criticalPages = [
    'index.php', 'login.php', 'register.php', 'my-bookings.php',
    'cancel-ticket.php', 'support.php', 'confirmation.php',
    'admin/login.php', 'admin/dashboard.php', 'admin/support-tickets.php',
    'admin/cancellations.php', 'api/send_otp.php', 'api/verify_otp.php'
];
$missingPages = [];
foreach ($criticalPages as $page) {
    if (!file_exists($page)) {
        $missingPages[] = $page;
    }
}
if (empty($missingPages)) {
    testResult('Critical Pages', true, 'All ' . count($criticalPages) . ' pages exist');
} else {
    testResult('Critical Pages', false, 'Missing: ' . implode(', ', $missingPages));
}

// ============================================================
// TEST 10: Support Ticket Creation (Simulated)
// ============================================================
if ($conn) {
    try {
        $testTicketId = 'TEST' . time();
        $stmt = $conn->prepare(
            "INSERT INTO support_tickets (ticket_id, user_name, user_email, subject, category, message, status)
             VALUES (?, 'Test User', 'test@test.com', 'Test Ticket', 'technical', 'This is a test ticket', 'open')"
        );
        $stmt->bind_param('s', $testTicketId);
        $stmt->execute();
        $insertId = $stmt->insert_id;
        $stmt->close();
        
        // Clean up test ticket
        $conn->query("DELETE FROM support_tickets WHERE id = $insertId");
        
        testResult('Support Ticket Creation', true, 'Can create and delete support tickets');
    } catch (Exception $e) {
        testResult('Support Ticket Creation', false, $e->getMessage());
    }
}

// ============================================================
// Display Results
// ============================================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Health Check - VelTech EventPass</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: #fff;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 8px;
        }
        .header p {
            opacity: 0.9;
            font-size: 14px;
        }
        .summary {
            padding: 20px 30px;
            background: <?= $allPassed ? '#e8f5e9' : '#fce4ec' ?>;
            border-bottom: 3px solid <?= $allPassed ? '#4caf50' : '#f44336' ?>;
        }
        .summary h2 {
            font-size: 20px;
            color: <?= $allPassed ? '#2e7d32' : '#c62828' ?>;
            margin-bottom: 8px;
        }
        .summary p {
            color: #666;
            font-size: 14px;
        }
        .results {
            padding: 30px;
        }
        .test-item {
            display: flex;
            align-items: flex-start;
            gap: 15px;
            padding: 15px;
            margin-bottom: 12px;
            border-radius: 8px;
            background: #f8f9fa;
            border-left: 4px solid #ddd;
        }
        .test-item.passed {
            background: #e8f5e9;
            border-left-color: #4caf50;
        }
        .test-item.failed {
            background: #fce4ec;
            border-left-color: #f44336;
        }
        .test-icon {
            font-size: 24px;
            flex-shrink: 0;
        }
        .test-content {
            flex: 1;
        }
        .test-name {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 4px;
        }
        .test-message {
            font-size: 13px;
            color: #666;
            line-height: 1.5;
        }
        .footer {
            padding: 20px 30px;
            background: #f8f9fa;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            font-size: 13px;
            color: #666;
        }
        .footer a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .stats {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 10px;
        }
        .stat {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }
        .stat.passed {
            background: #4caf50;
            color: #fff;
        }
        .stat.failed {
            background: #f44336;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 System Health Check</h1>
            <p>VelTech EventPass - Function Verification</p>
        </div>
        
        <div class="summary">
            <h2><?= $allPassed ? '✅ All Tests Passed!' : '⚠️ Some Tests Failed' ?></h2>
            <p><?= $allPassed ? 'Your system is ready for deployment.' : 'Please fix the issues below before deploying.' ?></p>
            <div class="stats">
                <?php
                $passed = count(array_filter($results, fn($r) => $r['passed']));
                $failed = count($results) - $passed;
                ?>
                <span class="stat passed"><?= $passed ?> Passed</span>
                <?php if ($failed > 0): ?>
                <span class="stat failed"><?= $failed ?> Failed</span>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="results">
            <?php foreach ($results as $result): ?>
            <div class="test-item <?= $result['passed'] ? 'passed' : 'failed' ?>">
                <div class="test-icon"><?= $result['passed'] ? '✅' : '❌' ?></div>
                <div class="test-content">
                    <div class="test-name"><?= htmlspecialchars($result['name']) ?></div>
                    <?php if ($result['message']): ?>
                    <div class="test-message"><?= htmlspecialchars($result['message']) ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="footer">
            <p>
                <?php if ($allPassed): ?>
                    🎉 System is healthy! Review the <a href="DEPLOYMENT_CHECKLIST.md">Deployment Checklist</a> before going live.
                <?php else: ?>
                    ⚠️ Fix the failed tests above. Check <a href="DEPLOYMENT_CHECKLIST.md">Deployment Checklist</a> for solutions.
                <?php endif; ?>
            </p>
            <p style="margin-top: 10px; font-size: 11px; color: #999;">
                ⚠️ Delete this file (test_system.php) before deploying to production
            </p>
        </div>
    </div>
</body>
</html>
