@echo off
REM ============================================================
REM CollegeEvents Background Worker
REM Run this via Windows Task Scheduler every 1 minute
REM ============================================================
REM Setup: 
REM   1. Open Task Scheduler
REM   2. Create Basic Task → "CollegeEvents Worker"
REM   3. Trigger: Daily, repeat every 1 minute
REM   4. Action: Start a program → this .bat file
REM ============================================================

SET PHP_PATH=C:\xampp\php\php.exe
SET WORKER_PATH=%~dp0worker.php
SET LOG_PATH=%~dp0worker.log

echo [%date% %time%] Starting worker... >> "%LOG_PATH%"
"%PHP_PATH%" "%WORKER_PATH%" >> "%LOG_PATH%" 2>&1
echo [%date% %time%] Worker done. >> "%LOG_PATH%"
