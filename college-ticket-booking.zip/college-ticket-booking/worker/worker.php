<?php
/**
 * Background Worker – runs every minute via Windows Task Scheduler
 * Tasks:
 *   1. Release expired pending bookings (restore ticket counts)
 *   2. Process job queue (email, WhatsApp, receipt generation)
 */

// Prevent running from browser
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    exit('CLI only');
}

define('WORKER_START', microtime(true));

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/Logger.php';
require_once __DIR__ . '/../includes/BookingService.php';
require_once __DIR__ . '/../includes/NotificationService.php';
require_once __DIR__ . '/../includes/ReceiptService.php';

echo "[" . date('Y-m-d H:i:s') . "] Worker started\n";

// ── Task 1: Release expired bookings ──────────────────────────
$released = BookingService::releaseExpiredBookings();
echo "[" . date('H:i:s') . "] Released $released expired booking(s)\n";
Logger::info('Worker', "Released $released expired bookings");

// ── Task 2: Process job queue ──────────────────────────────────
processJobs();

$elapsed = round(microtime(true) - WORKER_START, 2);
echo "[" . date('H:i:s') . "] Worker finished in {$elapsed}s\n";

// ──────────────────────────────────────────────────────────────

function processJobs(): void {
    $conn = getDBConnection();

    // Fetch pending jobs (max 20 per run)
    $result = $conn->query(
        "SELECT * FROM jobs 
         WHERE status = 'pending' AND attempts < max_attempts
         ORDER BY scheduled_at ASC LIMIT 20
         FOR UPDATE SKIP LOCKED"
    );

    if (!$result) {
        // SKIP LOCKED not supported in older MySQL, fallback
        $result = $conn->query(
            "SELECT * FROM jobs 
             WHERE status = 'pending' AND attempts < max_attempts
             ORDER BY scheduled_at ASC LIMIT 20"
        );
    }

    $jobs = [];
    while ($row = $result->fetch_assoc()) {
        $jobs[] = $row;
    }

    if (empty($jobs)) {
        echo "[" . date('H:i:s') . "] No pending jobs\n";
        return;
    }

    echo "[" . date('H:i:s') . "] Processing " . count($jobs) . " job(s)\n";

    foreach ($jobs as $job) {
        processJob($conn, $job);
    }
}

function processJob(mysqli $conn, array $job): void {
    $jobId   = $job['id'];
    $jobType = $job['job_type'];
    $payload = json_decode($job['payload'], true);

    // Mark as processing
    $stmt = $conn->prepare(
        "UPDATE jobs SET status='processing', attempts=attempts+1 WHERE id=?"
    );
    $stmt->bind_param('i', $jobId);
    $stmt->execute();
    $stmt->close();

    echo "[" . date('H:i:s') . "] Job #$jobId: $jobType\n";

    try {
        $success = false;

        switch ($jobType) {
            case 'generate_receipt':
                $bookingId = $payload['booking_id'] ?? '';
                if ($bookingId) {
                    $path = ReceiptService::generateReceipt($bookingId);
                    $success = $path !== null;
                }
                break;

            case 'send_email':
                $bookingId = $payload['booking_id'] ?? '';
                if ($bookingId) {
                    // Get full booking data
                    $booking = getBookingForNotification($conn, $bookingId);
                    if ($booking) {
                        $success = NotificationService::sendConfirmationEmail($booking);
                        if ($success) {
                            $stmt = $conn->prepare(
                                "UPDATE confirmed_bookings SET email_sent=1 WHERE booking_id=?"
                            );
                            $stmt->bind_param('s', $bookingId);
                            $stmt->execute();
                            $stmt->close();
                        }
                    }
                }
                break;

            case 'send_whatsapp':
                $bookingId = $payload['booking_id'] ?? '';
                if ($bookingId) {
                    $booking = getBookingForNotification($conn, $bookingId);
                    if ($booking) {
                        $success = NotificationService::sendWhatsAppNotification($booking);
                        if ($success) {
                            $stmt = $conn->prepare(
                                "UPDATE confirmed_bookings SET whatsapp_sent=1 WHERE booking_id=?"
                            );
                            $stmt->bind_param('s', $bookingId);
                            $stmt->execute();
                            $stmt->close();
                        }
                    }
                }
                break;
        }

        if ($success) {
            $stmt = $conn->prepare(
                "UPDATE jobs SET status='completed', processed_at=NOW() WHERE id=?"
            );
            $stmt->bind_param('i', $jobId);
            $stmt->execute();
            $stmt->close();
            echo "[" . date('H:i:s') . "] Job #$jobId completed ✓\n";
        } else {
            markJobFailed($conn, $jobId, $job, 'Job returned false');
        }

    } catch (Exception $e) {
        markJobFailed($conn, $jobId, $job, $e->getMessage());
        Logger::error('Worker', "Job #$jobId failed: " . $e->getMessage());
    }
}

function markJobFailed(mysqli $conn, int $jobId, array $job, string $error): void {
    $attempts   = $job['attempts'] + 1;
    $maxAttempts= $job['max_attempts'];
    $newStatus  = $attempts >= $maxAttempts ? 'failed' : 'pending';

    $stmt = $conn->prepare(
        "UPDATE jobs SET status=?, last_error=?, processed_at=NOW() WHERE id=?"
    );
    $stmt->bind_param('ssi', $newStatus, $error, $jobId);
    $stmt->execute();
    $stmt->close();

    echo "[" . date('H:i:s') . "] Job #$jobId failed ($attempts/$maxAttempts): $error\n";
}

function getBookingForNotification(mysqli $conn, string $bookingId): ?array {
    $stmt = $conn->prepare(
        "SELECT cb.*, e.name AS event_name, e.venue, e.event_date, e.department
         FROM confirmed_bookings cb
         JOIN events e ON cb.event_id = e.id
         WHERE cb.booking_id = ?"
    );
    $stmt->bind_param('s', $bookingId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row ?: null;
}
?>
