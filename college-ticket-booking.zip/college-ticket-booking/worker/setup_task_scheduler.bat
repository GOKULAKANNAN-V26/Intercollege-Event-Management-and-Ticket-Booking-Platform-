@echo off
REM ============================================================
REM Setup Windows Task Scheduler for CollegeEvents Worker
REM Run this ONCE as Administrator
REM ============================================================

SET TASK_NAME=CollegeEventsWorker
SET BAT_PATH=%~dp0run_worker.bat

echo Creating Task Scheduler task: %TASK_NAME%

schtasks /create /tn "%TASK_NAME%" ^
  /tr "\"%BAT_PATH%\"" ^
  /sc MINUTE /mo 1 ^
  /ru SYSTEM ^
  /f

IF %ERRORLEVEL% EQU 0 (
    echo Task created successfully!
    echo Worker will run every 1 minute.
) ELSE (
    echo Failed to create task. Run as Administrator.
)

pause
