# ⚡ Quick Test - 5 Minutes

## 🎯 Test Everything in 5 Minutes!

### Step 1: Login (30 seconds)
```
http://localhost/college-ticket-booking/login.php
```
- If no account: Click "Create Account"
- Register with any email/password

### Step 2: Add Sample Bookings (30 seconds)
```
http://localhost/college-ticket-booking/add_sample_bookings.php
```
- This creates sample bookings for you!
- Click the link after login

### Step 3: View Your Bookings (30 seconds)
```
http://localhost/college-ticket-booking/my-bookings.php
```
- See all your sample bookings
- Try clicking "Receipt" or "Cancel Ticket"

### Step 4: Book FREE Event (1 minute)
1. Go to homepage
2. Find "Sports Day" (FREE)
3. Click "Book Tickets"
4. Fill form → Send OTP
5. **OTP shows in green box!**
6. Click "Verify OTP"
7. **Booking confirmed immediately!**

### Step 5: Book PAID Event with UPI (2 minutes)
1. Find any paid event (or create one in admin)
2. Click "Book Tickets"
3. Fill form → Send OTP
4. Verify OTP
5. **Payment modal opens**
6. Choose payment method:
   - **UPI:** Enter `success@razorpay`
   - **Card:** `4111 1111 1111 1111`, CVV: `123`
   - **QR Code:** Scan with UPI app
7. Complete payment
8. **Booking confirmed!**

### Step 6: Test Support Ticket (1 minute)
1. Go to `support.php`
2. Submit a ticket
3. Note Ticket ID
4. Click **"Track Ticket"**
5. **See status timeline!**

---

## 🎉 Done!

You've tested:
- ✅ User registration/login
- ✅ Sample bookings
- ✅ Free event booking
- ✅ Paid event with UPI/Card
- ✅ Support ticket tracking

**Your system is fully functional! 🚀**

---

## 💳 Payment Test Details

### UPI Test:
```
UPI ID: success@razorpay
```

### Card Test:
```
Card: 4111 1111 1111 1111
CVV: 123
Expiry: 12/25
Name: Test User
```

### QR Code Test:
- Open any UPI app
- Scan the QR code shown
- Complete payment

---

## 🔗 Quick Links

- **Homepage:** `/`
- **My Bookings:** `/my-bookings.php`
- **Add Sample Bookings:** `/add_sample_bookings.php`
- **Track Ticket:** `/track-ticket.php`
- **Admin Panel:** `/admin/login.php` (admin/password)

---

**Test now! Everything works! 🎉**
