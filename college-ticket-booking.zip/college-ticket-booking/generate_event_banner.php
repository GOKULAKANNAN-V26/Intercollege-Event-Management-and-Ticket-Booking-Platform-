<?php
/**
 * Auto Event Banner Generator
 * Generates aesthetic banners for events based on name and description
 */
require_once __DIR__ . '/config/config.php';

// Get event details from query string
$eventName = $_GET['name'] ?? 'Event Name';
$eventDesc = $_GET['desc'] ?? '';
$department = $_GET['dept'] ?? '';
$date = $_GET['date'] ?? date('d M Y');
$venue = $_GET['venue'] ?? '';
$theme = $_GET['theme'] ?? 'default'; // default, tech, cultural, sports, science
$regType = $_GET['reg_type'] ?? 'Individual'; // Individual, Team, Both

// Banner dimensions
$width = 1200;
$height = 630;

// Create image
$image = imagecreatetruecolor($width, $height);

// Define color themes
$themes = [
    'default' => [
        'bg_start' => [0, 48, 135],      // #003087
        'bg_end' => [0, 32, 96],         // #002060
        'accent' => [255, 215, 0],       // #FFD700
        'text' => [255, 255, 255],
        'subtitle' => [200, 200, 255]
    ],
    'tech' => [
        'bg_start' => [26, 35, 126],     // Indigo
        'bg_end' => [13, 71, 161],       // Blue
        'accent' => [0, 229, 255],       // Cyan
        'text' => [255, 255, 255],
        'subtitle' => [179, 229, 252]
    ],
    'cultural' => [
        'bg_start' => [123, 31, 162],    // Purple
        'bg_end' => [74, 20, 140],       // Deep Purple
        'accent' => [255, 167, 38],      // Orange
        'text' => [255, 255, 255],
        'subtitle' => [225, 190, 231]
    ],
    'sports' => [
        'bg_start' => [27, 94, 32],      // Green
        'bg_end' => [46, 125, 50],       // Light Green
        'accent' => [255, 235, 59],      // Yellow
        'text' => [255, 255, 255],
        'subtitle' => [200, 230, 201]
    ],
    'science' => [
        'bg_start' => [1, 87, 155],      // Blue
        'bg_end' => [0, 131, 143],       // Teal
        'accent' => [255, 64, 129],      // Pink
        'text' => [255, 255, 255],
        'subtitle' => [179, 229, 252]
    ]
];

// Auto-detect theme from department or event name
if ($theme === 'default') {
    $lowerName = strtolower($eventName . ' ' . $department);
    if (preg_match('/tech|hack|code|digital|ai|ml|software/i', $lowerName)) {
        $theme = 'tech';
    } elseif (preg_match('/cultural|music|dance|drama|art|fest/i', $lowerName)) {
        $theme = 'cultural';
    } elseif (preg_match('/sport|game|athlet|tournament|match/i', $lowerName)) {
        $theme = 'sports';
    } elseif (preg_match('/science|research|lab|experiment|expo/i', $lowerName)) {
        $theme = 'science';
    }
}

$colors = $themes[$theme] ?? $themes['default'];

// Create gradient background
for ($y = 0; $y < $height; $y++) {
    $ratio = $y / $height;
    $r = $colors['bg_start'][0] + ($colors['bg_end'][0] - $colors['bg_start'][0]) * $ratio;
    $g = $colors['bg_start'][1] + ($colors['bg_end'][1] - $colors['bg_start'][1]) * $ratio;
    $b = $colors['bg_start'][2] + ($colors['bg_end'][2] - $colors['bg_start'][2]) * $ratio;
    
    $color = imagecolorallocate($image, $r, $g, $b);
    imagefilledrectangle($image, 0, $y, $width, $y + 1, $color);
}

// Add decorative elements
$accent = imagecolorallocate($image, $colors['accent'][0], $colors['accent'][1], $colors['accent'][2]);
$accentTransparent = imagecolorallocatealpha($image, $colors['accent'][0], $colors['accent'][1], $colors['accent'][2], 100);

// Draw circles (decorative)
imagefilledellipse($image, -50, -50, 300, 300, $accentTransparent);
imagefilledellipse($image, $width + 50, $height + 50, 400, 400, $accentTransparent);
imagefilledellipse($image, $width - 100, 100, 200, 200, $accentTransparent);

// Colors for text
$white = imagecolorallocate($image, $colors['text'][0], $colors['text'][1], $colors['text'][2]);
$subtitle = imagecolorallocate($image, $colors['subtitle'][0], $colors['subtitle'][1], $colors['subtitle'][2]);

// Font paths (use system fonts or bundled fonts)
$fontBold = __DIR__ . '/assets/fonts/Arial-Bold.ttf';
$fontRegular = __DIR__ . '/assets/fonts/Arial.ttf';

// Fallback to GD built-in fonts if TTF not available
$useTTF = false; // Disable TTF for now, use GD built-in fonts

if ($useTTF && file_exists($fontBold) && file_exists($fontRegular)) {
    // Draw event name (title)
    $fontSize = 60;
    $angle = 0;
    $x = 80;
    $y = 250;
    
    // Word wrap for long titles
    $words = explode(' ', $eventName);
    $lines = [];
    $currentLine = '';
    
    foreach ($words as $word) {
        $testLine = $currentLine . ($currentLine ? ' ' : '') . $word;
        $bbox = imagettfbbox($fontSize, $angle, $fontBold, $testLine);
        $textWidth = $bbox[2] - $bbox[0];
        
        if ($textWidth > $width - 160 && $currentLine !== '') {
            $lines[] = $currentLine;
            $currentLine = $word;
        } else {
            $currentLine = $testLine;
        }
    }
    if ($currentLine) $lines[] = $currentLine;
    
    // Draw title lines
    $lineHeight = 70;
    $startY = $y - (count($lines) - 1) * $lineHeight / 2;
    
    foreach ($lines as $i => $line) {
        imagettftext($image, $fontSize, $angle, $x, $startY + $i * $lineHeight, $white, $fontBold, $line);
    }
    
    // Draw description (if provided)
    if ($eventDesc) {
        $descY = $startY + count($lines) * $lineHeight + 20;
        $descSize = 24;
        
        // Truncate description if too long
        if (strlen($eventDesc) > 100) {
            $eventDesc = substr($eventDesc, 0, 97) . '...';
        }
        
        // Word wrap description
        $words = explode(' ', $eventDesc);
        $lines = [];
        $currentLine = '';
        
        foreach ($words as $word) {
            $testLine = $currentLine . ($currentLine ? ' ' : '') . $word;
            $bbox = imagettfbbox($descSize, $angle, $fontRegular, $testLine);
            $textWidth = $bbox[2] - $bbox[0];
            
            if ($textWidth > $width - 160 && $currentLine !== '') {
                $lines[] = $currentLine;
                $currentLine = $word;
            } else {
                $currentLine = $testLine;
            }
        }
        if ($currentLine) $lines[] = $currentLine;
        
        foreach ($lines as $i => $line) {
            if ($i >= 2) break; // Max 2 lines for description
            imagettftext($image, $descSize, $angle, $x, $descY + $i * 35, $subtitle, $fontRegular, $line);
        }
    }
    
    // Draw date and venue at bottom
    $bottomY = $height - 80;
    imagettftext($image, 28, $angle, $x, $bottomY, $accent, $fontBold, '📅 ' . $date);
    if ($venue) {
        imagettftext($image, 24, $angle, $x, $bottomY + 35, $subtitle, $fontRegular, '📍 ' . $venue);
    }
    
    // Draw department badge
    if ($department) {
        $badgeX = $width - 80;
        $badgeY = 80;
        $badgeSize = 20;
        
        // Background for badge
        $badgeBg = imagecolorallocatealpha($image, 255, 255, 255, 80);
        imagefilledrectangle($image, $badgeX - 150, $badgeY - 30, $badgeX + 20, $badgeY + 10, $badgeBg);
        
        imagettftext($image, $badgeSize, $angle, $badgeX - 140, $badgeY, $white, $fontBold, strtoupper($department));
    }
    
} else {
    // Use GD built-in fonts with better layout
    $titleFont = 5; // Largest built-in font
    $textFont = 3;
    $smallFont = 2;
    
    // Draw title (word wrap)
    $titleX = 60;
    $titleY = 180;
    $maxCharsPerLine = 35;
    $titleLines = [];
    $words = explode(' ', $eventName);
    $currentLine = '';
    
    foreach ($words as $word) {
        if (strlen($currentLine . ' ' . $word) <= $maxCharsPerLine) {
            $currentLine .= ($currentLine ? ' ' : '') . $word;
        } else {
            if ($currentLine) $titleLines[] = $currentLine;
            $currentLine = $word;
        }
    }
    if ($currentLine) $titleLines[] = $currentLine;
    
    // Draw title lines
    foreach ($titleLines as $i => $line) {
        imagestring($image, $titleFont, $titleX, $titleY + ($i * 25), strtoupper($line), $white);
    }
    
    // Draw description
    if ($eventDesc) {
        $descY = $titleY + (count($titleLines) * 25) + 30;
        $maxDescChars = 60;
        $descLines = [];
        $words = explode(' ', $eventDesc);
        $currentLine = '';
        
        foreach ($words as $word) {
            if (strlen($currentLine . ' ' . $word) <= $maxDescChars) {
                $currentLine .= ($currentLine ? ' ' : '') . $word;
            } else {
                if ($currentLine) $descLines[] = $currentLine;
                $currentLine = $word;
            }
        }
        if ($currentLine) $descLines[] = $currentLine;
        
        // Max 2 lines for description
        foreach (array_slice($descLines, 0, 2) as $i => $line) {
            imagestring($image, $textFont, $titleX, $descY + ($i * 18), $line, $subtitle);
        }
    }
    
    // Draw date with icon
    $bottomY = $height - 120;
    imagestring($image, $textFont, $titleX, $bottomY, 'DATE: ' . strtoupper($date), $accent);
    
    // Draw venue
    if ($venue) {
        imagestring($image, $textFont, $titleX, $bottomY + 25, 'VENUE: ' . strtoupper(substr($venue, 0, 40)), $subtitle);
    }
    
    // Draw department badge
    if ($department) {
        $deptX = $width - 200;
        $deptY = 60;
        
        // Background for badge
        $badgeBg = imagecolorallocatealpha($image, 255, 255, 255, 80);
        imagefilledrectangle($image, $deptX - 10, $deptY - 10, $deptX + 180, $deptY + 20, $badgeBg);
        
        imagestring($image, $textFont, $deptX, $deptY, strtoupper(substr($department, 0, 20)), $white);
    }
    
    // Draw registration type badge
    if ($regType) {
        $regX = 60;
        $regY = 60;
        
        // Badge background color based on type
        if ($regType === 'Team') {
            $regBg = imagecolorallocatealpha($image, 156, 39, 176, 30); // Purple
            $regText = 'TEAM ENTRY';
        } elseif ($regType === 'Individual') {
            $regBg = imagecolorallocatealpha($image, 33, 150, 243, 30); // Blue
            $regText = 'SOLO ENTRY';
        } else {
            $regBg = imagecolorallocatealpha($image, 255, 152, 0, 30); // Orange
            $regText = 'SOLO OR TEAM';
        }
        
        imagefilledrectangle($image, $regX - 10, $regY - 10, $regX + 120, $regY + 20, $regBg);
        imagestring($image, $textFont, $regX, $regY, $regText, $white);
    }
}

// Add VelTech branding
$brandY = $height - 40;
$brandText = 'VelTech EventPass';
if ($useTTF) {
    imagettftext($image, 18, 0, 80, $brandY, $accent, $fontBold, $brandText);
} else {
    imagestring($image, 3, 80, $brandY - 20, $brandText, $accent);
}

// Output image
header('Content-Type: image/png');
header('Cache-Control: max-age=86400'); // Cache for 1 day
imagepng($image, null, 9); // Max compression
imagedestroy($image);
?>
