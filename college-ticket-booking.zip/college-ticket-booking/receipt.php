<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/BookingService.php';
require_once __DIR__ . '/includes/ReceiptService.php';

$bookingId = trim($_GET['id'] ?? '');
if (empty($bookingId)) {
    header('Location: index.php');
    exit;
}

$bookingId = preg_replace('/[^A-Z0-9]/', '', strtoupper($bookingId));
$booking = BookingService::getConfirmedBooking($bookingId);

if (!$booking) {
    header('Location: index.php');
    exit;
}

// Generate receipt if not already done
if (empty($booking['receipt_path'])) {
    $path = ReceiptService::generateReceipt($bookingId);
    if ($path) {
        header('Location: ' . APP_URL . '/' . $path);
        exit;
    }
}

// Redirect to existing receipt
if (!empty($booking['receipt_path'])) {
    header('Location: ' . APP_URL . '/' . $booking['receipt_path']);
    exit;
}

// Fallback: render inline
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Receipt – <?= htmlspecialchars($bookingId) ?></title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div style="max-width:600px;margin:40px auto;padding:20px;text-align:center">
  <h2>Receipt for <?= htmlspecialchars($bookingId) ?></h2>
  <p>Receipt is being generated. Please check your email.</p>
  <a href="confirmation.php?id=<?= urlencode($bookingId) ?>" class="btn btn-primary" style="text-decoration:none;display:inline-block;margin-top:16px">
    View Booking
  </a>
</div>
</body>
</html>
