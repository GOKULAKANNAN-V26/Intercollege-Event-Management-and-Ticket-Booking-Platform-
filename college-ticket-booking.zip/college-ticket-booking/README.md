# 🎓 CollegeEvents – Ticket Booking System

A production-ready college event ticket booking system built with PHP, MySQL, and Razorpay.

---

## 🚀 Quick Setup (XAMPP on Windows)

### 1. Place Files
Copy the `college-ticket-booking/` folder to:
```
C:\xampp\htdocs\college-ticket-booking\
```

### 2. Create Database
1. Open phpMyAdmin: http://localhost/phpmyadmin
2. Import `database/schema.sql`
3. This creates all tables + sample data

> Note: `database/schema.sql` now includes cancellation and support ticket tables used by the admin panel.

### 3. Configure
Edit `config/config.php`:
- Set your **Razorpay** API keys (get from razorpay.com/dashboard)
- Set your **SMTP** credentials (Gmail App Password recommended)
- Set your **Twilio** credentials for WhatsApp OTP

### 4. Set Permissions
Ensure `uploads/receipts/` is writable by Apache.

### 5. Setup Background Worker
Run as Administrator:
```
worker\setup_task_scheduler.bat
```
This creates a Windows Task Scheduler job that runs every 1 minute.

### 6. Test with Ngrok (for Razorpay Webhooks)
```bash
ngrok http 80
```
Register the webhook URL in Razorpay Dashboard:
```
https://xxxx.ngrok.io/college-ticket-booking/api/webhook.php
```

---

## 🔑 Default Admin Credentials
- URL: http://localhost/college-ticket-booking/admin/login.php
- Username: `admin`
- Password: `password`
- **⚠️ Change immediately in production!**

---

## 📁 Project Structure
```
college-ticket-booking/
├── index.php              # Main events listing page
├── confirmation.php       # Booking confirmation page
├── receipt.php            # Receipt viewer/generator
├── config/
│   ├── config.php         # App configuration
│   └── database.php       # DB connection
├── includes/
│   ├── BookingService.php  # Core booking logic (atomic transactions)
│   ├── PaymentService.php  # Razorpay integration
│   ├── OTPService.php      # OTP generation & verification
│   ├── ReceiptService.php  # HTML receipt generation
│   ├── NotificationService.php # Email & WhatsApp
│   ├── Logger.php          # DB logging
│   └── RateLimiter.php     # Rate limiting
├── api/
│   ├── events.php          # GET events with search/filter
│   ├── send_otp.php        # POST send OTP
│   ├── verify_otp.php      # POST verify OTP + reserve tickets
│   ├── create_order.php    # POST create Razorpay order
│   ├── verify_payment.php  # POST verify payment signature
│   └── webhook.php         # POST Razorpay webhook handler
├── admin/
│   ├── login.php           # Admin login
│   ├── dashboard.php       # Stats & recent bookings
│   ├── events.php          # Add/edit/delete events
│   ├── bookings.php        # View all bookings
│   └── reports.php         # Revenue charts & reports
├── worker/
│   ├── worker.php          # Background job processor (CLI)
│   ├── run_worker.bat      # BAT file for Task Scheduler
│   └── setup_task_scheduler.bat  # One-time setup
├── assets/
│   ├── css/style.css       # Main stylesheet
│   └── js/app.js           # Frontend JavaScript
├── database/
│   └── schema.sql          # Full DB schema + sample data
└── uploads/receipts/       # Generated HTML receipts
```

---

## 🔄 Booking Flow
```
User fills form → OTP sent → OTP verified → Tickets RESERVED (DB lock)
→ Razorpay order created → Payment → Webhook/callback verifies
→ Booking CONFIRMED → Receipt generated → Email + WhatsApp sent
```

## ⏳ Expiry System
- Pending bookings expire after **15 minutes**
- Worker runs every minute to release expired bookings
- Tickets are restored to available count automatically

## 🔒 Security Features
- Prepared statements (no SQL injection)
- OTP hashed with bcrypt
- Razorpay webhook signature verification (HMAC-SHA256)
- Payment idempotency (one payment_id = one booking)
- Session-based CSRF protection for payment
- Rate limiting on OTP send/verify
- Admin session timeout

---

## 🧪 Testing Razorpay
Use test card: `4111 1111 1111 1111`, any future expiry, any CVV.

---

## 📧 PHPMailer (Optional but Recommended)
Install via Composer for reliable email:
```bash
composer require phpmailer/phpmailer
```
Then include the autoloader in `config/config.php`.
