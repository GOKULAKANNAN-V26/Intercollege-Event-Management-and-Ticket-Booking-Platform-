<?php
/**
 * Quick Diagnostic: Check for Orphaned Payments
 * Run this to quickly check if there are any payments that succeeded but have no bookings
 */
require_once 'config/database.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orphaned Payments Check</title>
    <style>
        body { font-family: system-ui; max-width: 1000px; margin: 40px auto; padding: 20px; background: #f5f5f5; }
        .card { background: white; border-radius: 8px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 20px; }
        h1 { color: #003087; margin-top: 0; }
        .status { padding: 12px; border-radius: 6px; margin-bottom: 16px; font-weight: 600; }
        .status-ok { background: #e8f5e9; color: #2e7d32; }
        .status-warning { background: #fff3e0; color: #e65100; }
        .status-error { background: #fce4ec; color: #c62828; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f5f5f5; font-weight: 600; font-size: 13px; }
        .code { font-family: monospace; background: #f5f5f5; padding: 2px 6px; border-radius: 4px; font-size: 12px; }
        .btn { display: inline-block; padding: 10px 20px; background: #003087; color: white; text-decoration: none; border-radius: 6px; font-weight: 600; margin-top: 16px; }
        .btn:hover { background: #002060; }
    </style>
</head>
<body>

<div class="card">
    <h1>💰 Orphaned Payments Check</h1>
    <p>Checking for payments that succeeded at Razorpay but have no corresponding confirmed booking...</p>

    <?php
    try {
        $conn = getDBConnection();
        
        // Find orphaned payments
        $query = "
            SELECT 
                p.id,
                p.razorpay_payment_id,
                p.razorpay_order_id,
                p.booking_ref,
                p.amount,
                p.created_at,
                pb.user_name,
                pb.user_email,
                pb.user_phone,
                pb.ticket_count,
                e.name AS event_name
            FROM payments p
            JOIN pending_bookings pb ON p.booking_ref = pb.booking_ref
            LEFT JOIN events e ON pb.event_id = e.id
            LEFT JOIN confirmed_bookings cb ON p.razorpay_payment_id = cb.payment_id
            WHERE p.status = 'PAID' 
              AND cb.booking_id IS NULL
            ORDER BY p.created_at DESC
        ";
        
        $result = $conn->query($query);
        $orphanedPayments = [];
        $totalAmount = 0;
        
        while ($row = $result->fetch_assoc()) {
            $orphanedPayments[] = $row;
            $totalAmount += $row['amount'];
        }
        
        $count = count($orphanedPayments);
        
        if ($count === 0) {
            echo '<div class="status status-ok">';
            echo '✅ <strong>All Clear!</strong> No orphaned payments found. All payments have corresponding bookings.';
            echo '</div>';
        } else {
            echo '<div class="status status-warning">';
            echo '⚠️ <strong>Found ' . $count . ' orphaned payment(s)</strong><br>';
            echo 'Total amount: ₹' . number_format($totalAmount, 2) . '<br>';
            echo 'These payments succeeded at Razorpay but no confirmed booking was created.';
            echo '</div>';
            
            echo '<table>';
            echo '<thead><tr>';
            echo '<th>Payment ID</th>';
            echo '<th>Customer</th>';
            echo '<th>Event</th>';
            echo '<th>Amount</th>';
            echo '<th>Date</th>';
            echo '</tr></thead>';
            echo '<tbody>';
            
            foreach ($orphanedPayments as $payment) {
                echo '<tr>';
                echo '<td><span class="code">' . htmlspecialchars(substr($payment['razorpay_payment_id'], 0, 20)) . '...</span></td>';
                echo '<td>';
                echo '<strong>' . htmlspecialchars($payment['user_name']) . '</strong><br>';
                echo '<small>' . htmlspecialchars($payment['user_email']) . '</small>';
                echo '</td>';
                echo '<td>';
                echo htmlspecialchars($payment['event_name']) . '<br>';
                echo '<small>' . $payment['ticket_count'] . ' ticket(s)</small>';
                echo '</td>';
                echo '<td><strong>₹' . number_format($payment['amount'], 2) . '</strong></td>';
                echo '<td>' . date('d M Y, h:i A', strtotime($payment['created_at'])) . '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
            
            echo '<a href="admin/payment-reconciliation.php" class="btn">🔄 Go to Reconciliation Tool</a>';
        }
        
        // Show recent successful bookings for comparison
        echo '<h2 style="margin-top: 40px;">Recent Successful Bookings</h2>';
        
        $query = "
            SELECT 
                cb.booking_id,
                cb.user_name,
                cb.user_email,
                cb.total_amount,
                cb.confirmed_at,
                e.name AS event_name
            FROM confirmed_bookings cb
            JOIN events e ON cb.event_id = e.id
            ORDER BY cb.confirmed_at DESC
            LIMIT 10
        ";
        
        $result = $conn->query($query);
        
        if ($result->num_rows > 0) {
            echo '<table>';
            echo '<thead><tr>';
            echo '<th>Booking ID</th>';
            echo '<th>Customer</th>';
            echo '<th>Event</th>';
            echo '<th>Amount</th>';
            echo '<th>Date</th>';
            echo '</tr></thead>';
            echo '<tbody>';
            
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td><span class="code">' . htmlspecialchars($row['booking_id']) . '</span></td>';
                echo '<td>';
                echo '<strong>' . htmlspecialchars($row['user_name']) . '</strong><br>';
                echo '<small>' . htmlspecialchars($row['user_email']) . '</small>';
                echo '</td>';
                echo '<td>' . htmlspecialchars($row['event_name']) . '</td>';
                echo '<td><strong>₹' . number_format($row['total_amount'], 2) . '</strong></td>';
                echo '<td>' . date('d M Y, h:i A', strtotime($row['confirmed_at'])) . '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
        } else {
            echo '<div class="status status-warning">';
            echo 'No confirmed bookings found yet.';
            echo '</div>';
        }
        
        // Show statistics
        echo '<h2 style="margin-top: 40px;">Statistics</h2>';
        
        $stats = $conn->query("
            SELECT 
                COUNT(*) as total_payments,
                SUM(CASE WHEN status = 'PAID' THEN 1 ELSE 0 END) as paid_payments,
                SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) as failed_payments,
                SUM(CASE WHEN status = 'CREATED' THEN 1 ELSE 0 END) as pending_payments
            FROM payments
        ")->fetch_assoc();
        
        $bookingStats = $conn->query("
            SELECT COUNT(*) as total_bookings
            FROM confirmed_bookings
        ")->fetch_assoc();
        
        echo '<table>';
        echo '<tr><td><strong>Total Payments</strong></td><td>' . $stats['total_payments'] . '</td></tr>';
        echo '<tr><td><strong>Paid Payments</strong></td><td>' . $stats['paid_payments'] . '</td></tr>';
        echo '<tr><td><strong>Confirmed Bookings</strong></td><td>' . $bookingStats['total_bookings'] . '</td></tr>';
        echo '<tr><td><strong>Orphaned Payments</strong></td><td style="color: ' . ($count > 0 ? '#e65100' : '#2e7d32') . '; font-weight: 600;">' . $count . '</td></tr>';
        echo '<tr><td><strong>Failed Payments</strong></td><td>' . $stats['failed_payments'] . '</td></tr>';
        echo '<tr><td><strong>Pending Payments</strong></td><td>' . $stats['pending_payments'] . '</td></tr>';
        
        if ($stats['paid_payments'] > 0) {
            $confirmationRate = round(($bookingStats['total_bookings'] / $stats['paid_payments']) * 100, 2);
            echo '<tr><td><strong>Booking Confirmation Rate</strong></td><td style="font-weight: 600; color: ' . ($confirmationRate >= 95 ? '#2e7d32' : '#e65100') . ';">' . $confirmationRate . '%</td></tr>';
        }
        
        echo '</table>';
        
    } catch (Exception $e) {
        echo '<div class="status status-error">';
        echo '❌ <strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
        echo '</div>';
    }
    ?>

    <div style="margin-top: 30px; padding-top: 20px; border-top: 2px solid #ddd;">
        <h3>What to Do Next</h3>
        <ul>
            <li>If orphaned payments found: Use the <a href="admin/payment-reconciliation.php">Payment Reconciliation Tool</a></li>
            <li>Check error logs: <code>logs/error.log</code></li>
            <li>Verify database schema: <a href="check_database.php">Database Check</a></li>
            <li>Read documentation: <code>PAYMENT_RECONCILIATION_GUIDE.md</code></li>
        </ul>
    </div>
</div>

<div style="text-align: center; margin-top: 20px; color: #888; font-size: 13px;">
    <p>Last checked: <?= date('Y-m-d H:i:s') ?></p>
    <p><a href="index.php" style="color: #003087;">← Back to Home</a> | 
       <a href="admin/dashboard.php" style="color: #003087;">Admin Dashboard</a></p>
</div>

</body>
</html>
