<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/PaymentService.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

session_start();

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

$orderId    = trim($input['razorpay_order_id'] ?? '');
$paymentId  = trim($input['razorpay_payment_id'] ?? '');
$signature  = trim($input['razorpay_signature'] ?? '');
$bookingRef = trim($input['booking_ref'] ?? '');

// Validate session
$sessionRef = $_SESSION['booking_ref'] ?? '';
if (empty($bookingRef) || $bookingRef !== $sessionRef) {
    session_write_close();
    echo json_encode(['success' => false, 'message' => 'Invalid session.']);
    exit;
}

if (empty($orderId) || empty($paymentId) || empty($signature)) {
    session_write_close();
    echo json_encode(['success' => false, 'message' => 'Missing payment data.']);
    exit;
}

// Verify signature
if (!PaymentService::verifyPaymentSignature($orderId, $paymentId, $signature)) {
    session_write_close();
    echo json_encode(['success' => false, 'message' => 'Payment verification failed. Please contact support.']);
    exit;
}

// Process payment
$result = PaymentService::processSuccessfulPayment($orderId, $paymentId);

if ($result['success']) {
    // Clear booking session
    unset($_SESSION['booking_ref'], $_SESSION['booking_data'], $_SESSION['booking_intent']);
    session_write_close();

    echo json_encode([
        'success'    => true,
        'booking_id' => $result['booking_id'],
        'message'    => 'Payment verified and booking confirmed!',
        'redirect'   => APP_URL . '/confirmation.php?id=' . urlencode($result['booking_id'])
    ]);
} else {
    session_write_close();
    echo json_encode($result);
}
?>
