<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/OTPService.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

$name       = trim($input['name'] ?? '');
$email      = trim($input['email'] ?? '');
$phone      = trim($input['phone'] ?? '');
$eventId    = (int)($input['event_id'] ?? 0);
$tickets    = (int)($input['tickets'] ?? 0);
$teamName   = trim($input['team_name'] ?? '');
$teamMembers = is_array($input['team_members'] ?? null) ? array_filter(array_map('trim', $input['team_members'])) : [];

// Normalize phone number to match frontend validation
$phone = preg_replace('/[^0-9\+]/', '', $phone);

// Validate basic fields
$errors = [];
if (empty($name) || strlen($name) < 2) {
    $errors[] = 'Name must be at least 2 characters.';
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Invalid email address.';
}
if (!preg_match('/^\+?[0-9]{10,15}$/', $phone)) {
    $errors[] = 'Invalid phone number.';
}
if ($eventId < 1) {
    $errors[] = 'Invalid event.';
}
if ($tickets < 1 || $tickets > MAX_TICKETS_PER_BOOKING) {
    $errors[] = 'Ticket count must be between 1 and ' . MAX_TICKETS_PER_BOOKING . '.';
}

if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
    exit;
}

// Fetch event details to validate registration rules
try {
    $conn = getDBConnection();
    $stmt = $conn->prepare(
        "SELECT registration_type, min_team_members, max_team_members, available_tickets 
         FROM events WHERE id = ? AND status = 'active'"
    );
    $stmt->bind_param('i', $eventId);
    $stmt->execute();
    $result = $stmt->get_result();
    $event = $result->fetch_assoc();
    $stmt->close();
    
    if (!$event) {
        echo json_encode(['success' => false, 'message' => 'Event not found or inactive.']);
        exit;
    }
    
    // Validate registration type rules
    $regType = $event['registration_type'];
    $minTeam = (int)$event['min_team_members'];
    $maxTeam = (int)$event['max_team_members'];
    $isTeamRegistration = !empty($teamName);
    
    // Individual (Solo) events
    if ($regType === 'Individual') {
        if ($tickets !== 1) {
            echo json_encode(['success' => false, 'message' => 'Solo events allow only 1 ticket per booking.']);
            exit;
        }
        if ($isTeamRegistration) {
            echo json_encode(['success' => false, 'message' => 'Team registration is not allowed for solo events.']);
            exit;
        }
    }
    
    // Team events
    if ($regType === 'Team') {
        if ($tickets < $minTeam) {
            echo json_encode(['success' => false, 'message' => "Team events require at least {$minTeam} members."]);
            exit;
        }
        if ($maxTeam > 0 && $tickets > $maxTeam) {
            echo json_encode(['success' => false, 'message' => "Team events allow maximum {$maxTeam} members."]);
            exit;
        }
        if (empty($teamName)) {
            echo json_encode(['success' => false, 'message' => 'Team name is required for team events.']);
            exit;
        }
        // Validate team member count (should be tickets - 1 since main registrant is counted)
        $requiredTeammates = $minTeam - 1;
        if (count($teamMembers) < $requiredTeammates) {
            echo json_encode(['success' => false, 'message' => "Please provide at least {$requiredTeammates} teammate name(s)."]);
            exit;
        }
    }
    
    // Both (Solo or Team)
    if ($regType === 'Both') {
        if ($isTeamRegistration) {
            // Team registration rules
            if ($tickets < $minTeam) {
                echo json_encode(['success' => false, 'message' => "Team registration requires at least {$minTeam} members."]);
                exit;
            }
            if ($maxTeam > 0 && $tickets > $maxTeam) {
                echo json_encode(['success' => false, 'message' => "Team registration allows maximum {$maxTeam} members."]);
                exit;
            }
            $requiredTeammates = $minTeam - 1;
            if (count($teamMembers) < $requiredTeammates) {
                echo json_encode(['success' => false, 'message' => "Please provide at least {$requiredTeammates} teammate name(s)."]);
                exit;
            }
        } else {
            // Solo registration rules
            if ($tickets !== 1) {
                echo json_encode(['success' => false, 'message' => 'Solo registration allows only 1 ticket.']);
                exit;
            }
        }
    }
    
    // Check available tickets
    if ($tickets > $event['available_tickets']) {
        echo json_encode(['success' => false, 'message' => 'Not enough tickets available.']);
        exit;
    }
    
} catch (Exception $e) {
    error_log("Event validation error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to validate event details.']);
    exit;
}

// Store booking intent in session
session_start();
$_SESSION['booking_intent'] = [
    'name'         => $name,
    'email'        => $email,
    'phone'        => $phone,
    'event_id'     => $eventId,
    'tickets'      => $tickets,
    'team_name'    => $teamName,
    'team_members' => $teamMembers,
    'ts'           => time(),
];
session_write_close();

$result = OTPService::sendOTP($phone, $email);
echo json_encode($result);
?>
