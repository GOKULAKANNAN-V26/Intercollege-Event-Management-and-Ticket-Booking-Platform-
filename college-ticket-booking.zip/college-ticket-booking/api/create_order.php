<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/PaymentService.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

session_start();

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

$bookingRef = trim($input['booking_ref'] ?? '');

// Validate booking ref from session (CSRF protection)
$sessionRef = $_SESSION['booking_ref'] ?? '';
if (empty($bookingRef) || $bookingRef !== $sessionRef) {
    session_write_close();
    echo json_encode(['success' => false, 'message' => 'Invalid or expired booking session.']);
    exit;
}

session_write_close();

$result = PaymentService::createOrder($bookingRef);
echo json_encode($result);
?>
