<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Only GET allowed
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    $conn = getDBConnection();

    // Sanitize inputs
    $search     = trim($_GET['search'] ?? '');
    $department = trim($_GET['department'] ?? '');
    $date       = trim($_GET['date'] ?? '');
    $eventId    = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    // Single event
    if ($eventId > 0) {
        $stmt = $conn->prepare(
            "SELECT id, name, description, department, venue, event_date, 
                    ticket_price, total_tickets, available_tickets, image, status,
                    registration_type, min_team_members, max_team_members
             FROM events WHERE id = ? AND status = 'active'"
        );
        $stmt->bind_param('i', $eventId);
        $stmt->execute();
        $result = $stmt->get_result();
        $event = $result->fetch_assoc();
        $stmt->close();

        if (!$event) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Event not found']);
            exit;
        }

        $event = formatEvent($event);
        echo json_encode(['success' => true, 'event' => $event]);
        exit;
    }

    // Build query with filters
    $where = ["status = 'active'", "event_date >= NOW()"];
    $params = [];
    $types  = '';

    if ($search !== '') {
        $where[] = "(name LIKE ? OR description LIKE ? OR department LIKE ?)";
        $searchParam = '%' . $search . '%';
        $params = array_merge($params, [$searchParam, $searchParam, $searchParam]);
        $types .= 'sss';
    }

    if ($department !== '') {
        $where[] = "department = ?";
        $params[] = $department;
        $types .= 's';
    }

    if ($date !== '') {
        $where[] = "DATE(event_date) = ?";
        $params[] = $date;
        $types .= 's';
    }

    $whereClause = implode(' AND ', $where);
    $sql = "SELECT id, name, description, department, venue, event_date, 
                   ticket_price, total_tickets, available_tickets, image, status,
                   registration_type, min_team_members, max_team_members
            FROM events WHERE $whereClause ORDER BY event_date ASC";

    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    $events = [];
    while ($row = $result->fetch_assoc()) {
        $events[] = formatEvent($row);
    }
    $stmt->close();

    // Get departments for filter
    $deptResult = $conn->query(
        "SELECT DISTINCT department FROM events WHERE status = 'active' ORDER BY department"
    );
    $departments = [];
    while ($row = $deptResult->fetch_assoc()) {
        $departments[] = $row['department'];
    }

    echo json_encode([
        'success'     => true,
        'events'      => $events,
        'departments' => $departments,
        'total'       => count($events)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error. Please try again.']);
}

function formatEvent(array $e): array {
    $available = (int)$e['available_tickets'];
    $total     = (int)$e['total_tickets'];
    $price     = (float)$e['ticket_price'];
    $regType   = $e['registration_type'] ?? 'Individual';
    $minTeam   = (int)($e['min_team_members'] ?? 2);
    $maxTeam   = (int)($e['max_team_members'] ?? 0);

    $urgency = '';
    if ($available === 0) {
        $urgency = 'sold_out';
    } elseif ($available <= 10) {
        $urgency = 'critical';
    } elseif ($available <= 50) {
        $urgency = 'low';
    } else {
        $urgency = 'available';
    }

    return [
        'id'                => (int)$e['id'],
        'name'              => $e['name'],
        'description'       => $e['description'],
        'department'        => $e['department'],
        'venue'             => $e['venue'],
        'event_date'        => $e['event_date'],
        'event_date_formatted' => date('D, d M Y', strtotime($e['event_date'])),
        'event_time_formatted' => date('h:i A', strtotime($e['event_date'])),
        'ticket_price'      => $price,
        'ticket_price_formatted' => $price == 0 ? 'FREE' : '₹' . number_format($price, 2),
        'total_tickets'     => $total,
        'available_tickets' => $available,
        'urgency'           => $urgency,
        'image'             => $e['image'],
        'status'            => $e['status'],
        'registration_type' => $regType,
        'min_team_members'  => $minTeam,
        'max_team_members'  => $maxTeam,
    ];
}
?>
