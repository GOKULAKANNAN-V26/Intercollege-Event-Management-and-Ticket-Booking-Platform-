<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/OTPService.php';
require_once __DIR__ . '/../includes/BookingService.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

session_start();

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

$otp = trim($input['otp'] ?? '');
$token = trim($input['token'] ?? $input['access_token'] ?? $input['accessToken'] ?? $input['jwt_token'] ?? $input['idToken'] ?? $input['firebase_token'] ?? '');
$widgetData = $input['widget_data'] ?? null;

$useToken = !empty($token);
$useWidget = $useToken || !empty($widgetData);
if (!$useWidget && !preg_match('/^\d{4}$/', $otp)) {
    echo json_encode(['success' => false, 'message' => 'OTP must be 4 digits.']);
    exit;
}

// Get booking intent from session
$intent = $_SESSION['booking_intent'] ?? null;
if (!$intent || (time() - $intent['ts']) > 1800) {
    session_write_close();
    echo json_encode(['success' => false, 'message' => 'Session expired. Please start again.']);
    exit;
}

if ($useToken) {
    // Check if this is a Firebase token or MSG91 widget token
    $isFirebaseToken = (defined('OTP_PROVIDER') && OTP_PROVIDER === 'firebase') || 
                       preg_match('/^eyJ/', $token); // Firebase tokens are JWT (start with eyJ)
    
    if ($isFirebaseToken) {
        // Firebase token verification path
        if (!$intent) {
            session_write_close();
            echo json_encode(['success' => false, 'message' => 'Session expired. Please start again.']);
            exit;
        }
        
        // Verify the Firebase token server-side
        $verifyResult = OTPService::verifyFirebaseToken($token);
        if (!$verifyResult['success']) {
            session_write_close();
            echo json_encode($verifyResult);
            exit;
        }
    } else {
        // MSG91 widget token verification path
        if (!$intent) {
            session_write_close();
            echo json_encode(['success' => false, 'message' => 'Session expired. Please start again.']);
            exit;
        }
        
        // Verify the widget token server-side with MSG91
        $verifyResult = OTPService::verifyMSG91WidgetToken($token);
        if (!$verifyResult['success']) {
            session_write_close();
            echo json_encode($verifyResult);
            exit;
        }
    }
} elseif (!empty($widgetData)) {
    // Legacy MSG91 widget data path
    if (!$intent) {
        session_write_close();
        echo json_encode(['success' => false, 'message' => 'Session expired. Please start again.']);
        exit;
    }
    
    // Extract token from widget data if available
    $tokenFromData = $widgetData['access_token'] ?? $widgetData['accessToken'] ?? $widgetData['token'] ?? null;
    if ($tokenFromData) {
        $verifyResult = OTPService::verifyMSG91WidgetToken($tokenFromData);
        if (!$verifyResult['success']) {
            session_write_close();
            echo json_encode($verifyResult);
            exit;
        }
    }
} else {
    // Standard OTP verification path (manual 4-digit entry).
    $verifyResult = OTPService::verifyOTP($intent['phone'], $intent['email'], $otp);
    if (!$verifyResult['success']) {
        session_write_close();
        echo json_encode($verifyResult);
        exit;
    }
}

// Reserve tickets
$reserveResult = BookingService::reserveTickets(
    $intent['event_id'],
    $intent['name'],
    $intent['email'],
    $intent['phone'],
    $intent['tickets'],
    $intent['team_name'] ?? '',
    $intent['team_members'] ?? []
);

if (!$reserveResult['success']) {
    session_write_close();
    echo json_encode($reserveResult);
    exit;
}

// Store booking ref in session
$_SESSION['booking_ref']  = $reserveResult['booking_ref'];
$_SESSION['booking_data'] = $reserveResult;

// Check if this is a free event (₹0)
$isFreeEvent = $reserveResult['total_amount'] <= 0;

if ($isFreeEvent) {
    // For free events, directly confirm the booking without payment
    require_once __DIR__ . '/../includes/BookingService.php';
    
    $freeBookingId = 'FREE_' . $reserveResult['booking_ref'];
    $confirmResult = BookingService::confirmBooking(
        $reserveResult['booking_ref'],
        $freeBookingId,
        'FREE_EVENT'
    );
    
    if ($confirmResult['success']) {
        $_SESSION['booking_confirmed'] = true;
        $_SESSION['confirmed_booking_id'] = $confirmResult['booking_id'];
        session_write_close();
        
        echo json_encode([
            'success'      => true,
            'message'      => 'Free event booking confirmed!',
            'booking_ref'  => $reserveResult['booking_ref'],
            'booking_id'   => $confirmResult['booking_id'],
            'total_amount' => 0,
            'event_name'   => $reserveResult['event_name'],
            'is_free'      => true,
            'redirect'     => 'confirmation.php?id=' . $confirmResult['booking_id']
        ]);
        exit;
    }
}

session_write_close();

echo json_encode([
    'success'      => true,
    'message'      => 'OTP verified and tickets reserved.',
    'booking_ref'  => $reserveResult['booking_ref'],
    'total_amount' => $reserveResult['total_amount'],
    'event_name'   => $reserveResult['event_name'],
    'expires_at'   => $reserveResult['expires_at'],
    'is_free'      => $isFreeEvent
]);
?>
