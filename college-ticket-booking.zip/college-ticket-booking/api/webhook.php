<?php
/**
 * Razorpay Webhook Handler
 * This endpoint must be registered in Razorpay Dashboard.
 * Use Ngrok URL for local testing: https://xxxx.ngrok.io/college-ticket-booking/api/webhook.php
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/PaymentService.php';
require_once __DIR__ . '/../includes/Logger.php';

// Disable output buffering for webhooks
ob_end_clean();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$rawBody = file_get_contents('php://input');
$webhookSignature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';

if (empty($rawBody)) {
    http_response_code(400);
    echo json_encode(['error' => 'Empty payload']);
    exit;
}

Logger::info('Webhook', 'Received webhook', [
    'signature_present' => !empty($webhookSignature),
    'body_length'       => strlen($rawBody)
]);

$result = PaymentService::handleWebhook($rawBody, $webhookSignature);

if ($result['success']) {
    http_response_code(200);
    echo json_encode(['status' => 'ok']);
} else {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $result['message']]);
}
?>
