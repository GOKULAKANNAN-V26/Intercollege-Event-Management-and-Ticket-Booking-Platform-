# 🔑 Finding Your MSG91 Auth Key

## What You Already Have
You have your **Widget Token**:
```
513951TEA34qlnAx069f8f158P1  ✓ (for frontend widget)
```

## What You Need To Find
Your **Auth Key** (API Key) for backend SMS sending:
```
????????????????????????  ← Need to find this
```

---

## 📍 Step-by-Step: Where to Find Your Auth Key

### Method 1: MSG91 Dashboard (Recommended)

1. **Go to** https://www.msg91.com
2. **Log in** with your account
3. **Click** your profile icon → **Account Settings** (or look for Settings)
4. **Find** the tab labeled:
   - "API Keys" or
   - "API Info" or
   - "API Configuration"
5. **Look for** a field labeled:
   - "Auth Key" or
   - "API Key" or
   - "Authentication Key"
6. **Copy** the entire value (long string of characters)

### Method 2: Direct URL

Try accessing directly:
- https://www.msg91.com/user/api

Look for the Auth Key field on that page.

---

## 🔍 What Auth Key Looks Like

It's typically a **long alphanumeric string**, like:
```
abc123def456xyz789abc123def456xyz789abc123def456xyz789
```

Or sometimes with numbers like:
```
9876543210abcdefghijklmnopqrstuvwxyz1234567890
```

---

## ❌ What It's NOT

Don't confuse with:
- ❌ Widget Token (you already have this)
- ❌ Account ID
- ❌ Username or Email
- ❌ Widget ID

---

## 📋 Once You Find It

Copy your Auth Key and update **`config/config.php`**:

```php
define('MSG91_API_KEY', 'PASTE_YOUR_AUTH_KEY_HERE');
```

Example:
```php
define('MSG91_API_KEY', 'abc123def456xyz789abc123def456xyz789');
```

---

## 🆘 Can't Find It?

If you can't find your Auth Key:

1. **Log out** from MSG91
2. **Log back in**
3. Check under:
   - Settings → API
   - Dashboard → Integrations
   - My Account → Developer Options

Or contact MSG91 support: **https://www.msg91.com/support**

---

## ✅ After Finding It

1. Copy the Auth Key
2. Add to `config/config.php`
3. Test by booking an event
4. User should receive SMS within seconds
