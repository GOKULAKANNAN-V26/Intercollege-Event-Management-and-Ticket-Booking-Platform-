<?php
require_once 'config/database.php';

header('Content-Type: text/plain');

echo "=== DATABASE DIAGNOSTIC CHECK ===\n\n";

try {
    $conn = getDBConnection();
    echo "✓ Database connection successful\n\n";
    
    // Check confirmed_bookings table
    echo "--- CONFIRMED BOOKINGS ---\n";
    $result = $conn->query('SELECT COUNT(*) as count FROM confirmed_bookings');
    $row = $result->fetch_assoc();
    echo "Total confirmed bookings: " . $row['count'] . "\n\n";
    
    if ($row['count'] > 0) {
        echo "Recent bookings:\n";
        $result = $conn->query('SELECT booking_id, user_email, event_id, ticket_count, status, confirmed_at FROM confirmed_bookings ORDER BY confirmed_at DESC LIMIT 10');
        while ($row = $result->fetch_assoc()) {
            echo "  - " . $row['booking_id'] . " | " . $row['user_email'] . " | Status: " . $row['status'] . " | " . $row['confirmed_at'] . "\n";
        }
    } else {
        echo "  No confirmed bookings found.\n";
    }
    
    // Check pending bookings
    echo "\n--- PENDING BOOKINGS ---\n";
    $result = $conn->query('SELECT COUNT(*) as count, status FROM pending_bookings GROUP BY status');
    while ($row = $result->fetch_assoc()) {
        echo "  " . $row['status'] . ": " . $row['count'] . "\n";
    }
    
    // Check recent pending bookings
    echo "\nRecent pending bookings:\n";
    $result = $conn->query('SELECT booking_ref, user_email, status, total_amount, created_at FROM pending_bookings ORDER BY created_at DESC LIMIT 10');
    while ($row = $result->fetch_assoc()) {
        echo "  - " . $row['booking_ref'] . " | " . $row['user_email'] . " | " . $row['status'] . " | ₹" . $row['total_amount'] . " | " . $row['created_at'] . "\n";
    }
    
    // Check payments
    echo "\n--- PAYMENTS ---\n";
    $result = $conn->query('SELECT COUNT(*) as count, status FROM payments GROUP BY status');
    while ($row = $result->fetch_assoc()) {
        echo "  " . $row['status'] . ": " . $row['count'] . "\n";
    }
    
    // Check events
    echo "\n--- EVENTS ---\n";
    $result = $conn->query('SELECT id, name, ticket_price, available_tickets, status FROM events WHERE status = "active"');
    while ($row = $result->fetch_assoc()) {
        echo "  - " . $row['name'] . " | ₹" . $row['ticket_price'] . " | " . $row['available_tickets'] . " available\n";
    }
    
    echo "\n=== END DIAGNOSTIC ===\n";
    
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
}
?>
