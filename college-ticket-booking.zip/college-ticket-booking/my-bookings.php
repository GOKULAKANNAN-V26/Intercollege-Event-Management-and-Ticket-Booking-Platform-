<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['user_id'])) {
    session_write_close();
    header('Location: login.php?redirect=my-bookings.php');
    exit;
}
$userEmail = $_SESSION['user_email'];
session_write_close();

$conn = getDBConnection();
$stmt = $conn->prepare(
    "SELECT cb.*, e.name AS event_name, e.venue, e.event_date, e.department
     FROM confirmed_bookings cb
     JOIN events e ON cb.event_id = e.id
     WHERE cb.user_email = ?
     ORDER BY cb.confirmed_at DESC"
);
$stmt->bind_param('s', $userEmail);
$stmt->execute();
$result   = $stmt->get_result();
$bookings = [];
while ($row = $result->fetch_assoc()) $bookings[] = $row;
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Bookings – VelTech EventPass</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body { background:#f4f6fb; }
    .page-wrap { max-width:900px; margin:30px auto; padding:0 16px 40px; }
    .page-title { font-size:22px; font-weight:800; color:#003087; margin-bottom:20px; }
    .booking-card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.08); margin-bottom:16px; display:flex; gap:20px; align-items:flex-start; flex-wrap:wrap; }
    .booking-badge { background:#003087; color:#fff; border-radius:8px; padding:10px 14px; text-align:center; min-width:80px; flex-shrink:0; }
    .booking-badge .tickets { font-size:26px; font-weight:800; line-height:1; }
    .booking-badge .label   { font-size:10px; opacity:.8; margin-top:2px; }
    .booking-info { flex:1; min-width:200px; }
    .booking-info h3 { font-size:16px; font-weight:700; color:#003087; margin-bottom:6px; }
    .booking-meta { display:flex; flex-wrap:wrap; gap:10px; font-size:13px; color:#666; margin-bottom:10px; }
    .booking-meta span { display:flex; align-items:center; gap:4px; }
    .booking-id { font-size:11px; color:#888; font-family:monospace; background:#f4f6fb; padding:3px 8px; border-radius:4px; display:inline-block; }
    .booking-actions { display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }
    .status-badge { padding:3px 10px; border-radius:20px; font-size:11px; font-weight:700; }
    .status-PAID,.status-CONFIRMED { background:#e8f5e9; color:#2e7d32; }
    .status-CANCELLED { background:#fce4ec; color:#c62828; }
    .status-REFUNDED  { background:#e3f2fd; color:#1565c0; }
  </style>
</head>
<body>
<?php require_once 'includes/navbar.php'; ?>

<div class="page-wrap">
  <h1 class="page-title">🎟 My Bookings</h1>

  <?php if (!empty($_GET['cancelled'])): ?>
  <div class="alert alert-success">✅ Cancellation request submitted successfully. We'll process it within 2-3 business days.</div>
  <?php endif; ?>

  <?php if (empty($bookings)): ?>
  <div style="text-align:center;padding:60px 20px;background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,48,135,0.08)">
    <div style="font-size:56px;margin-bottom:16px">🎫</div>
    <h3 style="color:#003087;margin-bottom:8px">No bookings yet</h3>
    <p style="color:#888;margin-bottom:20px">You haven't booked any tickets yet.</p>
    <a href="index.php" class="btn btn-primary" style="text-decoration:none">Browse Events</a>
  </div>
  <?php else: ?>

  <p style="color:#666;font-size:14px;margin-bottom:20px"><?= count($bookings) ?> booking(s) found</p>

  <?php foreach ($bookings as $b):
    $eventDate = date('D, d M Y', strtotime($b['event_date']));
    $eventTime = date('h:i A', strtotime($b['event_date']));
    $isPast    = strtotime($b['event_date']) < time();
    $canCancel = $b['status'] === 'PAID' || $b['status'] === 'CONFIRMED';
  ?>
  <div class="booking-card">
    <div class="booking-badge">
      <div class="tickets"><?= $b['ticket_count'] ?></div>
      <div class="label">TICKET<?= $b['ticket_count'] > 1 ? 'S' : '' ?></div>
    </div>
    <div class="booking-info">
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:6px">
        <h3 style="margin:0"><?= htmlspecialchars($b['event_name']) ?></h3>
        <span class="status-badge status-<?= $b['status'] ?>"><?= $b['status'] ?></span>
        <?php if ($isPast): ?>
        <span style="background:#f5f5f5;color:#888;padding:2px 8px;border-radius:20px;font-size:11px">Past Event</span>
        <?php endif; ?>
      </div>
      <div class="booking-meta">
        <span>📅 <?= $eventDate ?></span>
        <span>🕐 <?= $eventTime ?></span>
        <span>📍 <?= htmlspecialchars($b['venue']) ?></span>
        <span>🏛 <?= htmlspecialchars($b['department']) ?></span>
      </div>
      <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
        <span class="booking-id"><?= htmlspecialchars($b['booking_id']) ?></span>
        <span style="font-size:15px;font-weight:800;color:#003087">
          ₹<?= number_format($b['total_amount'], 2) ?>
        </span>
        <span style="font-size:12px;color:#888">
          Booked <?= date('d M Y', strtotime($b['confirmed_at'])) ?>
        </span>
      </div>
      <div class="booking-actions">
        <?php if ($b['receipt_path']): ?>
        <a href="<?= htmlspecialchars($b['receipt_path']) ?>" target="_blank"
           class="btn btn-outline" style="font-size:12px;padding:6px 14px;text-decoration:none">
          📄 Receipt
        </a>
        <?php endif; ?>
        <?php if ($canCancel && !$isPast): ?>
        <a href="modify-booking.php?booking_id=<?= urlencode($b['booking_id']) ?>"
           class="btn" style="font-size:12px;padding:6px 14px;background:#e3f2fd;color:#1565c0;text-decoration:none;border-radius:8px;font-weight:600">
          ✏️ Modify
        </a>
        <a href="cancel-ticket.php?booking_id=<?= urlencode($b['booking_id']) ?>"
           class="btn" style="font-size:12px;padding:6px 14px;background:#fce4ec;color:#c62828;text-decoration:none;border-radius:8px;font-weight:600">
          ❌ Cancel
        </a>
        <?php endif; ?>
        <a href="support.php?booking_id=<?= urlencode($b['booking_id']) ?>"
           class="btn" style="font-size:12px;padding:6px 14px;background:#e6edf8;color:#003087;text-decoration:none;border-radius:8px;font-weight:600">
          💬 Support
        </a>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
</body>
</html>
