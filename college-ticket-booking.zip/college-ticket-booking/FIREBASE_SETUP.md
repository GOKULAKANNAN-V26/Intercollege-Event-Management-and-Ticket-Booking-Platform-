# Firebase OTP Integration Setup

Firebase has been integrated into your VelTech EventPass system for OTP verification. This guide will help you complete the configuration.

## Prerequisites

1. A Firebase Project created at https://console.firebase.google.com
2. Firebase Authentication enabled with Phone Number provider
3. Firebase Web SDK compatibility (Node.js 12+ for backend verification)

## Step-by-Step Configuration

### 1. Get Your Firebase Configuration

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select your project (or create a new one)
3. Click the Settings icon (⚙️) → Project Settings
4. Under "Your apps" section, click on your Web app
5. Copy the entire firebaseConfig object

### 2. Update config/config.php

Your `FIREBASE_API_KEY` is already set. Now you need to add the complete Firebase configuration:

```php
// In config/config.php, update the Firebase section:

define('FIREBASE_API_KEY', 'YOUR_API_KEY_HERE');
define('FIREBASE_AUTH_DOMAIN', 'your-project.firebaseapp.com');
define('FIREBASE_PROJECT_ID', 'your-project-id');
define('FIREBASE_STORAGE_BUCKET', 'your-project.appspot.com');
define('FIREBASE_MESSAGING_SENDER_ID', 'your-sender-id');
define('FIREBASE_APP_ID', 'your-app-id');
```

### 3. Update index.php Firebase Configuration

In `index.php`, update the firebaseConfig object with your project details:

```javascript
const firebaseConfig = {
  apiKey: "<?php echo defined('FIREBASE_API_KEY') ? htmlspecialchars(FIREBASE_API_KEY) : ''; ?>",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "your-sender-id",
  appId: "your-app-id"
};
```

### 4. Enable Phone Authentication

1. In Firebase Console, go to Authentication → Sign-in method
2. Click "Phone" provider
3. Toggle it ON
4. Add reCAPTCHA Enterprise or reCAPTCHA v3 key if required

### 5. Configure OTP Provider

In `config/config.php`, set the OTP provider:

```php
// Options: 'msg91', 'firebase', 'hybrid'
define('OTP_PROVIDER', 'firebase');
```

- `firebase` - Use Firebase for all OTP operations
- `msg91` - Use MSG91 (original setup)
- `hybrid` - Try Firebase first, fall back to MSG91

### 6. Test Firebase Integration

Visit your booking page and attempt an OTP verification. The system will:
1. Send OTP via Firebase SMS
2. Verify the token server-side
3. Complete the booking flow

## How It Works

### OTP Flow with Firebase

1. **User enters phone number** → Frontend collects phone and email
2. **Backend generates OTP** → Stored in database with hash
3. **Firebase sends SMS** → Firebase Authentication handles SMS delivery
4. **User enters OTP** → Frontend collects 4-digit code
5. **Verification** → Backend validates OTP hash or Firebase token
6. **Booking proceeds** → On success, reserves tickets and starts payment flow

### Fallback Mechanism

If Firebase fails:
- With `hybrid` mode: System automatically tries MSG91
- With `firebase` mode: User sees error and can retry
- With `msg91` mode: Firebase is disabled entirely

## Troubleshooting

### Issue: Firebase SDK not loaded
**Solution**: Ensure `OTP_PROVIDER` is set to `'firebase'` in config.php

### Issue: "Phone number format is incorrect"
**Solution**: Ensure phone numbers include country code (+91 for India)

### Issue: reCAPTCHA errors
**Solution**: Update reCAPTCHA keys in Firebase Console → Project Settings → App credentials

### Issue: Token verification fails
**Solution**: 
1. Check Firebase API key is correct
2. Verify Firebase project ID matches
3. Check phone provider is enabled in Firebase Console

## Security Notes

- Store Firebase credentials securely (use environment variables in production)
- Enable reCAPTCHA to prevent abuse
- Set Firebase Realtime Database rules to private
- Enable authentication state persistence

## Production Checklist

- [ ] Firebase project created and configured
- [ ] Phone authentication provider enabled
- [ ] reCAPTCHA configured
- [ ] All config keys updated in config/config.php
- [ ] Firebase Web SDK credentials verified in index.php
- [ ] Tested OTP flow end-to-end
- [ ] MSG91 fallback configured (optional)
- [ ] Error logging enabled

## Support

For Firebase issues, consult:
- [Firebase Auth Documentation](https://firebase.google.com/docs/auth/phone-auth)
- [Firebase Admin SDK](https://firebase.google.com/docs/admin/setup)

For MSG91 fallback support, refer to MSG91 documentation.
