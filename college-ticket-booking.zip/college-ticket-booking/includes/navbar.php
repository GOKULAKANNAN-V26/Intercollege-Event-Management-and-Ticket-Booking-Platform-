<?php
// Shared navbar for all public pages
if (session_status() === PHP_SESSION_NONE) session_start();
$loggedIn  = !empty($_SESSION['user_id']);
$userName  = $_SESSION['user_name'] ?? '';
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<nav class="navbar" role="navigation" aria-label="Main navigation">
  <div class="navbar-inner">
    <a href="<?= APP_URL ?>/index.php" class="navbar-brand" aria-label="VelTech EventPass Home">
      <img src="<?= APP_URL ?>/assets/images/veltech-logo.svg" alt="Vel Tech Logo" style="height:46px;width:auto">
      <div style="display:flex;flex-direction:column;line-height:1.2">
        <span style="font-size:17px;font-weight:800;color:#003087">🎟 EventPass</span>
        <span style="font-size:10px;color:#666;max-width:240px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
          Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute
        </span>
      </div>
    </a>
    <div class="navbar-links" style="display:flex;align-items:center;gap:6px">
      <a href="<?= APP_URL ?>/index.php" <?= $currentPage==='index.php'?'style="color:#003087;font-weight:700"':'' ?>>Events</a>
      <a href="<?= APP_URL ?>/support.php" <?= $currentPage==='support.php'?'style="color:#003087;font-weight:700"':'' ?>>Support</a>
      <?php if ($loggedIn): ?>
        <a href="<?= APP_URL ?>/my-bookings.php" <?= $currentPage==='my-bookings.php'?'style="color:#003087;font-weight:700"':'' ?>>My Bookings</a>
        <a href="<?= APP_URL ?>/cancel-ticket.php" <?= $currentPage==='cancel-ticket.php'?'style="color:#003087;font-weight:700"':'' ?>>Cancel Ticket</a>
        <a href="<?= APP_URL ?>/logout.php"
           style="background:#003087;color:#fff;padding:7px 14px;border-radius:7px;font-size:13px;font-weight:600;text-decoration:none">
          👤 <?= htmlspecialchars($userName) ?> &nbsp;|&nbsp; Logout
        </a>
      <?php else: ?>
        <a href="<?= APP_URL ?>/login.php"
           style="border:2px solid #003087;color:#003087;padding:6px 14px;border-radius:7px;font-size:13px;font-weight:600;text-decoration:none">
          Sign In
        </a>
        <a href="<?= APP_URL ?>/register.php"
           style="background:#003087;color:#fff;padding:7px 14px;border-radius:7px;font-size:13px;font-weight:600;text-decoration:none">
          Sign Up
        </a>
      <?php endif; ?>
    </div>
  </div>
</nav>
