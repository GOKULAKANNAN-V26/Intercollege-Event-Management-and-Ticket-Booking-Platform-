<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/RateLimiter.php';

class OTPService {

    /**
     * Generate and store OTP, then dispatch via SMS/email.
     */
    public static function sendOTP(string $phone, string $email): array {
        $conn = getDBConnection();

        // Rate limit: max 5 OTP sends per phone per 10 minutes
        $identifier = 'otp_send_' . preg_replace('/\D/', '', $phone);
        if (!RateLimiter::isAllowed($identifier, 'send_otp', 5, 600)) {
            return ['success' => false, 'message' => 'Too many OTP requests. Please wait before requesting again.'];
        }

        // Check resend cooldown
        $stmt = $conn->prepare(
            "SELECT last_sent_at FROM otp_verification 
             WHERE phone = ? AND email = ? AND verified = 0 
             ORDER BY created_at DESC LIMIT 1"
        );
        $stmt->bind_param('ss', $phone, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $existing = $result->fetch_assoc();
        $stmt->close();

        if ($existing) {
            $lastSent = strtotime($existing['last_sent_at']);
            $cooldown = OTP_RESEND_COOLDOWN_SECONDS;
            if ((time() - $lastSent) < $cooldown) {
                $wait = $cooldown - (time() - $lastSent);
                return ['success' => false, 'message' => "Please wait {$wait} seconds before requesting a new OTP."];
            }
        }

        // Generate 4-digit OTP
        $otp = str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        $otpHash = password_hash($otp, PASSWORD_BCRYPT);
        $expiresAt = date('Y-m-d H:i:s', time() + (OTP_EXPIRY_MINUTES * 60));

        // Invalidate old OTPs for this phone/email
        $stmt = $conn->prepare(
            "UPDATE otp_verification SET verified = 1 WHERE phone = ? AND email = ? AND verified = 0"
        );
        $stmt->bind_param('ss', $phone, $email);
        $stmt->execute();
        $stmt->close();

        // Insert new OTP
        $stmt = $conn->prepare(
            "INSERT INTO otp_verification (phone, email, otp_hash, expires_at, created_at, last_sent_at) VALUES (?, ?, ?, ?, NOW(), NOW())"
        );
        $stmt->bind_param('ssss', $phone, $email, $otpHash, $expiresAt);
        $stmt->execute();
        $stmt->close();

        // Send OTP
        $sent = self::dispatchOTP($phone, $email, $otp);

        // In development mode, ALWAYS return the OTP for testing
        if (defined('APP_ENV') && APP_ENV === 'development') {
            Logger::info('OTPService', "OTP generated in development mode", ['phone' => $phone, 'otp' => $otp]);
            return [
                'success' => true,
                'message' => 'OTP sent successfully. (Development Mode: OTP shown below)',
                'otp_dev' => $otp,
                'dev_mode' => true
            ];
        }

        if (!$sent) {
            Logger::warning('OTPService', "OTP dispatch failed", ['phone' => $phone, 'email' => $email]);
            return ['success' => false, 'message' => 'Failed to send OTP. Please try again later.'];
        }

        Logger::info('OTPService', "OTP sent to $phone / $email", ['sent' => $sent]);

        $response = ['success' => true, 'message' => 'OTP sent successfully.'];
        return $response;
    }

    /**
     * Verify widget token from MSG91 (server-side verification).
     * This is called after the user completes OTP verification via the MSG91 widget.
     */
    public static function verifyMSG91WidgetToken(string $accessToken): array {
        try {
            if (empty($accessToken)) {
                return ['success' => false, 'message' => 'No access token provided.'];
            }

            $authkey = MSG91_API_KEY;
            if (empty($authkey)) {
                Logger::error('OTPService', 'MSG91_API_KEY not configured');
                return ['success' => false, 'message' => 'Server configuration error.'];
            }

            $url = 'https://control.msg91.com/api/v5/widget/verifyAccessToken';
            $payload = [
                'authkey' => $authkey,
                'access-token' => $accessToken
            ];

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING       => '',
                CURLOPT_MAXREDIRS      => 10,
                CURLOPT_TIMEOUT        => 10,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST  => 'POST',
                CURLOPT_POSTFIELDS     => json_encode($payload),
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    'Accept: application/json',
                ],
                CURLOPT_SSL_VERIFYPEER => true,
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($curlError) {
                Logger::error('OTPService', "MSG91 Widget Verification CURL Error: $curlError");
                return ['success' => false, 'message' => 'Verification service error.'];
            }

            if ($httpCode !== 200) {
                Logger::warning('OTPService', "MSG91 Widget Verification HTTP Error: $httpCode", ['response' => $response]);
                return ['success' => false, 'message' => 'OTP verification failed. Please try again.'];
            }

            $result = json_decode($response, true);
            $success = false;
            $message = $result['message'] ?? null;

            if (is_array($result)) {
                if ((isset($result['success']) && $result['success'] === true) ||
                    (isset($result['status']) && strtolower($result['status']) === 'success') ||
                    (isset($result['type']) && strtolower($result['type']) === 'success')) {
                    $success = true;
                }
            }

            if ($success) {
                Logger::info('OTPService', "MSG91 Widget token verified", ['result' => $result]);
                return [
                    'success' => true,
                    'message' => 'OTP verified successfully via widget.',
                    'verified_at' => date('Y-m-d H:i:s')
                ];
            }

            Logger::warning('OTPService', "MSG91 Widget verification rejected", ['response' => $result]);
            return ['success' => false, 'message' => 'OTP verification failed. ' . ($message ?? 'Please try again.')];
        } catch (Exception $e) {
            Logger::error('OTPService', 'MSG91 Widget verification error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Verification error. Please try again.'];
        }
    }

    /**
     * Verify OTP using Firebase (server-side verification).
     * Validates tokens from Firebase Authentication.
     */
    public static function verifyFirebaseToken(string $idToken): array {
        try {
            if (empty($idToken)) {
                return ['success' => false, 'message' => 'No Firebase token provided.'];
            }

            if (!defined('FIREBASE_API_KEY') || empty(FIREBASE_API_KEY)) {
                Logger::error('OTPService', 'FIREBASE_API_KEY not configured');
                return ['success' => false, 'message' => 'Server configuration error.'];
            }

            // Verify token with Firebase REST API
            $verifyUrl = 'https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' . FIREBASE_API_KEY;
            $payload = json_encode(['idToken' => $idToken]);

            $ch = curl_init($verifyUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING       => '',
                CURLOPT_MAXREDIRS      => 10,
                CURLOPT_TIMEOUT        => 10,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST  => 'POST',
                CURLOPT_POSTFIELDS     => $payload,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    'Accept: application/json',
                ],
                CURLOPT_SSL_VERIFYPEER => true,
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($curlError) {
                Logger::error('OTPService', "Firebase Token Verification CURL Error: $curlError");
                return ['success' => false, 'message' => 'Verification service error.'];
            }

            if ($httpCode !== 200) {
                Logger::warning('OTPService', "Firebase Token Verification HTTP Error: $httpCode", ['response' => $response]);
                return ['success' => false, 'message' => 'Token verification failed.'];
            }

            $result = json_decode($response, true);
            
            if (!is_array($result) || !isset($result['users']) || empty($result['users'])) {
                Logger::warning('OTPService', 'Firebase Token verification rejected', ['response' => $result]);
                return ['success' => false, 'message' => 'OTP verification failed.'];
            }

            $user = $result['users'][0];
            Logger::info('OTPService', 'Firebase token verified', ['phone' => $user['phoneNumber'] ?? 'unknown']);

            return [
                'success'      => true,
                'message'      => 'OTP verified successfully via Firebase.',
                'phone'        => $user['phoneNumber'] ?? null,
                'uid'          => $user['localId'] ?? null,
                'verified_at'  => date('Y-m-d H:i:s')
            ];
        } catch (Exception $e) {
            Logger::error('OTPService', 'Firebase token verification error: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Verification error. Please try again.'];
        }
    }

    /**
     * Verify OTP manually entered by user
     */
    public static function verifyOTP(string $phone, string $email, string $inputOtp): array {
        $conn = getDBConnection();

        // Rate limit: max 5 verify attempts per phone per 10 minutes
        $identifier = 'otp_verify_' . preg_replace('/\D/', '', $phone);
        if (!RateLimiter::isAllowed($identifier, 'verify_otp', 5, 600)) {
            return ['success' => false, 'message' => 'Too many failed attempts. Please request a new OTP.'];
        }

        $stmt = $conn->prepare(
            "SELECT id, otp_hash, attempts, expires_at FROM otp_verification 
             WHERE phone = ? AND email = ? AND verified = 0 
             ORDER BY created_at DESC LIMIT 1"
        );
        $stmt->bind_param('ss', $phone, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();

        if (!$row) {
            return ['success' => false, 'message' => 'No active OTP found. Please request a new one.'];
        }

        // Check expiry
        if (strtotime($row['expires_at']) < time()) {
            return ['success' => false, 'message' => 'OTP has expired. Please request a new one.'];
        }

        // Check max retries
        if ($row['attempts'] >= OTP_MAX_RETRIES) {
            return ['success' => false, 'message' => 'Maximum OTP attempts exceeded. Please request a new OTP.'];
        }

        // Increment attempts
        $stmt = $conn->prepare("UPDATE otp_verification SET attempts = attempts + 1 WHERE id = ?");
        $stmt->bind_param('i', $row['id']);
        $stmt->execute();
        $stmt->close();

        // Verify hash
        if (!password_verify($inputOtp, $row['otp_hash'])) {
            $remaining = OTP_MAX_RETRIES - ($row['attempts'] + 1);
            return ['success' => false, 'message' => "Invalid OTP. {$remaining} attempt(s) remaining."];
        }

        // Mark as verified
        $stmt = $conn->prepare("UPDATE otp_verification SET verified = 1 WHERE id = ?");
        $stmt->bind_param('i', $row['id']);
        $stmt->execute();
        $stmt->close();

        RateLimiter::reset($identifier, 'verify_otp');
        Logger::info('OTPService', "OTP verified for $phone / $email");

        return ['success' => true, 'message' => 'OTP verified successfully.'];
    }

    /**
     * Dispatch OTP via SMS (primary using MSG91) and email (fallback).
     */
    private static function dispatchOTP(string $phone, string $email, string $otp): bool {
        $message = "Your CollegeEvents OTP is: $otp. Valid for " . OTP_EXPIRY_MINUTES . " minutes. Do not share.";

        // Try MSG91 SMS first
        $smsSent = self::sendViaMSG91($phone, $message);
        if ($smsSent) {
            return true;
        }

        // Email fallback only if SMS fails
        return self::sendViaEmail($email, $otp);
    }

    private static function sendViaMSG91(string $phone, string $message): bool {
        try {
            // Remove any formatting from phone number
            $phone = preg_replace('/[^0-9\+]/', '', $phone);
            
            // Ensure phone has country code for India
            if (strlen($phone) == 10) {
                $phone = '91' . $phone;
            } elseif (substr($phone, 0, 1) === '+') {
                $phone = substr($phone, 1);
            }

            $params = [
                'authkey'  => MSG91_API_KEY,
                'mobiles'  => $phone,
                'message'  => $message,
                'sender'   => MSG91_SENDER_ID,
                'route'    => MSG91_ROUTE,
                'country'  => '91',
                'response' => 'json'
            ];

            $queryString = http_build_query($params);
            $url = MSG91_API_URL . '?' . $queryString;

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 10,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_USERAGENT      => 'EventPass/1.0'
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($curlError) {
                Logger::error('OTPService', "MSG91 CURL Error: $curlError");
                return false;
            }

            if ($httpCode !== 200) {
                Logger::error('OTPService', "MSG91 HTTP Error: $httpCode", ['response' => $response]);
                return false;
            }

            $result = json_decode($response, true);
            if ($result === null) {
                Logger::warning('OTPService', 'MSG91 response parse failed', ['response' => $response]);
                return false;
            }

            // Check if MSG91 returned success
            if (isset($result['type']) && strtolower($result['type']) === 'success') {
                Logger::info('OTPService', "SMS sent via MSG91 to $phone", ['msg91_response' => $result]);
                return true;
            }

            Logger::warning('OTPService', "MSG91 API Error", ['response' => $result]);
            return false;
        } catch (Exception $e) {
            Logger::error('OTPService', 'MSG91 send failed: ' . $e->getMessage());
            return false;
        }
    }

    private static function sendViaEmail(string $email, string $otp): bool {
        try {
            // Using PHPMailer if available, else basic mail()
            if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
                return self::sendEmailPHPMailer($email, $otp);
            }
            // Fallback: basic mail (works only if mail server configured)
            $subject = "Your CollegeEvents OTP";
            $body = "Your OTP is: <strong>$otp</strong><br>Valid for " . OTP_EXPIRY_MINUTES . " minutes.";
            $headers = "MIME-Version: 1.0\r\nContent-type: text/html\r\nFrom: " . SMTP_FROM_NAME . " <" . SMTP_USER . ">";
            return @mail($email, $subject, $body, $headers);
        } catch (Exception $e) {
            Logger::error('OTPService', 'Email OTP send failed: ' . $e->getMessage());
            return false;
        }
    }

    private static function sendEmailPHPMailer(string $email, string $otp): bool {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        $mail->setFrom(SMTP_USER, SMTP_FROM_NAME);
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Your CollegeEvents OTP';
        $mail->Body    = "
            <div style='font-family:Arial,sans-serif;max-width:400px;margin:auto;padding:20px;border:1px solid #ddd;border-radius:8px'>
                <h2 style='color:#6c63ff'>CollegeEvents OTP</h2>
                <p>Your One-Time Password is:</p>
                <h1 style='letter-spacing:8px;color:#333;text-align:center'>$otp</h1>
                <p>Valid for <strong>" . OTP_EXPIRY_MINUTES . " minutes</strong>. Do not share this OTP.</p>
            </div>";
        $mail->send();
        return true;
    }
}
?>
