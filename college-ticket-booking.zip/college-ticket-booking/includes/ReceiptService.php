<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Logger.php';

class ReceiptService {

    public static function generateReceipt(string $bookingId): ?string {
        $conn = getDBConnection();

        $stmt = $conn->prepare(
            "SELECT cb.*, e.name AS event_name, e.venue, e.event_date, e.department, e.ticket_price
             FROM confirmed_bookings cb
             JOIN events e ON cb.event_id = e.id
             WHERE cb.booking_id = ?"
        );
        $stmt->bind_param('s', $bookingId);
        $stmt->execute();
        $booking = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$booking) {
            Logger::error('ReceiptService', "Booking not found: $bookingId");
            return null;
        }

        if (!is_dir(RECEIPTS_PATH)) mkdir(RECEIPTS_PATH, 0755, true);

        $filename = 'receipt_' . $bookingId . '.html';
        $filepath = RECEIPTS_PATH . $filename;
        $html     = self::buildReceiptHTML($booking);

        if (file_put_contents($filepath, $html) === false) {
            Logger::error('ReceiptService', "Failed to write receipt: $filepath");
            return null;
        }

        $relativePath = 'uploads/receipts/' . $filename;
        $stmt = $conn->prepare("UPDATE confirmed_bookings SET receipt_path = ? WHERE booking_id = ?");
        $stmt->bind_param('ss', $relativePath, $bookingId);
        $stmt->execute();
        $stmt->close();

        Logger::info('ReceiptService', "Receipt generated: $filename");
        return $relativePath;
    }

    private static function buildReceiptHTML(array $b): string {
        $eventDate      = date('D, d M Y, h:i A', strtotime($b['event_date']));
        $confirmedAt    = date('d M Y, h:i A', strtotime($b['confirmed_at']));
        $total          = '&#8377;' . number_format($b['total_amount'], 2);
        $pricePerTicket = $b['ticket_price'] == 0 ? 'FREE' : '&#8377;' . number_format($b['ticket_price'], 2);
        $appUrl         = APP_URL;

        // QR code via Google Charts (no library needed)
        $qrData = urlencode(json_encode(['bid' => $b['booking_id'], 'eid' => $b['event_id']]));
        $qrUrl  = "https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl={$qrData}&choe=UTF-8";

        $bid  = htmlspecialchars($b['booking_id']);
        $name = htmlspecialchars($b['user_name']);
        $email= htmlspecialchars($b['user_email']);
        $phone= htmlspecialchars($b['user_phone']);
        $ename= htmlspecialchars($b['event_name']);
        $dept = htmlspecialchars($b['department']);
        $venue= htmlspecialchars($b['venue']);
        $pid  = htmlspecialchars($b['payment_id']);
        $tcnt = (int)$b['ticket_count'];

        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Receipt – {$bid}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f5;padding:20px}
.receipt{max-width:620px;margin:auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.12)}
.hdr{background:linear-gradient(135deg,#003087,#0055b3);color:#fff;padding:28px;text-align:center}
.hdr img{height:44px;filter:brightness(0) invert(1);margin-bottom:10px;display:block;margin-left:auto;margin-right:auto}
.hdr h1{font-size:20px;font-weight:800;margin-bottom:3px}
.hdr p{font-size:11px;opacity:.8}
.badge{display:inline-block;background:#00e676;color:#000;padding:4px 16px;border-radius:20px;font-weight:700;font-size:12px;margin-top:10px}
.body{padding:28px}
.bid-box{text-align:center;background:#f4f6fb;border:2px dashed #003087;border-radius:10px;padding:14px;margin-bottom:22px}
.bid-box .id{font-size:20px;font-weight:800;color:#003087;letter-spacing:2px;font-family:monospace}
.bid-box .sub{font-size:11px;color:#888;margin-top:4px}
.qr-section{text-align:center;margin-bottom:22px;padding:16px;background:#f4f6fb;border-radius:10px}
.qr-section img{width:160px;height:160px;border:3px solid #003087;border-radius:8px;padding:4px;background:#fff}
.qr-section p{font-size:11px;color:#888;margin-top:8px}
.section{margin-bottom:18px}
.section h3{font-size:11px;text-transform:uppercase;color:#888;letter-spacing:1px;margin-bottom:8px;border-bottom:1px solid #eee;padding-bottom:5px}
.row{display:flex;justify-content:space-between;padding:5px 0;font-size:13px}
.row .lbl{color:#666}.row .val{font-weight:600;color:#333;text-align:right;max-width:60%}
.total{background:#e6edf8;border-radius:8px;padding:12px 14px;margin-top:8px;display:flex;justify-content:space-between;align-items:center}
.total .lbl{font-size:15px;font-weight:700;color:#003087}
.total .val{font-size:20px;font-weight:800;color:#003087}
.ftr{background:#f4f6fb;padding:18px 28px;text-align:center;font-size:11px;color:#888;border-top:1px solid #eee}
.ftr a{color:#003087;text-decoration:none}
@media print{body{background:#fff;padding:0}.receipt{box-shadow:none}}
</style>
</head>
<body>
<div class="receipt">
  <div class="hdr">
    <img src="{$appUrl}/assets/images/veltech-logo.svg" alt="Vel Tech">
    <h1>🎟 VelTech EventPass</h1>
    <p>Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology</p>
    <div class="badge">✓ BOOKING CONFIRMED</div>
  </div>
  <div class="body">
    <div class="bid-box">
      <div class="sub">BOOKING ID</div>
      <div class="id">{$bid}</div>
      <div class="sub">Confirmed on {$confirmedAt}</div>
    </div>

    <div class="qr-section">
      <img src="{$qrUrl}" alt="QR Code for check-in">
      <p>📱 Show this QR code at the event entrance for check-in</p>
    </div>

    <div class="section">
      <h3>Event Details</h3>
      <div class="row"><span class="lbl">Event</span><span class="val">{$ename}</span></div>
      <div class="row"><span class="lbl">Department</span><span class="val">{$dept}</span></div>
      <div class="row"><span class="lbl">Date &amp; Time</span><span class="val">{$eventDate}</span></div>
      <div class="row"><span class="lbl">Venue</span><span class="val">{$venue}</span></div>
    </div>

    <div class="section">
      <h3>Attendee Details</h3>
      <div class="row"><span class="lbl">Name</span><span class="val">{$name}</span></div>
      <div class="row"><span class="lbl">Email</span><span class="val">{$email}</span></div>
      <div class="row"><span class="lbl">Phone</span><span class="val">{$phone}</span></div>
    </div>

    <div class="section">
      <h3>Payment Details</h3>
      <div class="row"><span class="lbl">Tickets</span><span class="val">{$tcnt} × {$pricePerTicket}</span></div>
      <div class="row"><span class="lbl">Payment ID</span><span class="val" style="font-size:11px;font-family:monospace">{$pid}</span></div>
      <div class="total"><span class="lbl">Total Paid</span><span class="val">{$total}</span></div>
    </div>
  </div>
  <div class="ftr">
    <p>Thank you for booking with <a href="{$appUrl}">VelTech EventPass</a></p>
    <p style="margin-top:5px">Please carry this receipt (digital or printed) to the event entrance.</p>
    <p style="margin-top:5px">Vel Tech University, Avadi, Chennai | support@veltech.edu.in</p>
  </div>
</div>
</body>
</html>
HTML;
    }
}
?>
