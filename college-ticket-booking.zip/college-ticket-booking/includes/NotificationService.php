<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Logger.php';

class NotificationService {

    /**
     * Send booking confirmation email.
     */
    public static function sendConfirmationEmail(array $booking): bool {
        $to      = $booking['user_email'];
        $name    = $booking['user_name'];
        $bookingId = $booking['booking_id'];
        $eventName = $booking['event_name'] ?? 'Event';
        $eventDate = isset($booking['event_date']) ? date('D, d M Y, h:i A', strtotime($booking['event_date'])) : '';
        $venue     = $booking['venue'] ?? '';
        $tickets   = $booking['ticket_count'];
        $total     = '₹' . number_format($booking['total_amount'], 2);
        $receiptUrl = APP_URL . '/receipt.php?id=' . urlencode($bookingId);

        $subject = "🎟 Booking Confirmed – $eventName | $bookingId";

        $body = <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;background:#f0f2f5;padding:20px">
<div style="max-width:560px;margin:auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.1)">
  <div style="background:linear-gradient(135deg,#6c63ff,#4facfe);color:#fff;padding:25px;text-align:center">
    <h1 style="margin:0">🎟 Booking Confirmed!</h1>
    <p style="margin:8px 0 0;opacity:.85">Your tickets are reserved</p>
  </div>
  <div style="padding:25px">
    <p>Hi <strong>$name</strong>,</p>
    <p>Your booking for <strong>$eventName</strong> has been confirmed.</p>
    <table style="width:100%;border-collapse:collapse;margin:20px 0">
      <tr style="background:#f8f9ff"><td style="padding:10px;color:#666">Booking ID</td><td style="padding:10px;font-weight:700;color:#6c63ff">$bookingId</td></tr>
      <tr><td style="padding:10px;color:#666">Event</td><td style="padding:10px;font-weight:600">$eventName</td></tr>
      <tr style="background:#f8f9ff"><td style="padding:10px;color:#666">Date</td><td style="padding:10px">$eventDate</td></tr>
      <tr><td style="padding:10px;color:#666">Venue</td><td style="padding:10px">$venue</td></tr>
      <tr style="background:#f8f9ff"><td style="padding:10px;color:#666">Tickets</td><td style="padding:10px">$tickets</td></tr>
      <tr><td style="padding:10px;color:#666;font-weight:700">Total Paid</td><td style="padding:10px;font-weight:700;color:#6c63ff;font-size:18px">$total</td></tr>
    </table>
    <div style="text-align:center;margin:20px 0">
      <a href="$receiptUrl" style="background:#6c63ff;color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-weight:600">View Receipt</a>
    </div>
    <p style="color:#888;font-size:13px">Please carry this booking ID to the event. For support, reply to this email.</p>
  </div>
  <div style="background:#f8f9ff;padding:15px;text-align:center;font-size:12px;color:#aaa">
    © CollegeEvents | <a href="$receiptUrl" style="color:#6c63ff">View Receipt</a>
  </div>
</div>
</body>
</html>
HTML;

        return self::sendEmail($to, $subject, $body);
    }

    /**
     * Send WhatsApp notification via Twilio.
     */
    public static function sendWhatsAppNotification(array $booking): bool {
        $phone     = $booking['user_phone'];
        $name      = $booking['user_name'];
        $bookingId = $booking['booking_id'];
        $eventName = $booking['event_name'] ?? 'Event';
        $tickets   = $booking['ticket_count'];
        $total     = '₹' . number_format($booking['total_amount'], 2);
        $receiptUrl = APP_URL . '/receipt.php?id=' . urlencode($bookingId);

        $message = "🎟 *Booking Confirmed!*\n\n"
            . "Hi $name,\n"
            . "Your booking is confirmed.\n\n"
            . "📌 *Booking ID:* $bookingId\n"
            . "🎉 *Event:* $eventName\n"
            . "🎫 *Tickets:* $tickets\n"
            . "💰 *Total:* $total\n\n"
            . "View receipt: $receiptUrl\n\n"
            . "_CollegeEvents_";

        return self::sendWhatsApp($phone, $message);
    }

    /**
     * Core email sender using PHPMailer or mail().
     */
    public static function sendEmail(string $to, string $subject, string $htmlBody): bool {
        try {
            if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host       = SMTP_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = SMTP_USER;
                $mail->Password   = SMTP_PASS;
                $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = SMTP_PORT;
                $mail->setFrom(SMTP_USER, SMTP_FROM_NAME);
                $mail->addAddress($to);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body    = $htmlBody;
                $mail->send();
                return true;
            }

            // Fallback: basic mail()
            $headers  = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type: text/html; charset=UTF-8\r\n";
            $headers .= "From: " . SMTP_FROM_NAME . " <" . SMTP_USER . ">\r\n";
            return mail($to, $subject, $htmlBody, $headers);

        } catch (Exception $e) {
            Logger::error('NotificationService', 'Email failed: ' . $e->getMessage(), ['to' => $to]);
            return false;
        }
    }

    /**
     * Core WhatsApp sender via Twilio.
     */
    public static function sendWhatsApp(string $phone, string $message): bool {
        try {
            // Normalize phone
            $phone = preg_replace('/\D/', '', $phone);
            if (strlen($phone) === 10) {
                $phone = '+91' . $phone; // India default
            } elseif (!str_starts_with($phone, '+')) {
                $phone = '+' . $phone;
            }

            $data = http_build_query([
                'From' => WHATSAPP_FROM,
                'To'   => 'whatsapp:' . $phone,
                'Body' => $message
            ]);

            $ch = curl_init(WHATSAPP_API_URL);
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $data,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_USERPWD        => WHATSAPP_ACCOUNT_SID . ':' . WHATSAPP_AUTH_TOKEN,
                CURLOPT_TIMEOUT        => 10,
                CURLOPT_SSL_VERIFYPEER => true,
            ]);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode >= 200 && $httpCode < 300) {
                return true;
            }

            Logger::warning('NotificationService', "WhatsApp failed HTTP $httpCode", ['response' => $response]);
            return false;

        } catch (Exception $e) {
            Logger::error('NotificationService', 'WhatsApp failed: ' . $e->getMessage());
            return false;
        }
    }
}
?>
