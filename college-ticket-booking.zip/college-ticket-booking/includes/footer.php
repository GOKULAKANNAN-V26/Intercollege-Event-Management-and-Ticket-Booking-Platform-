<footer>
  <p>
    <img src="<?= APP_URL ?>/assets/images/veltech-logo.svg" alt="Vel Tech"
         style="height:26px;vertical-align:middle;margin-right:8px">
    © <?= date('Y') ?> <strong>VelTech EventPass</strong>
  </p>
  <p style="margin-top:4px;font-size:12px">
    Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology, Avadi, Chennai
  </p>
  <p style="margin-top:6px;font-size:13px">
    <a href="<?= APP_URL ?>/support.php" style="color:#003087">Support</a> &nbsp;|&nbsp;
    <a href="<?= APP_URL ?>/cancel-ticket.php" style="color:#003087">Cancel Ticket</a> &nbsp;|&nbsp;
    <a href="<?= APP_URL ?>/index.php" style="color:#003087">Events</a>
  </p>
  <p style="margin-top:4px;font-size:12px;color:#aaa">
    For support: support@veltech.edu.in &nbsp;|&nbsp; +91 94455 68802
  </p>
</footer>
