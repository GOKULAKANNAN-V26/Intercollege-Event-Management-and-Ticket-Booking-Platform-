<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Logger.php';

class BookingService {

    public static function reserveTickets(
        int    $eventId,
        string $userName,
        string $userEmail,
        string $userPhone,
        int    $ticketCount,
        string $teamName = '',
        array  $teamMembers = []
    ): array {
        if ($ticketCount < 1 || $ticketCount > MAX_TICKETS_PER_BOOKING) {
            return ['success' => false, 'message' => "Ticket count must be between 1 and " . MAX_TICKETS_PER_BOOKING . "."];
        }

        $conn = getDBConnection();
        $conn->begin_transaction();

        try {
            $stmt = $conn->prepare(
                "SELECT id, name, ticket_price, available_tickets, status FROM events WHERE id = ? FOR UPDATE"
            );
            $stmt->bind_param('i', $eventId);
            $stmt->execute();
            $event = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$event) {
                $conn->rollback();
                return ['success' => false, 'message' => 'Event not found.'];
            }
            if ($event['status'] !== 'active') {
                $conn->rollback();
                return ['success' => false, 'message' => 'This event is no longer available.'];
            }
            if ((int)$event['available_tickets'] < $ticketCount) {
                $conn->rollback();
                $avail = (int)$event['available_tickets'];
                return ['success' => false,
                        'message' => $avail === 0 ? 'Sorry, this event is sold out.' : "Only {$avail} ticket(s) remaining.",
                        'available' => $avail];
            }

            // Atomic deduct
            $stmt = $conn->prepare(
                "UPDATE events SET available_tickets = available_tickets - ? WHERE id = ? AND available_tickets >= ?"
            );
            $stmt->bind_param('iii', $ticketCount, $eventId, $ticketCount);
            $stmt->execute();
            $affected = $stmt->affected_rows;
            $stmt->close();

            if ($affected === 0) {
                $conn->rollback();
                return ['success' => false, 'message' => 'Tickets just sold out. Please try again.'];
            }

            $totalAmount     = (float)$event['ticket_price'] * $ticketCount;
            $bookingRef      = 'BK' . strtoupper(bin2hex(random_bytes(8)));
            $expiryTimestamp = date('Y-m-d H:i:s', time() + (BOOKING_EXPIRY_MINUTES * 60));

            // Insert pending booking — types: s=bookingRef, i=eventId, s=userName, s=userEmail, s=userPhone, i=ticketCount, d=totalAmount, s=teamName, s=teamMembers, s=expiryTimestamp
            $stmt = $conn->prepare(
                "INSERT INTO pending_bookings
                 (booking_ref, event_id, user_name, user_email, user_phone, ticket_count, total_amount, team_name, team_members, status, expiry_timestamp, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'RESERVED', ?, NOW())"
            );
            $membersJson = json_encode($teamMembers);
            $stmt->bind_param('sisssissss',
                $bookingRef, $eventId, $userName, $userEmail,
                $userPhone, $ticketCount, $totalAmount, $teamName, $membersJson, $expiryTimestamp
            );
            $stmt->execute();
            $stmt->close();

            $conn->commit();

            Logger::info('BookingService', "Reserved: $bookingRef", ['event_id' => $eventId, 'tickets' => $ticketCount]);

            return [
                'success'      => true,
                'booking_ref'  => $bookingRef,
                'total_amount' => $totalAmount,
                'event_name'   => $event['name'],
                'expires_at'   => $expiryTimestamp,
                'message'      => 'Tickets reserved successfully.',
            ];

        } catch (Exception $e) {
            $conn->rollback();
            Logger::error('BookingService', 'Reserve failed: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Reservation failed. Please try again.'];
        }
    }

    public static function confirmBooking(string $bookingRef, string $paymentId, string $orderId): array {
        $conn = getDBConnection();
        $conn->begin_transaction();

        try {
            // Idempotency check
            $stmt = $conn->prepare("SELECT booking_id FROM confirmed_bookings WHERE payment_id = ?");
            $stmt->bind_param('s', $paymentId);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($existing) {
                $conn->rollback();
                Logger::info('BookingService', "Booking already confirmed: {$existing['booking_id']}", [
                    'payment_id' => $paymentId
                ]);
                return ['success' => true, 'already_confirmed' => true, 'booking_id' => $existing['booking_id']];
            }

            // Get pending booking
            $stmt = $conn->prepare(
                "SELECT * FROM pending_bookings WHERE booking_ref = ? AND status IN ('RESERVED', 'PAYMENT_INITIATED') FOR UPDATE"
            );
            $stmt->bind_param('s', $bookingRef);
            $stmt->execute();
            $pending = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$pending) {
                $conn->rollback();
                Logger::error('BookingService', "Pending booking not found", [
                    'booking_ref' => $bookingRef,
                    'payment_id' => $paymentId
                ]);
                return ['success' => false, 'message' => 'Pending booking not found or already processed.'];
            }

            $bookingId   = 'CB' . date('Ymd') . strtoupper(bin2hex(random_bytes(4)));
            $eventId     = (int)$pending['event_id'];
            $ticketCount = (int)$pending['ticket_count'];
            $totalAmount = (float)$pending['total_amount'];
            
            // Store values in variables (cannot pass expressions by reference to bind_param)
            $userName = $pending['user_name'];
            $userEmail = $pending['user_email'];
            $userPhone = $pending['user_phone'];
            $teamName = $pending['team_name'] ?? '';
            $teamMembers = $pending['team_members'] ?? '';

            // Insert confirmed booking — types: s,s,i,s,s,s,s,s,i,d,s,s
            $stmt = $conn->prepare(
                "INSERT INTO confirmed_bookings
                 (booking_id, pending_booking_ref, event_id, user_name, user_email, user_phone,
                  team_name, team_members, ticket_count, total_amount, payment_id, razorpay_order_id, status, confirmed_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PAID', NOW())"
            );
            $stmt->bind_param('ssissssisdss',
                $bookingId, $bookingRef, $eventId,
                $userName, $userEmail, $userPhone,
                $teamName, $teamMembers,
                $ticketCount, $totalAmount, $paymentId, $orderId
            );
            
            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();
                $conn->rollback();
                Logger::error('BookingService', "Failed to insert confirmed booking", [
                    'booking_ref' => $bookingRef,
                    'payment_id' => $paymentId,
                    'error' => $error
                ]);
                return ['success' => false, 'message' => 'Failed to create confirmed booking: ' . $error];
            }
            $stmt->close();

            // Update pending status
            $stmt = $conn->prepare("UPDATE pending_bookings SET status = 'PAID' WHERE booking_ref = ?");
            $stmt->bind_param('s', $bookingRef);
            $stmt->execute();
            $stmt->close();

            // Update payment record
            $stmt = $conn->prepare(
                "UPDATE payments SET status = 'PAID', razorpay_payment_id = ?, webhook_verified = 1 WHERE razorpay_order_id = ?"
            );
            $stmt->bind_param('ss', $paymentId, $orderId);
            $stmt->execute();
            $stmt->close();

            $conn->commit();

            // Queue notifications (non-critical, don't fail if this errors)
            try {
                self::queueNotifications($bookingId, $pending);
            } catch (Exception $e) {
                Logger::warning('BookingService', "Failed to queue notifications: " . $e->getMessage(), [
                    'booking_id' => $bookingId
                ]);
            }

            Logger::info('BookingService', "Confirmed: $bookingId", [
                'booking_ref' => $bookingRef,
                'payment_id' => $paymentId,
                'event_id' => $eventId,
                'amount' => $totalAmount
            ]);

            return ['success' => true, 'booking_id' => $bookingId, 'message' => 'Booking confirmed.'];

        } catch (Exception $e) {
            $conn->rollback();
            Logger::error('BookingService', 'Confirm failed: ' . $e->getMessage(), [
                'booking_ref' => $bookingRef,
                'payment_id' => $paymentId,
                'trace' => $e->getTraceAsString()
            ]);
            return ['success' => false, 'message' => 'Confirmation failed: ' . $e->getMessage()];
        }
    }

    private static function queueNotifications(string $bookingId, array $booking): void {
        try {
            $conn    = getDBConnection();
            $payload = json_encode([
                'booking_id' => $bookingId,
                'email'      => $booking['user_email'],
                'phone'      => $booking['user_phone'],
                'name'       => $booking['user_name'],
            ]);
            foreach (['generate_receipt', 'send_email', 'send_whatsapp'] as $jobType) {
                $stmt = $conn->prepare(
                    "INSERT INTO jobs (job_type, payload, status, scheduled_at) VALUES (?, ?, 'pending', NOW())"
                );
                $stmt->bind_param('ss', $jobType, $payload);
                $stmt->execute();
                $stmt->close();
            }
        } catch (Exception $e) {
            Logger::error('BookingService', 'Queue notifications failed: ' . $e->getMessage());
        }
    }

    public static function getConfirmedBooking(string $bookingId): ?array {
        $conn = getDBConnection();
        $stmt = $conn->prepare(
            "SELECT cb.*, e.name AS event_name, e.venue, e.event_date, e.department, e.ticket_price
             FROM confirmed_bookings cb
             JOIN events e ON cb.event_id = e.id
             WHERE cb.booking_id = ?"
        );
        $stmt->bind_param('s', $bookingId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?: null;
    }

    public static function releaseExpiredBookings(): int {
        $conn = getDBConnection();
        $conn->begin_transaction();
        try {
            $result = $conn->query(
                "SELECT id, event_id, ticket_count FROM pending_bookings
                 WHERE expiry_timestamp < NOW()
                 AND status IN ('OTP_PENDING','OTP_VERIFIED','RESERVED','PAYMENT_INITIATED')
                 FOR UPDATE"
            );
            $count = 0;
            while ($row = $result->fetch_assoc()) {
                $stmt = $conn->prepare("UPDATE events SET available_tickets = available_tickets + ? WHERE id = ?");
                $stmt->bind_param('ii', $row['ticket_count'], $row['event_id']);
                $stmt->execute();
                $stmt->close();

                $stmt = $conn->prepare("UPDATE pending_bookings SET status = 'EXPIRED' WHERE id = ?");
                $stmt->bind_param('i', $row['id']);
                $stmt->execute();
                $stmt->close();
                $count++;
            }
            $conn->commit();
            return $count;
        } catch (Exception $e) {
            $conn->rollback();
            Logger::error('BookingService', 'Release expired failed: ' . $e->getMessage());
            return 0;
        }
    }
}
?>
