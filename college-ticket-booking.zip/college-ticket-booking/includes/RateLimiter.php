<?php
require_once __DIR__ . '/../config/database.php';

class RateLimiter {
    /**
     * Check if action is allowed for identifier within window.
     * @param string $identifier  IP or phone/email
     * @param string $action      e.g. 'send_otp', 'verify_otp'
     * @param int    $maxAttempts Max allowed attempts
     * @param int    $windowSecs  Time window in seconds
     */
    public static function isAllowed(string $identifier, string $action, int $maxAttempts, int $windowSecs): bool {
        $conn = getDBConnection();

        // Clean old windows
        $stmt = $conn->prepare(
            "DELETE FROM rate_limits WHERE action = ? AND window_start < DATE_SUB(NOW(), INTERVAL ? SECOND)"
        );
        $stmt->bind_param('si', $action, $windowSecs);
        $stmt->execute();
        $stmt->close();

        // Check current count
        $stmt = $conn->prepare(
            "SELECT attempts FROM rate_limits WHERE identifier = ? AND action = ?"
        );
        $stmt->bind_param('ss', $identifier, $action);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();

        if (!$row) {
            // First attempt
            $stmt = $conn->prepare(
                "INSERT INTO rate_limits (identifier, action, attempts, window_start) VALUES (?, ?, 1, NOW())"
            );
            $stmt->bind_param('ss', $identifier, $action);
            $stmt->execute();
            $stmt->close();
            return true;
        }

        if ($row['attempts'] >= $maxAttempts) {
            return false;
        }

        // Increment
        $stmt = $conn->prepare(
            "UPDATE rate_limits SET attempts = attempts + 1 WHERE identifier = ? AND action = ?"
        );
        $stmt->bind_param('ss', $identifier, $action);
        $stmt->execute();
        $stmt->close();
        return true;
    }

    public static function reset(string $identifier, string $action): void {
        $conn = getDBConnection();
        $stmt = $conn->prepare("DELETE FROM rate_limits WHERE identifier = ? AND action = ?");
        $stmt->bind_param('ss', $identifier, $action);
        $stmt->execute();
        $stmt->close();
    }
}
?>
