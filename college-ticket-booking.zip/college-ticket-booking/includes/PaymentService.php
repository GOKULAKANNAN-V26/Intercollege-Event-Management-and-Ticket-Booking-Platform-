<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Logger.php';
require_once __DIR__ . '/BookingService.php';

class PaymentService {

    /**
     * Create a Razorpay order from the backend.
     * Amount is always fetched from DB, never trusted from frontend.
     */
    public static function createOrder(string $bookingRef): array {
        $conn = getDBConnection();

        // Get pending booking
        $stmt = $conn->prepare(
            "SELECT * FROM pending_bookings WHERE booking_ref = ? AND status = 'RESERVED'"
        );
        $stmt->bind_param('s', $bookingRef);
        $stmt->execute();
        $result = $stmt->get_result();
        $booking = $result->fetch_assoc();
        $stmt->close();

        if (!$booking) {
            return ['success' => false, 'message' => 'Booking not found or expired.'];
        }

        // Check expiry
        if (strtotime($booking['expiry_timestamp']) < time()) {
            return ['success' => false, 'message' => 'Booking has expired. Please start again.'];
        }

        // Amount in paise (Razorpay uses smallest currency unit)
        $amountPaise = (int)($booking['total_amount'] * 100);

        // Create Razorpay order
        $orderData = [
            'amount'          => $amountPaise,
            'currency'        => 'INR',
            'receipt'         => $bookingRef,
            'payment_capture' => 1,
            'notes'           => [
                'booking_ref' => $bookingRef,
                'event_id'    => $booking['event_id'],
            ]
        ];

        $ch = curl_init('https://api.razorpay.com/v1/orders');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($orderData),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERPWD        => RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            Logger::error('PaymentService', 'cURL error creating order: ' . $curlError);
            return ['success' => false, 'message' => 'Payment gateway unavailable. Please try again.'];
        }

        $order = json_decode($response, true);

        if ($httpCode !== 200 || empty($order['id'])) {
            Logger::error('PaymentService', 'Razorpay order creation failed', ['response' => $response]);
            return ['success' => false, 'message' => 'Failed to create payment order. Please try again.'];
        }

        // Store order in payments table
        $amount = (float)$booking['total_amount'];
        $stmt = $conn->prepare(
            "INSERT INTO payments (razorpay_order_id, booking_ref, amount, currency, status, created_at)
             VALUES (?, ?, ?, 'INR', 'CREATED', NOW())
             ON DUPLICATE KEY UPDATE status = 'CREATED'"
        );
        $stmt->bind_param('ssd', $order['id'], $bookingRef, $amount);
        $stmt->execute();
        $stmt->close();

        // Update pending booking with order ID and status
        $stmt = $conn->prepare(
            "UPDATE pending_bookings SET razorpay_order_id = ?, status = 'PAYMENT_INITIATED' WHERE booking_ref = ?"
        );
        $stmt->bind_param('ss', $order['id'], $bookingRef);
        $stmt->execute();
        $stmt->close();

        Logger::info('PaymentService', "Order created: {$order['id']} for booking $bookingRef");

        return [
            'success'      => true,
            'order_id'     => $order['id'],
            'amount'       => $amountPaise,
            'currency'     => 'INR',
            'key_id'       => RAZORPAY_KEY_ID,
            'booking_ref'  => $bookingRef,
            'user_name'    => $booking['user_name'],
            'user_email'   => $booking['user_email'],
            'user_phone'   => $booking['user_phone'],
        ];
    }

    /**
     * Verify Razorpay payment signature (client-side callback).
     */
    public static function verifyPaymentSignature(
        string $orderId,
        string $paymentId,
        string $signature
    ): bool {
        $expectedSignature = hash_hmac(
            'sha256',
            $orderId . '|' . $paymentId,
            RAZORPAY_KEY_SECRET
        );
        return hash_equals($expectedSignature, $signature);
    }

    /**
     * Handle Razorpay webhook (server-side, most reliable).
     */
    public static function handleWebhook(string $rawBody, string $webhookSignature): array {
        // Verify webhook signature
        $expectedSig = hash_hmac('sha256', $rawBody, RAZORPAY_WEBHOOK_SECRET);
        if (!hash_equals($expectedSig, $webhookSignature)) {
            Logger::warning('PaymentService', 'Invalid webhook signature');
            return ['success' => false, 'message' => 'Invalid signature'];
        }

        $payload = json_decode($rawBody, true);
        if (!$payload) {
            return ['success' => false, 'message' => 'Invalid payload'];
        }

        $event = $payload['event'] ?? '';

        if ($event === 'payment.captured') {
            $paymentEntity = $payload['payload']['payment']['entity'] ?? [];
            $orderId   = $paymentEntity['order_id'] ?? '';
            $paymentId = $paymentEntity['id'] ?? '';

            if (!$orderId || !$paymentId) {
                return ['success' => false, 'message' => 'Missing payment data'];
            }

            return self::processSuccessfulPayment($orderId, $paymentId, $rawBody);
        }

        if ($event === 'payment.failed') {
            $paymentEntity = $payload['payload']['payment']['entity'] ?? [];
            $orderId = $paymentEntity['order_id'] ?? '';
            self::markPaymentFailed($orderId);
            return ['success' => true, 'message' => 'Payment failure recorded'];
        }

        return ['success' => true, 'message' => 'Event ignored'];
    }

    /**
     * Process a successful payment (idempotent with enhanced error handling).
     */
    public static function processSuccessfulPayment(
        string $orderId,
        string $paymentId,
        string $rawResponse = ''
    ): array {
        $conn = getDBConnection();

        try {
            // Get booking ref from payment record
            $stmt = $conn->prepare(
                "SELECT booking_ref, status FROM payments WHERE razorpay_order_id = ?"
            );
            $stmt->bind_param('s', $orderId);
            $stmt->execute();
            $result = $stmt->get_result();
            $payment = $result->fetch_assoc();
            $stmt->close();

            if (!$payment) {
                Logger::error('PaymentService', "No payment record for order: $orderId", [
                    'order_id' => $orderId,
                    'payment_id' => $paymentId
                ]);
                return ['success' => false, 'message' => 'Payment record not found'];
            }

            // Idempotency: check if already processed
            if ($payment['status'] === 'PAID') {
                // Check if booking was created
                $stmt = $conn->prepare(
                    "SELECT booking_id FROM confirmed_bookings WHERE payment_id = ?"
                );
                $stmt->bind_param('s', $paymentId);
                $stmt->execute();
                $existing = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if ($existing) {
                    Logger::info('PaymentService', "Payment already processed: $paymentId", [
                        'booking_id' => $existing['booking_id']
                    ]);
                    return [
                        'success' => true,
                        'booking_id' => $existing['booking_id'],
                        'message' => 'Already processed'
                    ];
                } else {
                    // Payment marked as PAID but no booking - attempt recovery
                    Logger::warning('PaymentService', "Payment PAID but no booking found - attempting recovery", [
                        'order_id' => $orderId,
                        'payment_id' => $paymentId,
                        'booking_ref' => $payment['booking_ref']
                    ]);
                }
            }

            // Update payment record FIRST (before attempting booking confirmation)
            $stmt = $conn->prepare(
                "UPDATE payments 
                 SET razorpay_payment_id = ?, status = 'PAID', webhook_verified = 1, raw_response = ?
                 WHERE razorpay_order_id = ?"
            );
            $stmt->bind_param('sss', $paymentId, $rawResponse, $orderId);
            $stmt->execute();
            $stmt->close();

            Logger::info('PaymentService', "Payment marked as PAID: $paymentId", [
                'order_id' => $orderId,
                'booking_ref' => $payment['booking_ref']
            ]);

            // Confirm booking (this is where failures can occur)
            $confirmResult = BookingService::confirmBooking($payment['booking_ref'], $paymentId, $orderId);

            if ($confirmResult['success']) {
                Logger::info('PaymentService', "Booking confirmed successfully", [
                    'booking_id' => $confirmResult['booking_id'],
                    'payment_id' => $paymentId
                ]);
            } else {
                // Log the failure but payment is already marked as PAID
                // This creates an "orphaned payment" that can be reconciled later
                Logger::error('PaymentService', "Booking confirmation FAILED after payment success", [
                    'order_id' => $orderId,
                    'payment_id' => $paymentId,
                    'booking_ref' => $payment['booking_ref'],
                    'error' => $confirmResult['message'] ?? 'Unknown error',
                    'action_required' => 'Use payment reconciliation tool in admin panel'
                ]);
            }

            return $confirmResult;

        } catch (Exception $e) {
            Logger::error('PaymentService', "Exception in processSuccessfulPayment: " . $e->getMessage(), [
                'order_id' => $orderId,
                'payment_id' => $paymentId,
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'message' => 'Payment processing failed: ' . $e->getMessage()
            ];
        }
    }

    private static function markPaymentFailed(string $orderId): void {
        $conn = getDBConnection();
        $stmt = $conn->prepare(
            "UPDATE payments SET status = 'FAILED' WHERE razorpay_order_id = ?"
        );
        $stmt->bind_param('s', $orderId);
        $stmt->execute();
        $stmt->close();

        // Also update pending booking
        $stmt = $conn->prepare(
            "UPDATE pending_bookings SET status = 'FAILED' WHERE razorpay_order_id = ?"
        );
        $stmt->bind_param('s', $orderId);
        $stmt->execute();
        $stmt->close();
    }
}
?>
