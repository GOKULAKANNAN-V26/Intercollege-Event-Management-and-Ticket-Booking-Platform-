<?php
require_once __DIR__ . '/../config/database.php';

class Logger {
    public static function log(string $level, string $context, string $message, array $data = []): void {
        try {
            $conn = getDBConnection();
            $stmt = $conn->prepare(
                "INSERT INTO logs (level, context, message, data) VALUES (?, ?, ?, ?)"
            );
            $jsonData = !empty($data) ? json_encode($data) : null;
            $stmt->bind_param('ssss', $level, $context, $message, $jsonData);
            $stmt->execute();
            $stmt->close();
        } catch (Exception $e) {
            error_log("Logger failed: " . $e->getMessage());
        }
    }

    public static function info(string $context, string $message, array $data = []): void {
        self::log('info', $context, $message, $data);
    }

    public static function error(string $context, string $message, array $data = []): void {
        self::log('error', $context, $message, $data);
        error_log("[$context] $message " . json_encode($data));
    }

    public static function warning(string $context, string $message, array $data = []): void {
        self::log('warning', $context, $message, $data);
    }
}
?>
