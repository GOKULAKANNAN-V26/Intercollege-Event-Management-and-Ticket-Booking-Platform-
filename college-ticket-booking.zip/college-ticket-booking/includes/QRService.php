<?php
/**
 * QR Code Service
 * Uses Google Charts API (no library needed) to generate QR codes
 * For production, use endroid/qr-code via Composer for offline generation
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Logger.php';

class QRService {

    /**
     * Generate QR code image and save to disk.
     * Encodes: booking_id|event_id|user_email (pipe-separated)
     */
    public static function generateQR(string $bookingId): ?string {
        $conn = getDBConnection();

        $stmt = $conn->prepare(
            "SELECT booking_id, event_id, user_email, ticket_count FROM confirmed_bookings WHERE booking_id = ?"
        );
        $stmt->bind_param('s', $bookingId);
        $stmt->execute();
        $booking = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$booking) return null;

        // QR data payload
        $qrData = json_encode([
            'bid' => $booking['booking_id'],
            'eid' => $booking['event_id'],
            'email' => $booking['user_email'],
            'tickets' => $booking['ticket_count'],
            'ts' => time()
        ]);

        // Use Google Charts QR API
        $encodedData = urlencode($qrData);
        $qrUrl = "https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl={$encodedData}&choe=UTF-8";

        // Download and save QR image
        $qrDir = UPLOADS_PATH . 'qrcodes' . DIRECTORY_SEPARATOR;
        if (!is_dir($qrDir)) {
            mkdir($qrDir, 0755, true);
        }

        $filename = 'qr_' . $bookingId . '.png';
        $filepath = $qrDir . $filename;

        // Try to download QR image
        $ctx = stream_context_create(['http' => ['timeout' => 10]]);
        $imgData = @file_get_contents($qrUrl, false, $ctx);

        if ($imgData !== false) {
            file_put_contents($filepath, $imgData);
            $relativePath = 'uploads/qrcodes/' . $filename;
        } else {
            // Fallback: store the URL itself as reference
            $relativePath = $qrUrl;
        }

        // Update booking with QR path
        $stmt = $conn->prepare(
            "UPDATE confirmed_bookings SET qr_code_path = ? WHERE booking_id = ?"
        );
        $stmt->bind_param('ss', $relativePath, $bookingId);
        $stmt->execute();
        $stmt->close();

        Logger::info('QRService', "QR generated for $bookingId");
        return $relativePath;
    }

    /**
     * Get QR code URL for display (inline Google Charts URL as fallback)
     */
    public static function getQRUrl(string $bookingId, int $eventId, string $email): string {
        $data = urlencode(json_encode(['bid' => $bookingId, 'eid' => $eventId]));
        return "https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl={$data}&choe=UTF-8";
    }

    /**
     * Verify and check-in a booking by scanning QR
     */
    public static function checkIn(string $bookingId, int $eventId): array {
        $conn = getDBConnection();

        $stmt = $conn->prepare(
            "SELECT cb.*, e.name AS event_name, e.event_date
             FROM confirmed_bookings cb
             JOIN events e ON cb.event_id = e.id
             WHERE cb.booking_id = ?"
        );
        $stmt->bind_param('s', $bookingId);
        $stmt->execute();
        $booking = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$booking) {
            return ['success' => false, 'message' => 'Booking not found.'];
        }

        if ($booking['event_id'] != $eventId) {
            return ['success' => false, 'message' => 'QR code does not match this event.'];
        }

        if ($booking['status'] === 'CANCELLED') {
            return ['success' => false, 'message' => 'This booking has been cancelled.'];
        }

        if ($booking['checked_in']) {
            return [
                'success'  => false,
                'message'  => 'Already checked in at ' . date('h:i A, d M Y', strtotime($booking['checked_in_at'])),
                'booking'  => $booking,
                'duplicate' => true
            ];
        }

        // Mark checked in
        $stmt = $conn->prepare(
            "UPDATE confirmed_bookings SET checked_in = 1, checked_in_at = NOW(), status = 'CONFIRMED'
             WHERE booking_id = ?"
        );
        $stmt->bind_param('s', $bookingId);
        $stmt->execute();
        $stmt->close();

        Logger::info('QRService', "Checked in: $bookingId for event $eventId");

        return [
            'success'  => true,
            'message'  => 'Check-in successful!',
            'booking'  => $booking,
        ];
    }
}
?>
