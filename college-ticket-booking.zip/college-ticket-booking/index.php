<?php
require_once __DIR__ . '/config/config.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Require login to view events
if (empty($_SESSION['user_id'])) {
    session_write_close();
    header('Location: login.php?redirect=index.php');
    exit;
}

require_once __DIR__ . '/config/database.php';
$serverEvents = [];
try {
    $conn = getDBConnection();
    $stmt = $conn->prepare(
        "SELECT id, name, description, department, venue, event_date, ticket_price, total_tickets, available_tickets, 
                image, status, registration_type, min_team_members, max_team_members
         FROM events WHERE status = 'active' AND event_date >= NOW() ORDER BY event_date ASC"
    );
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $serverEvents[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    $serverEvents = [];
}

function renderEventCardHTML(array $ev): string {
    $available = (int)$ev['available_tickets'];
    $price = (float)$ev['ticket_price'];
    $registrationType = $ev['registration_type'] ?? 'Individual';
    $minTeam = (int)($ev['min_team_members'] ?? 2);
    $maxTeam = (int)($ev['max_team_members'] ?? 0);
    
    if ($available === 0) {
        $urgency = 'sold_out';
        $urgencyLabel = 'Sold Out';
    } elseif ($available <= 10) {
        $urgency = 'critical';
        $urgencyLabel = "⚡ Only {$available} left!";
    } elseif ($available <= 50) {
        $urgency = 'low';
        $urgencyLabel = "Only {$available} left!";
    } else {
        $urgency = 'available';
        $urgencyLabel = "{$available} tickets left";
    }
    $ticketLabel = $price == 0 ? 'FREE' : '₹' . number_format($price, 2);
    
    // Generate banner URL if no image exists
    if (empty($ev['image'])) {
        $bannerUrl = 'generate_event_banner.php?' . http_build_query([
            'name' => $ev['name'],
            'desc' => substr($ev['description'] ?? '', 0, 100),
            'dept' => $ev['department'],
            'date' => date('d M Y', strtotime($ev['event_date'])),
            'venue' => $ev['venue'],
            'reg_type' => $registrationType
        ]);
        $imageHtml = '<img src="' . htmlspecialchars($bannerUrl) . '" alt="' . htmlspecialchars($ev['name']) . '" loading="lazy">';
    } else {
        $imageHtml = '<img src="' . htmlspecialchars($ev['image']) . '" alt="' . htmlspecialchars($ev['name']) . '" loading="lazy">';
    }
    
    // Registration type badge
    $regBadge = '';
    if ($registrationType === 'Team') {
        $teamInfo = $maxTeam > 0 ? "{$minTeam}-{$maxTeam}" : "{$minTeam}+";
        $regBadge = '<span class="reg-badge team-badge">👥 Team Entry (' . $teamInfo . ')</span>';
    } elseif ($registrationType === 'Individual') {
        $regBadge = '<span class="reg-badge solo-badge">👤 Solo Entry</span>';
    } elseif ($registrationType === 'Both') {
        $regBadge = '<span class="reg-badge both-badge">👤👥 Solo or Team</span>';
    }
    
    return '<div class="event-card" data-event-id="' . (int)$ev['id'] . '" 
                 data-reg-type="' . htmlspecialchars($registrationType) . '"
                 data-min-team="' . $minTeam . '"
                 data-max-team="' . $maxTeam . '"
                 role="listitem" tabindex="0" onkeydown="if(event.key===\'Enter\')this.click()">'
         . '<div class="event-card-img">' . $imageHtml 
         . '<span class="dept-badge">' . htmlspecialchars($ev['department']) . '</span>'
         . $regBadge
         . '</div>'
         . '<div class="event-card-body">'
         . '<h3 class="event-card-title">' . htmlspecialchars($ev['name']) . '</h3>'
         . '<div class="event-meta">'
         . '<div class="event-meta-item"><span class="mi">📅</span><span>' . htmlspecialchars(date('D, d M Y', strtotime($ev['event_date']))) . '</span></div>'
         . '<div class="event-meta-item"><span class="mi">🕐</span><span>' . htmlspecialchars(date('h:i A', strtotime($ev['event_date']))) . '</span></div>'
         . '<div class="event-meta-item"><span class="mi">📍</span><span>' . htmlspecialchars($ev['venue']) . '</span></div>'
         . '</div>'
         . '<div class="event-card-footer">'
         . '<span class="ticket-price ' . ($price == 0 ? 'free' : '') . '">' . htmlspecialchars($ticketLabel) . '</span>'
         . '<span class="availability ' . $urgency . '">' . htmlspecialchars($urgencyLabel) . '</span>'
         . '</div>'
         . '<button class="btn-book" data-event-id="' . (int)$ev['id'] . '" ' . ($urgency === 'sold_out' ? 'disabled' : '') . '>'
         . ($urgency === 'sold_out' ? '🚫 Sold Out' : '🎟 Book Tickets')
         . '</button>'
         . '</div></div>';
}

session_write_close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= APP_SHORT_NAME ?> – <?= APP_COLLEGE_SHORT ?></title>
  <meta name="description" content="Book tickets for Vel Tech events easily and securely.">
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
  <style>
    .navbar-inner { height: 70px; }
    .hero-logo { height: 64px; margin-bottom: 16px; filter: brightness(0) invert(1); }
    .hero-tagline { font-size: 13px; opacity: 0.8; margin-top: 6px; letter-spacing: 0.5px; }
    
    /* Registration Type Badges */
    .reg-badge {
      position: absolute;
      top: 10px;
      left: 10px;
      padding: 6px 12px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 700;
      backdrop-filter: blur(10px);
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      z-index: 2;
    }
    .solo-badge {
      background: rgba(33, 150, 243, 0.95);
      color: white;
    }
    .team-badge {
      background: rgba(156, 39, 176, 0.95);
      color: white;
    }
    .both-badge {
      background: rgba(255, 152, 0, 0.95);
      color: white;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<?php require_once __DIR__ . '/includes/navbar.php'; ?>

<!-- Hero -->
<section class="hero" aria-label="Hero section">
  <img src="assets/images/veltech-logo.svg" alt="Vel Tech Logo" class="hero-logo">
  <h1>🎟 VelTech EventPass</h1>
  <p>Book tickets for exciting Vel Tech events — fast, secure &amp; paperless</p>
  <p class="hero-tagline">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology</p>
</section>

<!-- Search & Filter -->
<section class="search-section" aria-label="Search and filter events">
  <div class="search-card">
    <div class="search-input-wrap">
      <span class="icon" aria-hidden="true">🔍</span>
      <input
        type="search"
        id="searchInput"
        class="search-input"
        placeholder="Search events..."
        aria-label="Search events"
        autocomplete="off"
      >
    </div>
    <select id="filterDept" class="filter-select" aria-label="Filter by department">
      <option value="">All Departments</option>
    </select>
    <input
      type="date"
      id="filterDate"
      class="filter-select"
      aria-label="Filter by date"
      min="<?= date('Y-m-d') ?>"
    >
  </div>
</section>

<!-- Events Grid -->
<main class="events-section" aria-label="Events listing">
  <div class="section-header">
    <h2 class="section-title">Upcoming Events</h2>
    <span id="eventsCount" class="events-count" aria-live="polite"></span>
  </div>
  <div id="eventsGrid" class="events-grid" role="list" aria-label="Events list">
    <?php if (!empty($serverEvents)): ?>
      <?php foreach ($serverEvents as $ev): ?>
        <?= renderEventCardHTML($ev) ?>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="empty-state" style="grid-column:1/-1;text-align:center;padding:40px">
        <div class="icon">🔍</div>
        <h3>No upcoming events yet</h3>
        <p>Events will appear here once the admin publishes them.</p>
      </div>
    <?php endif; ?>
  </div>
</main>

<!-- ============================================================
     BOOKING MODAL
     ============================================================ -->
<div id="bookingModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
  <div class="modal">
    <div class="modal-header">
      <h2 class="modal-title" id="modalTitle">Book Tickets – VelTech EventPass</h2>
      <button class="modal-close" id="modalClose" aria-label="Close booking modal">✕</button>
    </div>
    <div class="modal-body">

      <!-- Progress Steps -->
      <div class="steps" role="list" aria-label="Booking steps">
        <div class="step active" role="listitem">
          <div class="step-num">1</div>
          <span class="step-label">Details</span>
        </div>
        <div class="step" role="listitem">
          <div class="step-num">2</div>
          <span class="step-label">OTP</span>
        </div>
        <div class="step" role="listitem">
          <div class="step-num">3</div>
          <span class="step-label">Payment</span>
        </div>
      </div>

      <!-- Event Summary -->
      <div style="background:#f8f9ff;border-radius:8px;padding:12px 14px;margin-bottom:20px;font-size:13px">
        <strong id="modalEventName" style="font-size:15px;display:block;margin-bottom:4px"></strong>
        <span>📅 </span><span id="modalEventDate"></span><br>
        <span>📍 </span><span id="modalEventVenue"></span><br>
        <span>🎫 </span><span id="modalEventPrice"></span> per ticket &nbsp;|&nbsp;
        <span id="modalAvailable" style="color:#2e7d32;font-weight:600"></span>
      </div>

      <!-- ── STEP 1: Booking Details ── -->
      <div class="booking-step">
        <div id="bookingAlert" class="alert" style="display:none" role="alert" aria-live="assertive"></div>

        <form id="bookingForm" novalidate>
          <div class="form-group">
            <label class="form-label" for="inputName">Full Name *</label>
            <input type="text" id="inputName" class="form-control"
              placeholder="Enter your full name"
              required minlength="2" maxlength="100"
              autocomplete="name" aria-required="true">
          </div>
          <div class="form-group">
            <label class="form-label" for="inputEmail">Email Address *</label>
            <input type="email" id="inputEmail" class="form-control"
              placeholder="your@email.com"
              required autocomplete="email" aria-required="true">
          </div>
          <div class="form-group">
            <label class="form-label" for="inputPhone">Phone Number *</label>
            <input type="tel" id="inputPhone" class="form-control"
              placeholder="+91 9876543210"
              required autocomplete="tel" aria-required="true">
          </div>
          <div class="form-group">
            <label class="form-label" for="teamRegistrationToggle">
              <input type="checkbox" id="teamRegistrationToggle" style="margin-right:8px;vertical-align:middle">
              Team registration (add teammates)
            </label>
          </div>
          <div id="teamSection" style="display:none;">
            <div class="form-group">
              <label class="form-label" for="inputTeamName">Team Name</label>
              <input type="text" id="inputTeamName" class="form-control"
                placeholder="Enter your team name"
                maxlength="100" autocomplete="organization">
            </div>
            <div class="form-group">
              <label class="form-label">Team Members</label>
              <div id="teamMembersContainer" style="display:grid;gap:10px"></div>
              <button type="button" id="btnAddTeammate" class="btn btn-outline" style="margin-top:10px;">
                + Add Teammate
              </button>
              <p style="font-size:12px;color:#666;margin-top:8px">Add teammate names to register the full group.</p>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Number of Tickets</label>
            <div class="ticket-counter" role="group" aria-label="Ticket quantity">
              <button type="button" id="ticketMinus" aria-label="Decrease tickets">−</button>
              <span class="count" id="ticketCount" aria-live="polite">1</span>
              <button type="button" id="ticketPlus" aria-label="Increase tickets">+</button>
            </div>
          </div>
          <div class="price-summary" aria-label="Price summary">
            <span class="label">Total Amount</span>
            <span class="amount" id="priceSummary">₹0.00</span>
          </div>
          <button type="submit" id="btnSendOTP" class="btn btn-primary btn-full">
            📱 Send OTP
          </button>
        </form>
      </div>

      <!-- ── STEP 2: OTP Verification ── -->
      <div class="booking-step" style="display:none">
        <div id="otpAlert" class="alert" style="display:none" role="alert" aria-live="assertive"></div>

          <div id="otpWidgetContainer" style="min-height:260px;margin-bottom:20px"></div>
        <div id="otpFallback" style="display:block;">
          <div class="otp-fallback-banner">
            <strong>Enter the OTP sent to your phone or email.</strong><br>
            If you do not receive it in 30 seconds, use the Resend OTP button below.
          </div>
          <div class="otp-info">
            OTP sent to <strong id="otpPhone"></strong><br>
            and <strong id="otpEmail"></strong>
          </div>

          <form id="otpForm" novalidate>
            <div class="otp-inputs" role="group" aria-label="Enter 4-digit OTP">
              <input type="text" class="otp-digit" maxlength="1" inputmode="numeric"
                pattern="[0-9]" aria-label="OTP digit 1">
              <input type="text" class="otp-digit" maxlength="1" inputmode="numeric"
                pattern="[0-9]" aria-label="OTP digit 2">
              <input type="text" class="otp-digit" maxlength="1" inputmode="numeric"
                pattern="[0-9]" aria-label="OTP digit 3">
              <input type="text" class="otp-digit" maxlength="1" inputmode="numeric"
                pattern="[0-9]" aria-label="OTP digit 4">
            </div>

            <p style="text-align:center;font-size:13px;color:#888;margin-bottom:16px">
              OTP expires in <?= OTP_EXPIRY_MINUTES ?> minutes
            </p>

            <button type="submit" id="btnVerifyOTP" class="btn btn-primary btn-full">
              ✓ Verify OTP
            </button>
          </form>

          <div style="text-align:center;margin-top:14px">
            <button id="btnResendOTP" class="resend-btn" disabled>
              Resend OTP<span id="resendTimer"></span>
            </button>
          </div>
        </div>
        <div style="text-align:center;margin-top:10px">
          <button id="btnBackToDetails" class="btn btn-outline" style="font-size:13px;padding:8px 16px">
            ← Back
          </button>
        </div>
      </div>

      <!-- ── STEP 3: Payment ── -->
      <div class="booking-step" style="display:none">
        <div id="paymentAlert" class="alert" style="display:none" role="alert" aria-live="assertive"></div>

        <div class="booking-timer" role="timer" aria-live="polite" aria-label="Booking expires in">
          <span>⏱</span>
          <span>Tickets reserved for: <strong id="bookingTimer">15:00</strong></span>
        </div>

        <div style="background:#f8f9ff;border-radius:8px;padding:16px;margin-bottom:20px">
          <h3 style="font-size:14px;color:#888;margin-bottom:12px;text-transform:uppercase;letter-spacing:1px">
            Payment Summary
          </h3>
          <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:14px">
            <span>Event</span>
            <strong id="paymentEventName"></strong>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:18px;font-weight:800;color:#6c63ff;border-top:1px solid #e0e0e0;padding-top:10px;margin-top:10px">
            <span>Total</span>
            <span id="paymentTotal">₹0.00</span>
          </div>
        </div>

        <button id="btnPay" class="btn btn-primary btn-full" style="font-size:16px;padding:14px" disabled>
          <span class="spinner"></span> Preparing payment...
        </button>

        <p style="text-align:center;font-size:12px;color:#888;margin-top:12px">
          🔒 Secured by Razorpay. Your payment info is never stored on our servers.
        </p>
      </div>

    </div><!-- /modal-body -->
  </div><!-- /modal -->
</div><!-- /modal-overlay -->

<!-- Loading Overlay -->
<div id="loadingOverlay" class="loading-overlay" role="status" aria-live="polite">
  <div class="loading-spinner"></div>
  <p class="loading-text">Processing...</p>
</div>

<!-- Footer -->
<?php require_once __DIR__ . '/includes/footer.php'; ?>

<!-- Scripts -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script type="text/javascript">
var configuration = {
  widgetId: "366564734b65373038303032",
  tokenAuth: "513951TEA34qlnAx069f8f158P1",
  identifier: "", // will be set dynamically when booking starts
  exposeMethods: true,
  success: (data) => {
      console.log('success response', data);
      if (typeof window.handleOtpWidgetSuccess === 'function') {
          window.handleOtpWidgetSuccess(data);
      }
  },
  failure: (error) => {
      console.log('failure reason', error);
      if (typeof window.handleOtpWidgetFailure === 'function') {
          window.handleOtpWidgetFailure(error);
      }
  },
  container: '#otpWidgetContainer'
};

(function loadOtpScript(urls) {
    let i = 0;
    function attempt() {
        const s = document.createElement('script');
        s.src = urls[i];
        s.async = true;
        s.onload = () => {
            if (typeof window.initSendOTP === 'function') {
                // Provider script loaded; the widget is initialized later after phone is known.
            }
        };
        s.onerror = () => {
            i++;
            if (i < urls.length) {
                attempt();
            }
        };
        document.head.appendChild(s);
    }
    attempt();
})([
    'https://verify.msg91.com/otp-provider.js',
    'https://verify.phone91.com/otp-provider.js'
]);
</script>

<!-- Firebase Configuration -->
<?php if (defined('OTP_PROVIDER') && OTP_PROVIDER === 'firebase'): ?>
<script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js"></script>
<script type="text/javascript">
// Firebase Configuration - Update with your Firebase project details
const firebaseConfig = {
  apiKey: "<?php echo defined('FIREBASE_API_KEY') ? htmlspecialchars(FIREBASE_API_KEY) : ''; ?>",
  authDomain: "YOUR_PROJECT.firebaseapp.com", // Update this
  projectId: "YOUR_PROJECT_ID", // Update this
  storageBucket: "YOUR_PROJECT.appspot.com", // Update this
  messagingSenderId: "YOUR_SENDER_ID", // Update this
  appId: "YOUR_APP_ID" // Update this
};

// Initialize Firebase
try {
  firebase.initializeApp(firebaseConfig);
  console.info('Firebase initialized for OTP verification');
} catch (err) {
  console.error('Firebase init error:', err);
}
</script>
<script src="assets/js/firebase-auth.js"></script>
<?php endif; ?>

<script src="assets/js/registration-validation.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
