<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/Logger.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$error   = '';
$success = '';
$ticketId = '';
$booking = null;
$existingRequest = null;

$conn = getDBConnection();

// ── Handle form submission ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingId   = preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($_POST['booking_id'] ?? '')));
    $email       = trim($_POST['email'] ?? '');
    $reason      = trim($_POST['reason'] ?? '');
    $reasonDetail= trim($_POST['reason_detail'] ?? '');

    $validReasons = ['event_cancelled','schedule_conflict','personal_emergency','duplicate_booking','other'];

    if (empty($bookingId) || empty($email) || empty($reason)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (!in_array($reason, $validReasons)) {
        $error = 'Invalid cancellation reason.';
    } else {
        // Verify booking belongs to this email
        $stmt = $conn->prepare(
            "SELECT cb.*, e.name AS event_name, e.event_date
             FROM confirmed_bookings cb
             JOIN events e ON cb.event_id = e.id
             WHERE cb.booking_id = ? AND cb.user_email = ?"
        );
        $stmt->bind_param('ss', $bookingId, $email);
        $stmt->execute();
        $booking = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$booking) {
            $error = 'Booking not found or email does not match.';
        } elseif ($booking['status'] === 'CANCELLED') {
            $error = 'This booking is already cancelled.';
        } elseif (strtotime($booking['event_date']) < time()) {
            $error = 'Cannot cancel a booking for a past event.';
        } else {
            // Check for existing cancellation support ticket
            $stmt = $conn->prepare(
                "SELECT ticket_id FROM support_tickets 
                 WHERE booking_id = ? AND category = 'cancellation' 
                 AND status IN ('open','in_progress')"
            );
            $stmt->bind_param('s', $bookingId);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($existing) {
                $error = 'A cancellation request for this booking already exists (Ticket: ' . $existing['ticket_id'] . ') and is being processed.';
            } else {
                // Create support ticket for cancellation
                $ticketId = 'ST' . date('Ymd') . strtoupper(bin2hex(random_bytes(4)));
                
                // Format reason for display
                $reasonLabels = [
                    'event_cancelled' => 'Event was cancelled by organizer',
                    'schedule_conflict' => 'Schedule conflict / Can\'t attend',
                    'personal_emergency' => 'Personal emergency',
                    'duplicate_booking' => 'Duplicate booking',
                    'other' => 'Other'
                ];
                $reasonText = $reasonLabels[$reason] ?? $reason;
                
                // Build ticket message
                $message = "CANCELLATION REQUEST\n\n";
                $message .= "Booking ID: {$bookingId}\n";
                $message .= "Event: {$booking['event_name']}\n";
                $message .= "Event Date: " . date('d M Y, h:i A', strtotime($booking['event_date'])) . "\n";
                $message .= "Tickets: {$booking['ticket_count']}\n";
                $message .= "Amount Paid: ₹" . number_format($booking['total_amount'], 2) . "\n\n";
                $message .= "Reason: {$reasonText}\n";
                if (!empty($reasonDetail)) {
                    $message .= "Additional Details: {$reasonDetail}\n";
                }
                $message .= "\n---\n";
                $message .= "This is an automated cancellation request. Please process the refund according to the cancellation policy.";
                
                $subject = "Cancellation Request - {$booking['event_name']}";
                
                // Insert support ticket
                $stmt = $conn->prepare(
                    "INSERT INTO support_tickets
                     (ticket_id, user_name, user_email, user_phone, booking_id, 
                      subject, category, message, status, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, 'cancellation', ?, 'open', NOW())"
                );
                $stmt->bind_param(
                    'sssssss',
                    $ticketId,
                    $booking['user_name'],
                    $booking['user_email'],
                    $booking['user_phone'],
                    $bookingId,
                    $subject,
                    $message
                );
                
                if ($stmt->execute()) {
                    $stmt->close();
                    
                    // Update booking status to CANCELLED
                    $stmt = $conn->prepare(
                        "UPDATE confirmed_bookings SET status = 'CANCELLED' WHERE booking_id = ?"
                    );
                    $stmt->bind_param('s', $bookingId);
                    $stmt->execute();
                    $stmt->close();

                    Logger::info('CancelTicket', "Cancellation support ticket created: $ticketId for booking $bookingId");

                    $success = $ticketId;
                } else {
                    $error = 'Failed to create cancellation request. Please try again or contact support.';
                    Logger::error('CancelTicket', "Failed to create support ticket: " . $stmt->error);
                    $stmt->close();
                }
            }
        }
    }
}

// ── Pre-fill from GET ───────────────────────────────────────
$prefillBookingId = preg_replace('/[^A-Z0-9]/', '', strtoupper($_GET['booking_id'] ?? ''));
if ($prefillBookingId && empty($_SESSION['user_id']) === false) {
    $userEmail = $_SESSION['user_email'] ?? '';
    $stmt = $conn->prepare(
        "SELECT cb.*, e.name AS event_name, e.event_date
         FROM confirmed_bookings cb
         JOIN events e ON cb.event_id = e.id
         WHERE cb.booking_id = ? AND cb.user_email = ?"
    );
    $stmt->bind_param('ss', $prefillBookingId, $userEmail);
    $stmt->execute();
    $booking = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

session_write_close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cancel Ticket – VelTech EventPass</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body { background:#f4f6fb; }
    .page-wrap { max-width:600px; margin:30px auto; padding:0 16px 40px; }
    .page-title { font-size:22px; font-weight:800; color:#003087; margin-bottom:6px; }
    .page-sub   { font-size:14px; color:#666; margin-bottom:24px; }
    .cancel-card { background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 4px 20px rgba(0,48,135,0.10); }
    .cancel-header { background:linear-gradient(135deg,#c62828,#e53935); color:#fff; padding:22px 24px; }
    .cancel-header h2 { font-size:18px; font-weight:700; margin-bottom:4px; }
    .cancel-header p  { font-size:12px; opacity:.85; }
    .cancel-body { padding:24px; }
    .policy-box { background:#fff3e0; border-left:4px solid #ff9800; border-radius:6px; padding:14px 16px; margin-bottom:20px; font-size:13px; }
    .policy-box h4 { color:#e65100; margin-bottom:8px; font-size:14px; }
    .policy-box ul { padding-left:18px; color:#555; line-height:1.8; }
    .booking-preview { background:#f4f6fb; border-radius:8px; padding:14px 16px; margin-bottom:20px; font-size:13px; }
    .booking-preview .row { display:flex; justify-content:space-between; padding:4px 0; }
    .booking-preview .key { color:#888; }
    .booking-preview .val { font-weight:600; color:#003087; }
    .success-box { text-align:center; padding:30px 20px; }
    .success-icon { font-size:56px; margin-bottom:16px; }
    .success-box h2 { color:#003087; font-size:20px; margin-bottom:8px; }
    .request-id { font-size:18px; font-weight:800; color:#003087; letter-spacing:2px; background:#e6edf8; padding:10px 20px; border-radius:8px; display:inline-block; margin:12px 0; }
  </style>
</head>
<body>
<?php require_once 'includes/navbar.php'; ?>

<div class="page-wrap">
  <h1 class="page-title">❌ Cancel Ticket</h1>
  <p class="page-sub">Submit a cancellation request for your booking</p>

  <?php if ($success): ?>
  <!-- ── Success State ── -->
  <div class="cancel-card">
    <div class="cancel-body">
      <div class="success-box">
        <div class="success-icon">✅</div>
        <h2>Cancellation Request Submitted</h2>
        <p style="color:#666;margin-bottom:12px">Your request has been received and is being reviewed.</p>
        <div class="request-id"><?= htmlspecialchars($success) ?></div>
        <p style="font-size:13px;color:#888;margin-top:12px">
          Save this <strong>Ticket ID</strong> for tracking.<br>
          You can track your cancellation status in the Support section.<br>
          Refund will be processed within <strong>5–7 business days</strong> to your original payment method.
        </p>
        <div style="display:flex;gap:12px;justify-content:center;margin-top:20px;flex-wrap:wrap">
          <a href="my-bookings.php" class="btn btn-primary" style="text-decoration:none">My Bookings</a>
          <a href="support.php?ticket_id=<?= urlencode($success) ?>" class="btn btn-outline" style="text-decoration:none">Track Ticket</a>
        </div>
      </div>
    </div>
  </div>

  <?php else: ?>

  <!-- ── Cancellation Policy ── -->
  <div class="policy-box">
    <h4>📋 Cancellation Policy</h4>
    <ul>
      <li>Cancellations accepted up to <strong>24 hours before</strong> the event</li>
      <li><strong>100% refund</strong> if cancelled 7+ days before event</li>
      <li><strong>50% refund</strong> if cancelled 2–6 days before event</li>
      <li><strong>No refund</strong> if cancelled within 24 hours of event</li>
      <li>Refund processed within 5–7 business days</li>
      <li>Free events (₹0) are non-refundable but can be cancelled</li>
    </ul>
  </div>

  <?php if ($error): ?>
  <div class="alert alert-danger" role="alert">⚠ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <div class="cancel-card">
    <div class="cancel-header">
      <h2>❌ Request Cancellation</h2>
      <p>Fill in the details below to cancel your ticket</p>
    </div>
    <div class="cancel-body">

      <?php if ($booking && empty($error)): ?>
      <!-- Booking preview -->
      <div class="booking-preview">
        <div style="font-size:12px;color:#888;margin-bottom:8px;text-transform:uppercase;letter-spacing:1px">Booking Details</div>
        <div class="row"><span class="key">Event</span><span class="val"><?= htmlspecialchars($booking['event_name']) ?></span></div>
        <div class="row"><span class="key">Date</span><span class="val"><?= date('d M Y, h:i A', strtotime($booking['event_date'])) ?></span></div>
        <div class="row"><span class="key">Tickets</span><span class="val"><?= $booking['ticket_count'] ?></span></div>
        <div class="row"><span class="key">Amount Paid</span><span class="val">₹<?= number_format($booking['total_amount'], 2) ?></span></div>
      </div>
      <?php endif; ?>

      <form method="POST" id="cancelForm" novalidate>
        <div class="form-group">
          <label class="form-label" for="booking_id">Booking ID *</label>
          <input type="text" id="booking_id" name="booking_id" class="form-control"
            placeholder="e.g. CB20260615ABCD1234"
            value="<?= htmlspecialchars($prefillBookingId ?: ($_POST['booking_id'] ?? '')) ?>"
            required style="text-transform:uppercase;font-family:monospace">
        </div>

        <div class="form-group">
          <label class="form-label" for="email">Registered Email *</label>
          <input type="email" id="email" name="email" class="form-control"
            placeholder="Email used during booking" required
            value="<?= htmlspecialchars($_SESSION['user_email'] ?? ($_POST['email'] ?? '')) ?>">
        </div>

        <div class="form-group">
          <label class="form-label" for="reason">Reason for Cancellation *</label>
          <select id="reason" name="reason" class="form-control" required>
            <option value="">Select a reason</option>
            <option value="event_cancelled"     <?= ($_POST['reason']??'')==='event_cancelled'?'selected':'' ?>>Event was cancelled by organizer</option>
            <option value="schedule_conflict"   <?= ($_POST['reason']??'')==='schedule_conflict'?'selected':'' ?>>Schedule conflict / Can't attend</option>
            <option value="personal_emergency"  <?= ($_POST['reason']??'')==='personal_emergency'?'selected':'' ?>>Personal emergency</option>
            <option value="duplicate_booking"   <?= ($_POST['reason']??'')==='duplicate_booking'?'selected':'' ?>>Duplicate booking</option>
            <option value="other"               <?= ($_POST['reason']??'')==='other'?'selected':'' ?>>Other</option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label" for="reason_detail">Additional Details (optional)</label>
          <textarea id="reason_detail" name="reason_detail" class="form-control" rows="3"
            placeholder="Provide any additional information..."><?= htmlspecialchars($_POST['reason_detail'] ?? '') ?></textarea>
        </div>

        <div style="background:#fce4ec;border-radius:8px;padding:12px 14px;font-size:13px;color:#c62828;margin-bottom:16px">
          ⚠ <strong>This action cannot be undone.</strong> Once submitted, your booking will be marked as cancelled.
        </div>

        <div style="display:flex;gap:12px">
          <button type="submit" class="btn" id="btnSubmit"
            style="flex:1;background:#c62828;color:#fff;font-size:14px;padding:12px;border-radius:8px;cursor:pointer;border:none;font-weight:600"
            onclick="return confirm('Are you sure you want to cancel this booking? This cannot be undone.')">
            ❌ Submit Cancellation Request
          </button>
          <a href="my-bookings.php" class="btn btn-outline" style="flex:1;text-decoration:none;text-align:center;padding:12px;font-size:14px">
            ← Go Back
          </a>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
</body>
</html>
