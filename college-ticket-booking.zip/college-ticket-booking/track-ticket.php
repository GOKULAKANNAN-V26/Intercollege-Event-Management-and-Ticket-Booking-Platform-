<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$error = '';
$ticket = null;
$ticketId = '';

// Get ticket ID from URL or POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticketId = strtoupper(trim($_POST['ticket_id'] ?? ''));
} else {
    $ticketId = strtoupper(trim($_GET['id'] ?? ''));
}

// Fetch ticket if ID provided
if (!empty($ticketId)) {
    try {
        $conn = getDBConnection();
        $stmt = $conn->prepare(
            "SELECT * FROM support_tickets WHERE ticket_id = ?"
        );
        $stmt->bind_param('s', $ticketId);
        $stmt->execute();
        $result = $stmt->get_result();
        $ticket = $result->fetch_assoc();
        $stmt->close();

        if (!$ticket) {
            $error = 'Ticket not found. Please check your Ticket ID and try again.';
        }
    } catch (Exception $e) {
        $error = 'Error fetching ticket. Please try again.';
    }
}

session_write_close();

// Status display configuration
$statusConfig = [
    'open' => [
        'label' => 'Open',
        'icon' => '🔴',
        'color' => '#ff9800',
        'bg' => '#fff3e0',
        'description' => 'Your ticket has been received and is waiting to be reviewed by our support team.'
    ],
    'in_progress' => [
        'label' => 'In Progress',
        'icon' => '🔵',
        'color' => '#2196f3',
        'bg' => '#e3f2fd',
        'description' => 'Our support team is actively working on your ticket.'
    ],
    'resolved' => [
        'label' => 'Resolved',
        'icon' => '✅',
        'color' => '#4caf50',
        'bg' => '#e8f5e9',
        'description' => 'Your issue has been resolved. If you need further assistance, please create a new ticket.'
    ],
    'closed' => [
        'label' => 'Closed',
        'icon' => '⚫',
        'color' => '#9e9e9e',
        'bg' => '#f5f5f5',
        'description' => 'This ticket has been closed. No further action will be taken.'
    ]
];

$categoryLabels = [
    'cancellation' => '🔴 Cancellation/Refund',
    'payment' => '💳 Payment Issue',
    'booking' => '🎟 Booking Problem',
    'technical' => '⚙️ Technical Issue',
    'password' => '🔑 Password/Account',
    'other' => '💬 Other'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Track Support Ticket – VelTech EventPass</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body { background:#f4f6fb; }
    .page-wrap { max-width:800px; margin:30px auto; padding:0 16px 40px; }
    .page-title { font-size:22px; font-weight:800; color:#003087; margin-bottom:6px; }
    .page-sub { font-size:14px; color:#666; margin-bottom:24px; }
    
    .track-card { background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 4px 20px rgba(0,48,135,0.10); margin-bottom:20px; }
    .track-header { background:linear-gradient(135deg,#003087,#0055b3); color:#fff; padding:22px 24px; }
    .track-header h2 { font-size:18px; font-weight:700; margin-bottom:4px; }
    .track-header p { font-size:12px; opacity:.85; }
    .track-body { padding:24px; }
    
    .search-box { background:#f8f9fa; border-radius:8px; padding:20px; margin-bottom:20px; }
    .search-box label { display:block; font-size:13px; font-weight:600; color:#333; margin-bottom:8px; }
    .search-input { display:flex; gap:10px; }
    .search-input input { flex:1; padding:12px 16px; border:2px solid #ddd; border-radius:8px; font-size:14px; font-family:monospace; text-transform:uppercase; }
    .search-input input:focus { border-color:#003087; outline:none; }
    .search-input button { padding:12px 24px; background:#003087; color:#fff; border:none; border-radius:8px; font-weight:600; cursor:pointer; }
    .search-input button:hover { background:#0055b3; }
    
    .ticket-info { background:#f8f9fa; border-radius:8px; padding:16px; margin-bottom:20px; }
    .ticket-info .row { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #e0e0e0; }
    .ticket-info .row:last-child { border-bottom:none; }
    .ticket-info .label { color:#666; font-size:13px; }
    .ticket-info .value { font-weight:600; color:#333; font-size:13px; }
    
    .status-timeline { position:relative; padding:20px 0; }
    .status-step { display:flex; align-items:flex-start; gap:16px; margin-bottom:30px; position:relative; }
    .status-step:last-child { margin-bottom:0; }
    .status-step::before { content:''; position:absolute; left:19px; top:40px; bottom:-30px; width:2px; background:#e0e0e0; }
    .status-step:last-child::before { display:none; }
    .status-step.active::before { background:#003087; }
    
    .status-icon { width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0; border:3px solid #e0e0e0; background:#fff; z-index:1; }
    .status-step.active .status-icon { border-color:#003087; background:#003087; color:#fff; }
    .status-step.completed .status-icon { border-color:#4caf50; background:#4caf50; color:#fff; }
    
    .status-content { flex:1; }
    .status-title { font-size:15px; font-weight:700; color:#333; margin-bottom:4px; }
    .status-step.active .status-title { color:#003087; }
    .status-desc { font-size:13px; color:#666; line-height:1.6; }
    .status-time { font-size:11px; color:#999; margin-top:4px; }
    
    .message-box { background:#fff; border:1px solid #e0e0e0; border-radius:8px; padding:16px; margin-bottom:16px; }
    .message-box .header { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; padding-bottom:10px; border-bottom:1px solid #f0f0f0; }
    .message-box .author { font-weight:700; color:#003087; font-size:14px; }
    .message-box .time { font-size:11px; color:#999; }
    .message-box .content { font-size:13px; color:#333; line-height:1.7; }
    
    .admin-reply { background:#e8f5e9; border-color:#4caf50; }
    .admin-reply .author { color:#2e7d32; }
    
    .status-badge { display:inline-block; padding:4px 12px; border-radius:20px; font-size:11px; font-weight:700; }
    .category-badge { display:inline-block; padding:3px 10px; border-radius:4px; font-size:11px; font-weight:600; background:#e6edf8; color:#003087; }
    
    .empty-state { text-align:center; padding:60px 20px; }
    .empty-state .icon { font-size:64px; margin-bottom:16px; opacity:0.5; }
    .empty-state h3 { color:#003087; margin-bottom:8px; }
    .empty-state p { color:#666; margin-bottom:20px; }
  </style>
</head>
<body>
<?php require_once 'includes/navbar.php'; ?>

<div class="page-wrap">
  <h1 class="page-title">🔍 Track Support Ticket</h1>
  <p class="page-sub">Enter your ticket ID to view status and updates</p>

  <!-- Search Box -->
  <div class="track-card">
    <div class="track-body">
      <div class="search-box">
        <label for="ticket_id">Ticket ID</label>
        <form method="POST" class="search-input">
          <input type="text" id="ticket_id" name="ticket_id" 
            placeholder="e.g. ST2026050677D35ED1" 
            value="<?= htmlspecialchars($ticketId) ?>"
            pattern="[A-Z0-9]+" 
            required>
          <button type="submit">🔍 Track</button>
        </form>
        <p style="font-size:12px;color:#666;margin-top:8px">
          💡 Your Ticket ID was sent to your email when you submitted the ticket
        </p>
      </div>
    </div>
  </div>

  <?php if ($error): ?>
  <div class="alert alert-danger" role="alert">⚠ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if ($ticket): ?>
  
  <!-- Ticket Details -->
  <div class="track-card">
    <div class="track-header">
      <h2>📋 Ticket Details</h2>
      <p>Ticket ID: <?= htmlspecialchars($ticket['ticket_id']) ?></p>
    </div>
    <div class="track-body">
      
      <div class="ticket-info">
        <div class="row">
          <span class="label">Status</span>
          <span class="value">
            <?php 
            $status = $ticket['status'];
            $config = $statusConfig[$status];
            ?>
            <span class="status-badge" style="background:<?= $config['bg'] ?>;color:<?= $config['color'] ?>">
              <?= $config['icon'] ?> <?= $config['label'] ?>
            </span>
          </span>
        </div>
        <div class="row">
          <span class="label">Category</span>
          <span class="value">
            <span class="category-badge"><?= $categoryLabels[$ticket['category']] ?? $ticket['category'] ?></span>
          </span>
        </div>
        <div class="row">
          <span class="label">Subject</span>
          <span class="value"><?= htmlspecialchars($ticket['subject']) ?></span>
        </div>
        <div class="row">
          <span class="label">Submitted</span>
          <span class="value"><?= date('d M Y, h:i A', strtotime($ticket['created_at'])) ?></span>
        </div>
        <?php if ($ticket['updated_at'] && $ticket['updated_at'] !== $ticket['created_at']): ?>
        <div class="row">
          <span class="label">Last Updated</span>
          <span class="value"><?= date('d M Y, h:i A', strtotime($ticket['updated_at'])) ?></span>
        </div>
        <?php endif; ?>
        <?php if ($ticket['booking_id']): ?>
        <div class="row">
          <span class="label">Related Booking</span>
          <span class="value" style="font-family:monospace"><?= htmlspecialchars($ticket['booking_id']) ?></span>
        </div>
        <?php endif; ?>
      </div>

      <!-- Status Timeline -->
      <h3 style="font-size:16px;font-weight:700;color:#003087;margin:24px 0 16px">📊 Status Timeline</h3>
      <div class="status-timeline">
        
        <div class="status-step completed">
          <div class="status-icon">✓</div>
          <div class="status-content">
            <div class="status-title">Ticket Submitted</div>
            <div class="status-desc">Your support ticket has been received</div>
            <div class="status-time"><?= date('d M Y, h:i A', strtotime($ticket['created_at'])) ?></div>
          </div>
        </div>

        <div class="status-step <?= in_array($status, ['in_progress','resolved','closed']) ? 'completed' : ($status === 'open' ? 'active' : '') ?>">
          <div class="status-icon"><?= $status === 'open' ? '🔴' : '✓' ?></div>
          <div class="status-content">
            <div class="status-title">Under Review</div>
            <div class="status-desc">Our support team is reviewing your ticket</div>
            <?php if ($status !== 'open'): ?>
            <div class="status-time">Reviewed</div>
            <?php endif; ?>
          </div>
        </div>

        <div class="status-step <?= in_array($status, ['resolved','closed']) ? 'completed' : ($status === 'in_progress' ? 'active' : '') ?>">
          <div class="status-icon"><?= $status === 'in_progress' ? '🔵' : ($status === 'resolved' || $status === 'closed' ? '✓' : '○') ?></div>
          <div class="status-content">
            <div class="status-title">In Progress</div>
            <div class="status-desc">Support team is working on resolving your issue</div>
            <?php if (in_array($status, ['resolved','closed'])): ?>
            <div class="status-time">Processed</div>
            <?php endif; ?>
          </div>
        </div>

        <div class="status-step <?= $status === 'resolved' || $status === 'closed' ? 'completed' : '' ?>">
          <div class="status-icon"><?= $status === 'resolved' || $status === 'closed' ? '✅' : '○' ?></div>
          <div class="status-content">
            <div class="status-title">Resolved</div>
            <div class="status-desc">Your issue has been resolved</div>
            <?php if ($status === 'resolved' || $status === 'closed'): ?>
            <div class="status-time"><?= date('d M Y, h:i A', strtotime($ticket['updated_at'])) ?></div>
            <?php endif; ?>
          </div>
        </div>

      </div>

      <!-- Messages -->
      <h3 style="font-size:16px;font-weight:700;color:#003087;margin:24px 0 16px">💬 Messages</h3>
      
      <!-- User's Original Message -->
      <div class="message-box">
        <div class="header">
          <span class="author">You</span>
          <span class="time"><?= date('d M Y, h:i A', strtotime($ticket['created_at'])) ?></span>
        </div>
        <div class="content"><?= nl2br(htmlspecialchars($ticket['message'])) ?></div>
      </div>

      <!-- Admin Reply -->
      <?php if ($ticket['admin_reply']): ?>
      <div class="message-box admin-reply">
        <div class="header">
          <span class="author">Support Team</span>
          <span class="time"><?= date('d M Y, h:i A', strtotime($ticket['updated_at'])) ?></span>
        </div>
        <div class="content"><?= nl2br(htmlspecialchars($ticket['admin_reply'])) ?></div>
      </div>
      <?php else: ?>
      <div style="background:#f8f9fa;border-radius:8px;padding:16px;text-align:center;color:#666;font-size:13px">
        ⏳ Waiting for support team response...
      </div>
      <?php endif; ?>

      <!-- Actions -->
      <div style="margin-top:24px;display:flex;gap:12px;flex-wrap:wrap">
        <?php if ($status !== 'closed'): ?>
        <a href="support.php?ticket_id=<?= urlencode($ticket['ticket_id']) ?>" 
           class="btn btn-outline" style="text-decoration:none">
          💬 Add Follow-up
        </a>
        <?php endif; ?>
        <a href="support.php" class="btn btn-outline" style="text-decoration:none">
          📩 New Ticket
        </a>
        <button onclick="window.print()" class="btn btn-outline">
          🖨 Print
        </button>
      </div>

    </div>
  </div>

  <?php elseif (!empty($ticketId)): ?>
  
  <!-- Not Found State -->
  <div class="track-card">
    <div class="track-body">
      <div class="empty-state">
        <div class="icon">🔍</div>
        <h3>Ticket Not Found</h3>
        <p>We couldn't find a ticket with ID: <strong><?= htmlspecialchars($ticketId) ?></strong></p>
        <p style="font-size:13px;color:#888">Please check your Ticket ID and try again, or contact support for assistance.</p>
        <a href="support.php" class="btn btn-primary" style="text-decoration:none">Contact Support</a>
      </div>
    </div>
  </div>

  <?php endif; ?>

  <!-- Help Box -->
  <div style="background:#e6edf8;border-radius:12px;padding:16px;margin-top:20px;font-size:13px;color:#003087">
    <strong>💡 Need Help?</strong><br>
    <span style="font-size:12px;color:#555">
      If you can't find your Ticket ID, check your email or contact us at 
      <a href="mailto:support@veltech.edu.in" style="color:#003087;font-weight:600">support@veltech.edu.in</a>
    </span>
  </div>

</div>

<?php require_once 'includes/footer.php'; ?>
</body>
</html>
