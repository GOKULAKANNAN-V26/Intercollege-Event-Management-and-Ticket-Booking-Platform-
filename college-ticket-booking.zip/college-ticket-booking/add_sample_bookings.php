<?php
/**
 * Add Sample Bookings for Testing
 * This script creates sample confirmed bookings for the logged-in user
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Check if user is logged in
if (empty($_SESSION['user_id'])) {
    die('❌ Please login first to add sample bookings. <a href="login.php">Login</a>');
}

$userEmail = $_SESSION['user_email'];
$userName = $_SESSION['user_name'];
$userPhone = $_SESSION['user_phone'] ?? '9876543210';

echo "<h1>Adding Sample Bookings</h1>";
echo "<p>User: <strong>$userName</strong> ($userEmail)</p>";
echo "<hr>";

$conn = getDBConnection();

// Get available events
$eventsResult = $conn->query("SELECT * FROM events WHERE status = 'active' ORDER BY event_date ASC LIMIT 5");
$events = [];
while ($row = $eventsResult->fetch_assoc()) {
    $events[] = $row;
}

if (empty($events)) {
    die('❌ No active events found. Please create some events first in the admin panel.');
}

echo "<h2>Found " . count($events) . " events</h2>";

// Create sample bookings
$bookingsCreated = 0;
$bookingsSkipped = 0;

foreach ($events as $event) {
    // Check if user already has a booking for this event
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM confirmed_bookings WHERE event_id = ? AND user_email = ?");
    $stmt->bind_param('is', $event['id'], $userEmail);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    if ($row['count'] > 0) {
        echo "<p>⏭️ Skipped: <strong>{$event['name']}</strong> (already booked)</p>";
        $bookingsSkipped++;
        continue;
    }
    
    // Create booking
    $bookingId = 'CB' . date('Ymd') . strtoupper(bin2hex(random_bytes(4)));
    $pendingRef = 'BK' . strtoupper(bin2hex(random_bytes(8)));
    $paymentId = 'pay_SAMPLE' . time() . rand(1000, 9999);
    $orderId = 'order_SAMPLE' . time() . rand(1000, 9999);
    $ticketCount = rand(1, 3);
    $totalAmount = $event['ticket_price'] * $ticketCount;
    
    try {
        $stmt = $conn->prepare(
            "INSERT INTO confirmed_bookings 
             (booking_id, pending_booking_ref, event_id, user_name, user_email, user_phone, 
              ticket_count, total_amount, payment_id, razorpay_order_id, status, confirmed_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PAID', NOW())"
        );
        $stmt->bind_param('ssisssidss',
            $bookingId, $pendingRef, $event['id'], $userName, $userEmail, $userPhone,
            $ticketCount, $totalAmount, $paymentId, $orderId
        );
        
        if ($stmt->execute()) {
            echo "<p>✅ Created booking for: <strong>{$event['name']}</strong></p>";
            echo "<ul>";
            echo "<li>Booking ID: <code>$bookingId</code></li>";
            echo "<li>Tickets: $ticketCount</li>";
            echo "<li>Amount: ₹" . number_format($totalAmount, 2) . "</li>";
            echo "<li>Event Date: " . date('d M Y', strtotime($event['event_date'])) . "</li>";
            echo "</ul>";
            $bookingsCreated++;
        } else {
            echo "<p>❌ Failed to create booking for: <strong>{$event['name']}</strong></p>";
            echo "<p>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
        
    } catch (Exception $e) {
        echo "<p>❌ Error creating booking for <strong>{$event['name']}</strong>: " . $e->getMessage() . "</p>";
    }
}

echo "<hr>";
echo "<h2>Summary</h2>";
echo "<p>✅ Bookings Created: <strong>$bookingsCreated</strong></p>";
echo "<p>⏭️ Bookings Skipped: <strong>$bookingsSkipped</strong></p>";

if ($bookingsCreated > 0) {
    echo "<hr>";
    echo "<h3>Next Steps:</h3>";
    echo "<ol>";
    echo "<li><a href='my-bookings.php'>View My Bookings</a></li>";
    echo "<li><a href='index.php'>Browse More Events</a></li>";
    echo "<li><strong>Delete this file before production:</strong> <code>add_sample_bookings.php</code></li>";
    echo "</ol>";
}

echo "<hr>";
echo "<p><a href='index.php'>← Back to Homepage</a></p>";
?>
