<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'college_events');
define('DB_PORT', 3306);

function getDBConnection() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
        if ($conn->connect_error) {
            error_log("DB Connection failed: " . $conn->connect_error);
            throw new Exception("Database connection failed.");
        }
        $conn->set_charset("utf8mb4");
        $conn->query("SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE");
    }
    return $conn;
}
?>
