<?php
// App Settings
define('APP_NAME', 'VelTech EventPass');
define('APP_SHORT_NAME', 'EventPass');
define('APP_COLLEGE', 'Vel Tech Rangarajan Dr. Sagunthala R&D Institute of Science and Technology');
define('APP_COLLEGE_SHORT', 'Vel Tech University');
define('APP_URL', 'http://localhost/college-ticket-booking');
define('APP_ENV', 'development'); // 'production' in live

// Razorpay
define('RAZORPAY_KEY_ID', 'rzp_test_SlPoCiiwiPBArC');
define('RAZORPAY_KEY_SECRET', 'EsSk4ZEcrdk90smJbrY8XxK1');
define('RAZORPAY_WEBHOOK_SECRET', 'your_webhook_secret_here');

// Email (SMTP)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your_email@gmail.com');
define('SMTP_PASS', 'your_app_password');
define('SMTP_FROM_NAME', 'VelTech EventPass');

// MSG91 SMS Configuration
define('MSG91_API_KEY', '513951AVg51wznUF69fa2343P1'); // Get from https://www.msg91.com/user/api
// Your approved sender ID must be exactly 6 characters and approved by MSG91 for transactional OTP SMS.
define('MSG91_SENDER_ID', 'EVENTP');
define('MSG91_ROUTE', '4'); // Route: 1=Promotional, 4=Transactional (use 4 for OTP)
define('MSG91_API_URL', 'https://api.msg91.com/api/sendhttp.php');

// Firebase Configuration (for OTP verification)
define('FIREBASE_API_KEY', 'AdrTqXEoSlsdu1H9WC6vqIG7Uz4gOn7L_v10pmDbUDutfos5AKAc2s2SrQ582psGjG02d2nzIbNR7vTW3A6t8_w94PyBbDnAd9-JVQwCDMh4ZNdrXZUk0q9RAxYKxuEZf-X8RgdFfOfdriYu1n1B-IyAnw');
define('FIREBASE_AUTH_URL', 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPhoneNumber');
define('OTP_PROVIDER', 'firebase'); // Options: 'msg91', 'firebase', 'hybrid'

// OTP Settings
define('OTP_EXPIRY_MINUTES', 10);
define('OTP_MAX_RETRIES', 3);
define('OTP_RESEND_COOLDOWN_SECONDS', 60);

// Booking Settings
define('BOOKING_EXPIRY_MINUTES', 15);
define('MAX_TICKETS_PER_BOOKING', 10);

// Admin
define('ADMIN_SESSION_TIMEOUT', 3600);

// Paths
define('ROOT_PATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);
define('UPLOADS_PATH', ROOT_PATH . 'uploads' . DIRECTORY_SEPARATOR);
define('RECEIPTS_PATH', UPLOADS_PATH . 'receipts' . DIRECTORY_SEPARATOR);

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Error reporting
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
ini_set('log_errors', 1);
ini_set('error_log', ROOT_PATH . 'logs' . DIRECTORY_SEPARATOR . 'error.log');
?>
