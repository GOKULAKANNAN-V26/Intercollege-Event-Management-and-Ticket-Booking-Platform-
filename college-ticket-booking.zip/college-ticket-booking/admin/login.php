<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

session_start();

// Already logged in
if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Redirect direct admin login page access to shared login page
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error = 'Please enter username and password.';
    } else {
        try {
            $conn = getDBConnection();
            $stmt = $conn->prepare("SELECT id, username, password_hash FROM admins WHERE username = ?");
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $result = $stmt->get_result();
            $admin = $result->fetch_assoc();
            $stmt->close();

            if ($admin && password_verify($password, $admin['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id']   = $admin['id'];
                $_SESSION['admin_user'] = $admin['username'];
                $_SESSION['admin_ts']   = time();

                // Update last login
                $stmt = $conn->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?");
                $stmt->bind_param('i', $admin['id']);
                $stmt->execute();
                $stmt->close();

                session_write_close();
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Invalid username or password.';
            }
        } catch (Exception $e) {
            $error = 'Login failed. Please try again.';
        }
    }
}
session_write_close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    body { display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh; background:#f4f6fb; }
    .login-top-bar { background:#003087; width:100%; padding:10px 20px; display:flex; align-items:center; gap:12px; position:fixed; top:0; left:0; }
    .login-top-bar img { height:36px; filter:brightness(0) invert(1); }
    .login-top-bar span { color:#FFD700; font-size:12px; font-weight:600; }
    .login-card { background:#fff; border-radius:16px; padding:40px; width:100%; max-width:400px; box-shadow:0 8px 30px rgba(0,48,135,0.15); margin-top:70px; }
    .login-logo { text-align:center; margin-bottom:28px; }
    .login-logo img { height:56px; margin-bottom:10px; }
    .login-logo h1 { font-size:22px; color:#003087; font-weight:800; }
    .login-logo .owned { font-size:11px; color:#888; margin-top:4px; line-height:1.4; }
  </style>
</head>
<body>
<!-- Top bar -->
<div class="login-top-bar">
  <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
  <span>Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology</span>
</div>

<div class="login-card">
  <div class="login-logo">
    <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
    <h1>🎟 VelTech EventPass</h1>
    <p class="owned">
      Owned &amp; Operated by<br>
      <strong>Vel Tech Rangarajan Dr. Sagunthala R&amp;D<br>Institute of Science and Technology</strong>
    </p>
    <p style="color:#888;font-size:13px;margin-top:8px">Admin Panel</p>
  </div>

  <?php if ($error): ?>
  <div class="alert alert-danger" role="alert"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" novalidate>
    <div class="form-group">
      <label class="form-label" for="username">Username</label>
      <input type="text" id="username" name="username" class="form-control"
        placeholder="admin" required autocomplete="username"
        value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
    </div>
    <div class="form-group">
      <label class="form-label" for="password">Password</label>
      <input type="password" id="password" name="password" class="form-control"
        placeholder="••••••••" required autocomplete="current-password">
    </div>
    <button type="submit" class="btn btn-primary btn-full" style="margin-top:8px">
      Login →
    </button>
  </form>

  <p style="text-align:center;margin-top:16px;font-size:12px;color:#aaa">
    Default: admin / password (change in production)
  </p>
</div>
</body>
</html>
