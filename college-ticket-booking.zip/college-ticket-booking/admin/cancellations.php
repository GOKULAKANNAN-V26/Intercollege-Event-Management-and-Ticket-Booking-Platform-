<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();
$message = '';
$messageType = 'success';

// Handle approve/reject for cancellation support tickets
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticketId   = trim($_POST['ticket_id'] ?? '');
    $action     = trim($_POST['action'] ?? '');
    $adminReply = trim($_POST['admin_reply'] ?? '');
    $refundAmt  = (float)($_POST['refund_amount'] ?? 0);

    if ($action === 'approve') {
        $conn->begin_transaction();
        try {
            // Get ticket details
            $stmt = $conn->prepare(
                "SELECT * FROM support_tickets 
                 WHERE ticket_id = ? AND category = 'cancellation' AND status IN ('open','in_progress')"
            );
            $stmt->bind_param('s', $ticketId);
            $stmt->execute();
            $ticket = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$ticket) {
                $conn->rollback();
                $message = "Ticket not found or already processed.";
                $messageType = 'danger';
            } else {
                $bookingId = $ticket['booking_id'];
                
                // Get booking details
                $stmt = $conn->prepare(
                    "SELECT cb.*, e.id as event_id FROM confirmed_bookings cb
                     JOIN events e ON cb.event_id = e.id
                     WHERE cb.booking_id = ?"
                );
                $stmt->bind_param('s', $bookingId);
                $stmt->execute();
                $booking = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$booking) {
                    $conn->rollback();
                    $message = "Booking not found for ticket {$ticketId}.";
                    $messageType = 'danger';
                } else {
                    // 1. Update support ticket to resolved
                    $replyText = $adminReply ?: "Your cancellation request has been approved. Refund of ₹" . number_format($refundAmt, 2) . " will be processed within 5-7 business days.";
                    $stmt = $conn->prepare(
                        "UPDATE support_tickets
                         SET status='resolved', admin_reply=?, updated_at=NOW()
                         WHERE ticket_id=?"
                    );
                    $stmt->bind_param('ss', $replyText, $ticketId);
                    $stmt->execute();
                    $stmt->close();

                    // 2. Update confirmed booking status + refund info
                    $stmt = $conn->prepare(
                        "UPDATE confirmed_bookings
                         SET status='CANCELLED', refund_status='pending', refund_amount=?
                         WHERE booking_id=?"
                    );
                    $stmt->bind_param('ds', $refundAmt, $bookingId);
                    $stmt->execute();
                    $stmt->close();

                    // 3. RESTORE tickets to event
                    $stmt = $conn->prepare(
                        "UPDATE events SET available_tickets = available_tickets + ? WHERE id = ?"
                    );
                    $stmt->bind_param('ii', $booking['ticket_count'], $booking['event_id']);
                    $stmt->execute();
                    $stmt->close();

                    $conn->commit();
                    $message = "Cancellation approved for ticket {$ticketId}. {$booking['ticket_count']} ticket(s) restored to event.";
                }
            }
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Error: " . $e->getMessage();
            $messageType = 'danger';
        }
    } elseif ($action === 'reject') {
        $conn->begin_transaction();
        try {
            // Get ticket details
            $stmt = $conn->prepare(
                "SELECT booking_id FROM support_tickets WHERE ticket_id = ?"
            );
            $stmt->bind_param('s', $ticketId);
            $stmt->execute();
            $ticket = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($ticket) {
                // Update ticket to closed with rejection message
                $replyText = $adminReply ?: "Your cancellation request has been rejected. Please contact support if you have questions.";
                $stmt = $conn->prepare(
                    "UPDATE support_tickets
                     SET status='closed', admin_reply=?, updated_at=NOW()
                     WHERE ticket_id=?"
                );
                $stmt->bind_param('ss', $replyText, $ticketId);
                $stmt->execute();
                $stmt->close();

                // Restore booking status to PAID (un-cancel it)
                $stmt = $conn->prepare(
                    "UPDATE confirmed_bookings SET status='PAID' WHERE booking_id=? AND status='CANCELLED'"
                );
                $stmt->bind_param('s', $ticket['booking_id']);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                $message = "Cancellation rejected for ticket {$ticketId}. Booking restored.";
            } else {
                $conn->rollback();
                $message = "Ticket not found.";
                $messageType = 'danger';
            }
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Error: " . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

// Fetch cancellation support tickets
$filter = $_GET['status'] ?? 'open';
$tickets = [];

// Map filter to support ticket statuses
$statusMap = [
    'open' => ['open', 'in_progress'],
    'approved' => ['resolved'],
    'rejected' => ['closed']
];

$statuses = $statusMap[$filter] ?? ['open'];
$placeholders = implode(',', array_fill(0, count($statuses), '?'));

$stmt = $conn->prepare(
    "SELECT st.*, cb.ticket_count, cb.total_amount, e.name as event_name
     FROM support_tickets st
     LEFT JOIN confirmed_bookings cb ON st.booking_id = cb.booking_id
     LEFT JOIN events e ON cb.event_id = e.id
     WHERE st.category = 'cancellation' AND st.status IN ($placeholders)
     ORDER BY st.created_at DESC"
);
$stmt->bind_param(str_repeat('s', count($statuses)), ...$statuses);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) $tickets[] = $row;
$stmt->close();

// Get counts
$counts = [];
$counts['open'] = $conn->query(
    "SELECT COUNT(*) FROM support_tickets WHERE category='cancellation' AND status IN ('open','in_progress')"
)->fetch_row()[0];
$counts['approved'] = $conn->query(
    "SELECT COUNT(*) FROM support_tickets WHERE category='cancellation' AND status='resolved'"
)->fetch_row()[0];
$counts['rejected'] = $conn->query(
    "SELECT COUNT(*) FROM support_tickets WHERE category='cancellation' AND status='closed'"
)->fetch_row()[0];
?>
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cancellations – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .admin-layout { display:flex; min-height:100vh; }
    .sidebar { width:240px; background:#003087; color:#fff; padding:0; flex-shrink:0; display:flex; flex-direction:column; }
    .sidebar-brand { padding:16px 20px; border-bottom:1px solid rgba(255,255,255,0.15); background:#002060; }
    .sidebar-brand img { height:36px; filter:brightness(0) invert(1); display:block; margin-bottom:8px; }
    .sidebar-brand .app-title { font-size:15px; font-weight:800; color:#FFD700; }
    .sidebar-brand .college-name { font-size:9px; color:rgba(255,255,255,0.6); line-height:1.4; margin-top:3px; }
    .sidebar a { display:flex; align-items:center; gap:10px; padding:12px 20px; color:rgba(255,255,255,0.8); text-decoration:none; font-size:14px; border-left:3px solid transparent; transition:all .2s; }
    .sidebar a:hover, .sidebar a.active { background:rgba(255,215,0,0.15); color:#FFD700; border-left-color:#FFD700; }
    .main-content { flex:1; padding:24px; overflow-x:auto; background:#f4f6fb; }
    .page-title { font-size:22px; font-weight:700; margin-bottom:20px; color:#003087; }
    .tab-bar { display:flex; gap:8px; margin-bottom:20px; flex-wrap:wrap; }
    .tab { padding:8px 18px; border-radius:20px; font-size:13px; font-weight:600; text-decoration:none; background:#fff; color:#666; border:1px solid #dde3ee; }
    .tab.active { background:#003087; color:#fff; border-color:#003087; }
    .tab .cnt { background:rgba(255,255,255,0.3); border-radius:10px; padding:1px 7px; font-size:11px; margin-left:4px; }
    .tab:not(.active) .cnt { background:#e6edf8; color:#003087; }
    .card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.06); margin-bottom:16px; }
    .req-header { display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px; margin-bottom:12px; }
    .req-id { font-family:monospace; font-size:13px; font-weight:700; color:#003087; }
    .req-meta { font-size:13px; color:#666; display:flex; flex-wrap:wrap; gap:12px; margin-bottom:10px; }
    .badge { padding:3px 10px; border-radius:20px; font-size:11px; font-weight:700; }
    .badge-pending  { background:#fff3e0; color:#e65100; }
    .badge-approved { background:#e8f5e9; color:#2e7d32; }
    .badge-rejected { background:#fce4ec; color:#c62828; }
    .badge-refunded { background:#e3f2fd; color:#1565c0; }
    .action-form { background:#f4f6fb; border-radius:8px; padding:14px; margin-top:12px; }
    .action-form h4 { font-size:13px; font-weight:700; color:#003087; margin-bottom:10px; }
    .action-row { display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <div class="app-title">🎟 VelTech EventPass</div>
      <div class="college-name">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute</div>
    </div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="events.php">🎉 Events</a>
    <a href="bookings.php">🎟 Bookings</a>
    <a href="cancellations.php" class="active">❌ Cancellations</a>
    <a href="support-tickets.php">💬 Support</a>
    <a href="reports.php">📈 Reports</a>
    <a href="logout.php" style="color:#ff6b6b;margin-top:auto">🚪 Logout</a>
  </aside>

  <main class="main-content">
    <h1 class="page-title">❌ Cancellation Requests</h1>

    <?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="tab-bar">
      <?php foreach (['open'=>'⏳ Pending','approved'=>'✅ Approved','rejected'=>'❌ Rejected'] as $s => $label): ?>
      <a href="?status=<?= $s ?>" class="tab <?= $filter===$s?'active':'' ?>">
        <?= $label ?><span class="cnt"><?= $counts[$s] ?></span>
      </a>
      <?php endforeach; ?>
    </div>

    <?php if (empty($tickets)): ?>
    <div style="text-align:center;padding:40px;background:#fff;border-radius:12px;color:#888">
      No <?= $filter ?> cancellation requests found.
    </div>
    <?php endif; ?>

    <?php foreach ($tickets as $t): ?>
    <div class="card">
      <div class="req-header">
        <div>
          <span class="req-id"><?= htmlspecialchars($t['ticket_id']) ?></span>
          &nbsp;→&nbsp;
          <span style="font-family:monospace;font-size:12px;color:#666"><?= htmlspecialchars($t['booking_id']) ?></span>
        </div>
        <span class="badge badge-<?= $filter ?>"><?= strtoupper($filter) ?></span>
      </div>
      <div class="req-meta">
        <span>👤 <?= htmlspecialchars($t['user_name']) ?></span>
        <span>📧 <?= htmlspecialchars($t['user_email']) ?></span>
        <?php if ($t['user_phone']): ?><span>📞 <?= htmlspecialchars($t['user_phone']) ?></span><?php endif; ?>
        <?php if ($t['event_name']): ?><span>🎉 <?= htmlspecialchars($t['event_name']) ?></span><?php endif; ?>
        <?php if ($t['ticket_count']): ?><span>🎫 <?= $t['ticket_count'] ?> ticket(s)</span><?php endif; ?>
        <?php if ($t['total_amount']): ?><span>💰 ₹<?= number_format($t['total_amount'], 2) ?></span><?php endif; ?>
      </div>
      
      <div style="font-size:14px;font-weight:600;color:#003087;margin-bottom:8px">
        <?= htmlspecialchars($t['subject']) ?>
      </div>
      
      <div style="background:#f4f6fb;border-radius:8px;padding:12px 14px;font-size:13px;color:#444;margin-bottom:10px;white-space:pre-line">
        <?= htmlspecialchars($t['message']) ?>
      </div>
      
      <div style="font-size:12px;color:#aaa">
        Requested: <?= date('d M Y, h:i A', strtotime($t['created_at'])) ?>
        <?php if ($t['updated_at'] && $t['updated_at'] !== $t['created_at']): ?>
        &nbsp;|&nbsp; Updated: <?= date('d M Y, h:i A', strtotime($t['updated_at'])) ?>
        <?php endif; ?>
      </div>
      
      <?php if ($t['admin_reply']): ?>
      <div style="background:#e8f5e9;border-radius:8px;padding:12px 14px;font-size:13px;color:#2e7d32;margin-top:10px">
        <strong>Admin Reply:</strong><br><?= nl2br(htmlspecialchars($t['admin_reply'])) ?>
      </div>
      <?php endif; ?>

      <?php if ($t['status'] === 'open' || $t['status'] === 'in_progress'): ?>
      <div class="action-form">
        <h4>Process Cancellation Request</h4>
        <div class="action-row">
          <form method="POST" style="display:contents">
            <input type="hidden" name="ticket_id" value="<?= $t['ticket_id'] ?>">
            <div class="form-group" style="flex:1;min-width:200px;margin:0">
              <label class="form-label" style="font-size:12px">Admin Reply (optional)</label>
              <input type="text" name="admin_reply" class="form-control" style="font-size:13px" 
                placeholder="Custom message to user">
            </div>
            <div class="form-group" style="width:130px;margin:0">
              <label class="form-label" style="font-size:12px">Refund Amount (₹)</label>
              <input type="number" name="refund_amount" class="form-control" style="font-size:13px"
                value="<?= $t['total_amount'] ?? 0 ?>" min="0" step="0.01">
            </div>
            <button type="submit" name="action" value="approve"
              class="btn" style="background:#2e7d32;color:#fff;padding:10px 18px;font-size:13px;border-radius:8px;cursor:pointer;border:none;align-self:flex-end">
              ✅ Approve
            </button>
            <button type="submit" name="action" value="reject"
              class="btn" style="background:#c62828;color:#fff;padding:10px 18px;font-size:13px;border-radius:8px;cursor:pointer;border:none;align-self:flex-end"
              onclick="return confirm('Reject this cancellation request?')">
              ❌ Reject
            </button>
          </form>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </main>
</div>
</body>
</html>
