<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();

// Stats
$stats = [];
$stats['total_events']    = $conn->query("SELECT COUNT(*) FROM events WHERE status='active'")->fetch_row()[0];
$stats['total_bookings']  = $conn->query("SELECT COUNT(*) FROM confirmed_bookings")->fetch_row()[0];
$stats['total_revenue']   = $conn->query("SELECT COALESCE(SUM(total_amount),0) FROM confirmed_bookings WHERE status='PAID'")->fetch_row()[0];
$stats['pending_bookings']= $conn->query("SELECT COUNT(*) FROM pending_bookings WHERE status IN ('RESERVED','PAYMENT_INITIATED')")->fetch_row()[0];
$stats['pending_cancels'] = $conn->query("SELECT COUNT(*) FROM cancellation_requests WHERE status='pending'")->fetch_row()[0];
$stats['open_tickets']    = $conn->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetch_row()[0];

// Recent bookings
$recentBookings = [];
$result = $conn->query(
    "SELECT cb.booking_id, cb.user_name, cb.user_email, cb.ticket_count, cb.total_amount,
            cb.confirmed_at, e.name AS event_name
     FROM confirmed_bookings cb
     JOIN events e ON cb.event_id = e.id
     ORDER BY cb.confirmed_at DESC LIMIT 10"
);
while ($row = $result->fetch_assoc()) {
    $recentBookings[] = $row;
}

// Revenue by event
$revenueByEvent = [];
$result = $conn->query(
    "SELECT e.name, COUNT(cb.id) AS bookings, SUM(cb.total_amount) AS revenue
     FROM confirmed_bookings cb
     JOIN events e ON cb.event_id = e.id
     GROUP BY e.id ORDER BY revenue DESC LIMIT 5"
);
while ($row = $result->fetch_assoc()) {
    $revenueByEvent[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .admin-layout { display:flex; min-height:100vh; }
    .sidebar { width:240px; background:#003087; color:#fff; padding:0; flex-shrink:0; position:sticky; top:0; height:100vh; overflow-y:auto; display:flex; flex-direction:column; }
    .sidebar-brand { padding:16px 20px; border-bottom:1px solid rgba(255,255,255,0.15); background:#002060; }
    .sidebar-brand img { height:36px; filter:brightness(0) invert(1); display:block; margin-bottom:8px; }
    .sidebar-brand .app-title { font-size:16px; font-weight:800; color:#FFD700; }
    .sidebar-brand .college-name { font-size:9px; color:rgba(255,255,255,0.6); line-height:1.4; margin-top:3px; }
    .sidebar a { display:flex; align-items:center; gap:10px; padding:12px 20px; color:rgba(255,255,255,0.8); text-decoration:none; font-size:14px; transition:all .2s; border-left:3px solid transparent; }
    .sidebar a:hover, .sidebar a.active { background:rgba(255,215,0,0.15); color:#FFD700; border-left-color:#FFD700; }
    .sidebar-footer { margin-top:auto; padding:16px 20px; border-top:1px solid rgba(255,255,255,0.1); font-size:11px; color:rgba(255,255,255,0.5); }
    .main-content { flex:1; padding:24px; overflow-x:auto; background:#f4f6fb; }
    .page-title { font-size:22px; font-weight:700; margin-bottom:24px; color:#003087; }
    .stats-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:16px; margin-bottom:28px; }
    .stat-card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.08); border-top:3px solid #003087; }
    .stat-card .label { font-size:12px; color:#888; text-transform:uppercase; letter-spacing:1px; margin-bottom:8px; }
    .stat-card .value { font-size:28px; font-weight:800; color:#003087; }
    .stat-card .sub   { font-size:12px; color:#888; margin-top:4px; }
    .card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.06); margin-bottom:24px; }
    .card-title { font-size:16px; font-weight:700; margin-bottom:16px; color:#003087; }
    table { width:100%; border-collapse:collapse; font-size:13px; }
    th { text-align:left; padding:10px 12px; background:#e6edf8; color:#003087; font-weight:600; text-transform:uppercase; font-size:11px; letter-spacing:.5px; }
    td { padding:10px 12px; border-bottom:1px solid #f0f0f0; }
    tr:last-child td { border-bottom:none; }
    tr:hover td { background:#fafbff; }
  </style>
</head>
<body>
<div class="admin-layout">
  <!-- Sidebar -->
  <aside class="sidebar" role="navigation" aria-label="Admin navigation">
    <div class="sidebar-brand">
      <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <div class="app-title">🎟 VelTech EventPass</div>
      <div class="college-name">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology</div>
    </div>
    <a href="dashboard.php" class="active">📊 Dashboard</a>
    <a href="events.php">🎉 Events</a>
    <a href="bookings.php">🎟 Bookings</a>
    <a href="checkin.php">📷 Check-in</a>
    <a href="cancellations.php">❌ Cancellations</a>
    <a href="support-tickets.php">💬 Support</a>
    <a href="reports.php">📈 Reports</a>
    <a href="users.php">👤 Registered Users</a>
    <a href="logout.php" style="color:#ff6b6b;margin-top:auto">🚪 Logout</a>
    <div class="sidebar-footer">👤 <?= htmlspecialchars($adminUser) ?><br>Admin Panel</div>
  </aside>

  <!-- Main -->
  <main class="main-content">
    <h1 class="page-title">Dashboard</h1>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="label">Active Events</div>
        <div class="value"><?= $stats['total_events'] ?></div>
      </div>
      <div class="stat-card">
        <div class="label">Total Bookings</div>
        <div class="value"><?= $stats['total_bookings'] ?></div>
      </div>
      <div class="stat-card">
        <div class="label">Total Revenue</div>
        <div class="value">₹<?= number_format($stats['total_revenue'], 0) ?></div>
      </div>
      <div class="stat-card">
        <div class="label">Pending Payments</div>
        <div class="value" style="color:#ff9800"><?= $stats['pending_bookings'] ?></div>
        <div class="sub">Reserved, awaiting payment</div>
      </div>
      <div class="stat-card">
        <div class="label">Cancellation Requests</div>
        <div class="value" style="color:#c62828"><?= $stats['pending_cancels'] ?></div>
        <div class="sub"><a href="cancellations.php" style="color:#c62828">View →</a></div>
      </div>
      <div class="stat-card">
        <div class="label">Open Support Tickets</div>
        <div class="value" style="color:#1565c0"><?= $stats['open_tickets'] ?></div>
        <div class="sub"><a href="support-tickets.php" style="color:#1565c0">View →</a></div>
      </div>
    </div>

    <!-- Revenue by Event -->
    <div class="card">
      <div class="card-title">Revenue by Event</div>
      <table>
        <thead>
          <tr><th>Event</th><th>Bookings</th><th>Revenue</th></tr>
        </thead>
        <tbody>
          <?php foreach ($revenueByEvent as $r): ?>
          <tr>
            <td><?= htmlspecialchars($r['name']) ?></td>
            <td><?= $r['bookings'] ?></td>
            <td>₹<?= number_format($r['revenue'], 2) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($revenueByEvent)): ?>
          <tr><td colspan="3" style="text-align:center;color:#888;padding:20px">No bookings yet</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Recent Bookings -->
    <div class="card">
      <div class="card-title">Recent Bookings</div>
      <table>
        <thead>
          <tr><th>Booking ID</th><th>Name</th><th>Event</th><th>Tickets</th><th>Amount</th><th>Date</th></tr>
        </thead>
        <tbody>
          <?php foreach ($recentBookings as $b): ?>
          <tr>
            <td><code style="font-size:11px"><?= htmlspecialchars($b['booking_id']) ?></code></td>
            <td><?= htmlspecialchars($b['user_name']) ?></td>
            <td><?= htmlspecialchars($b['event_name']) ?></td>
            <td><?= $b['ticket_count'] ?></td>
            <td>₹<?= number_format($b['total_amount'], 2) ?></td>
            <td><?= date('d M, h:i A', strtotime($b['confirmed_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($recentBookings)): ?>
          <tr><td colspan="6" style="text-align:center;color:#888;padding:20px">No bookings yet</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
      <div style="margin-top:12px">
        <a href="bookings.php" class="btn btn-outline" style="font-size:13px;padding:8px 16px;text-decoration:none">
          View All Bookings →
        </a>
      </div>
    </div>
  </main>
</div>
</body>
</html>
