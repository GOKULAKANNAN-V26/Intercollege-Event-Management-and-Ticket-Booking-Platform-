<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/QRService.php';

$conn = getDBConnection();

// Get events for dropdown
$events = [];
$res = $conn->query("SELECT id, name, event_date FROM events WHERE status='active' ORDER BY event_date ASC");
while ($row = $res->fetch_assoc()) $events[] = $row;

$result  = null;
$message = '';
$msgType = '';

// Handle manual booking ID check-in
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingId = preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($_POST['booking_id'] ?? '')));
    $eventId   = (int)($_POST['event_id'] ?? 0);

    if (empty($bookingId) || $eventId < 1) {
        $message = 'Please enter a Booking ID and select an event.';
        $msgType = 'danger';
    } else {
        $result  = QRService::checkIn($bookingId, $eventId);
        $message = $result['message'];
        $msgType = $result['success'] ? 'success' : (($result['duplicate'] ?? false) ? 'warning' : 'danger');
    }
}

// Handle AJAX QR scan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ajax'])) {
    header('Content-Type: application/json');
    $bookingId = preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($_POST['booking_id'] ?? '')));
    $eventId   = (int)($_POST['event_id'] ?? 0);
    echo json_encode(QRService::checkIn($bookingId, $eventId));
    exit;
}

// Stats for selected event
$selectedEvent = (int)($_GET['event_id'] ?? ($events[0]['id'] ?? 0));
$stats = ['total' => 0, 'checked_in' => 0, 'pending' => 0];
if ($selectedEvent) {
    $r = $conn->query("SELECT COUNT(*) FROM confirmed_bookings WHERE event_id=$selectedEvent AND status IN ('PAID','CONFIRMED')");
    $stats['total'] = $r->fetch_row()[0];
    $r = $conn->query("SELECT COUNT(*) FROM confirmed_bookings WHERE event_id=$selectedEvent AND checked_in=1");
    $stats['checked_in'] = $r->fetch_row()[0];
    $stats['pending'] = $stats['total'] - $stats['checked_in'];
}

// Recent check-ins
$recentCheckins = [];
if ($selectedEvent) {
    $stmt = $conn->prepare(
        "SELECT booking_id, user_name, ticket_count, checked_in_at
         FROM confirmed_bookings
         WHERE event_id = ? AND checked_in = 1
         ORDER BY checked_in_at DESC LIMIT 20"
    );
    $stmt->bind_param('i', $selectedEvent);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $recentCheckins[] = $row;
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Check-in Scanner – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <!-- QR Code Scanner Library -->
  <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
  <style>
    .admin-layout{display:flex;min-height:100vh}
    .sidebar{width:240px;background:#003087;color:#fff;padding:0;flex-shrink:0;display:flex;flex-direction:column}
    .sidebar-brand{padding:16px 20px;border-bottom:1px solid rgba(255,255,255,.15);background:#002060}
    .sidebar-brand img{height:36px;filter:brightness(0) invert(1);display:block;margin-bottom:8px}
    .sidebar-brand .app-title{font-size:15px;font-weight:800;color:#FFD700}
    .sidebar-brand .college-name{font-size:9px;color:rgba(255,255,255,.6);line-height:1.4;margin-top:3px}
    .sidebar a{display:flex;align-items:center;gap:10px;padding:12px 20px;color:rgba(255,255,255,.8);text-decoration:none;font-size:14px;border-left:3px solid transparent;transition:all .2s}
    .sidebar a:hover,.sidebar a.active{background:rgba(255,215,0,.15);color:#FFD700;border-left-color:#FFD700}
    .main-content{flex:1;padding:24px;overflow-x:auto;background:#f4f6fb}
    .page-title{font-size:22px;font-weight:700;margin-bottom:20px;color:#003087}
    .grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px}
    .card{background:#fff;border-radius:12px;padding:20px;box-shadow:0 2px 12px rgba(0,48,135,.06);margin-bottom:20px}
    .card-title{font-size:15px;font-weight:700;color:#003087;margin-bottom:14px}
    .stat-row{display:flex;gap:12px;margin-bottom:20px}
    .stat{flex:1;background:#fff;border-radius:10px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(0,48,135,.06)}
    .stat .val{font-size:28px;font-weight:800}
    .stat .lbl{font-size:11px;color:#888;text-transform:uppercase;letter-spacing:.5px;margin-top:3px}
    .scan-box{border:3px dashed #003087;border-radius:12px;padding:30px;text-align:center;background:#f4f6fb;margin-bottom:16px}
    .scan-icon{font-size:48px;margin-bottom:10px}
    table{width:100%;border-collapse:collapse;font-size:13px}
    th{text-align:left;padding:9px 12px;background:#e6edf8;color:#003087;font-weight:600;font-size:11px;text-transform:uppercase}
    td{padding:9px 12px;border-bottom:1px solid #f0f0f0}
    .checkin-result{border-radius:10px;padding:16px;margin-bottom:16px;text-align:center}
    .checkin-result.ok{background:#e8f5e9;border:2px solid #4caf50}
    .checkin-result.err{background:#fce4ec;border:2px solid #f44336}
    .checkin-result.warn{background:#fff3e0;border:2px solid #ff9800}
    @media(max-width:700px){.grid2{grid-template-columns:1fr}}
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <div class="app-title">🎟 VelTech EventPass</div>
      <div class="college-name">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute</div>
    </div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="events.php">🎉 Events</a>
    <a href="bookings.php">🎟 Bookings</a>
    <a href="checkin.php" class="active">📷 Check-in</a>
    <a href="cancellations.php">❌ Cancellations</a>
    <a href="support-tickets.php">💬 Support</a>
    <a href="reports.php">📈 Reports</a>
    <a href="logout.php" style="color:#ff6b6b;margin-top:auto">🚪 Logout</a>
  </aside>

  <main class="main-content">
    <h1 class="page-title">📷 Event Check-in</h1>

    <!-- Event selector -->
    <div class="card">
      <form method="GET" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
        <div class="form-group" style="flex:1;min-width:200px;margin:0">
          <label class="form-label">Select Event</label>
          <select name="event_id" class="form-control" onchange="this.form.submit()">
            <?php foreach ($events as $ev): ?>
            <option value="<?= $ev['id'] ?>" <?= $selectedEvent==$ev['id']?'selected':'' ?>>
              <?= htmlspecialchars($ev['name']) ?> — <?= date('d M Y', strtotime($ev['event_date'])) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
      </form>
    </div>

    <!-- Stats -->
    <div class="stat-row">
      <div class="stat">
        <div class="val" style="color:#003087"><?= $stats['total'] ?></div>
        <div class="lbl">Total Bookings</div>
      </div>
      <div class="stat">
        <div class="val" style="color:#4caf50"><?= $stats['checked_in'] ?></div>
        <div class="lbl">Checked In</div>
      </div>
      <div class="stat">
        <div class="val" style="color:#ff9800"><?= $stats['pending'] ?></div>
        <div class="lbl">Not Yet In</div>
      </div>
      <?php if ($stats['total'] > 0): ?>
      <div class="stat">
        <div class="val" style="color:#003087"><?= round($stats['checked_in']/$stats['total']*100) ?>%</div>
        <div class="lbl">Attendance</div>
      </div>
      <?php endif; ?>
    </div>

    <div class="grid2">
      <!-- QR Code Scanner -->
      <div class="card">
        <div class="card-title">📷 QR Code Scanner</div>
        
        <div id="qr-reader" style="width:100%;margin-bottom:16px"></div>
        
        <div style="display:flex;gap:8px;margin-bottom:16px">
          <button id="btnStartScan" class="btn btn-primary" style="flex:1">
            📷 Start Camera
          </button>
          <button id="btnStopScan" class="btn btn-outline" style="flex:1;display:none">
            ⏹ Stop Camera
          </button>
        </div>
        
        <div id="scanResult" style="display:none" class="checkin-result">
          <div id="scanIcon" style="font-size:28px;margin-bottom:6px"></div>
          <strong id="scanMessage"></strong>
          <div id="scanDetails" style="margin-top:10px;font-size:13px;color:#555"></div>
        </div>
        
        <div style="background:#f8f9ff;border-radius:8px;padding:12px;font-size:12px;color:#666">
          <strong>How to use:</strong><br>
          1. Click "Start Camera" button<br>
          2. Allow camera access when prompted<br>
          3. Point camera at QR code on ticket<br>
          4. System will auto-check-in when scanned
        </div>
      </div>

      <!-- Manual Check-in -->
      <div class="card">
        <div class="card-title">🔍 Manual Check-in</div>

        <?php if ($message): ?>
        <div class="checkin-result <?= $msgType==='success'?'ok':($msgType==='warning'?'warn':'err') ?>">
          <div style="font-size:28px;margin-bottom:6px">
            <?= $msgType==='success'?'✅':($msgType==='warning'?'⚠️':'❌') ?>
          </div>
          <strong><?= htmlspecialchars($message) ?></strong>
          <?php if ($result && !empty($result['booking'])): $b=$result['booking']; ?>
          <div style="margin-top:10px;font-size:13px;color:#555">
            <div><strong><?= htmlspecialchars($b['user_name']) ?></strong></div>
            <div><?= htmlspecialchars($b['user_email']) ?></div>
            <div><?= $b['ticket_count'] ?> ticket(s)</div>
          </div>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <form method="POST">
          <input type="hidden" name="event_id" value="<?= $selectedEvent ?>">
          <div class="form-group">
            <label class="form-label">Booking ID</label>
            <input type="text" name="booking_id" class="form-control"
              placeholder="Scan QR or type Booking ID"
              style="text-transform:uppercase;font-family:monospace;font-size:15px"
              autofocus autocomplete="off" id="bookingInput">
          </div>
          <button type="submit" class="btn btn-primary btn-full" style="font-size:15px;padding:12px">
            ✅ Check In
          </button>
        </form>

        <div class="scan-box" style="margin-top:16px">
          <div class="scan-icon">📱</div>
          <p style="font-size:13px;color:#666;margin-bottom:8px">
            Use a barcode scanner or phone camera to scan the QR code on the ticket.
            The scanner will auto-fill the Booking ID above.
          </p>
          <p style="font-size:12px;color:#aaa">
            Most USB barcode scanners work as keyboard input — just scan and it submits automatically.
          </p>
        </div>
      </div>

      <!-- Recent Check-ins -->
      <div class="card">
        <div class="card-title">🕐 Recent Check-ins</div>
        <?php if (empty($recentCheckins)): ?>
        <p style="color:#888;text-align:center;padding:20px">No check-ins yet for this event.</p>
        <?php else: ?>
        <table>
          <thead>
            <tr><th>Booking ID</th><th>Name</th><th>Tickets</th><th>Time</th></tr>
          </thead>
          <tbody>
            <?php foreach ($recentCheckins as $c): ?>
            <tr>
              <td><code style="font-size:11px"><?= htmlspecialchars($c['booking_id']) ?></code></td>
              <td><?= htmlspecialchars($c['user_name']) ?></td>
              <td><?= $c['ticket_count'] ?></td>
              <td><?= date('h:i A', strtotime($c['checked_in_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php endif; ?>
      </div>
    </div>
  </main>
</div>

<script>
// QR Code Scanner
let html5QrcodeScanner = null;
const selectedEventId = <?= $selectedEvent ?>;

document.getElementById('btnStartScan').addEventListener('click', function() {
  this.style.display = 'none';
  document.getElementById('btnStopScan').style.display = 'block';
  document.getElementById('scanResult').style.display = 'none';
  
  html5QrcodeScanner = new Html5Qrcode("qr-reader");
  
  html5QrcodeScanner.start(
    { facingMode: "environment" },
    {
      fps: 10,
      qrbox: { width: 250, height: 250 }
    },
    (decodedText, decodedResult) => {
      // QR code scanned successfully
      console.log(`QR Code detected: ${decodedText}`);
      
      // Extract booking ID from QR code (format: CB20260506XXXX or full URL)
      let bookingId = decodedText;
      if (decodedText.includes('/')) {
        // Extract from URL
        const match = decodedText.match(/[?&]id=([A-Z0-9]+)/i);
        if (match) bookingId = match[1];
      }
      
      // Clean booking ID
      bookingId = bookingId.replace(/[^A-Z0-9]/gi, '').toUpperCase();
      
      if (bookingId) {
        // Stop scanner
        html5QrcodeScanner.stop().then(() => {
          document.getElementById('btnStartScan').style.display = 'block';
          document.getElementById('btnStopScan').style.display = 'none';
        });
        
        // Perform check-in via AJAX
        performCheckIn(bookingId);
      }
    },
    (errorMessage) => {
      // QR code parse error, ignore
    }
  ).catch((err) => {
    console.error('Camera start error:', err);
    alert('Failed to start camera. Please check permissions.');
    document.getElementById('btnStartScan').style.display = 'block';
    document.getElementById('btnStopScan').style.display = 'none';
  });
});

document.getElementById('btnStopScan').addEventListener('click', function() {
  if (html5QrcodeScanner) {
    html5QrcodeScanner.stop().then(() => {
      document.getElementById('btnStartScan').style.display = 'block';
      this.style.display = 'none';
    });
  }
});

function performCheckIn(bookingId) {
  // Show loading
  const resultDiv = document.getElementById('scanResult');
  resultDiv.style.display = 'block';
  resultDiv.className = 'checkin-result';
  document.getElementById('scanIcon').textContent = '⏳';
  document.getElementById('scanMessage').textContent = 'Processing...';
  document.getElementById('scanDetails').innerHTML = '';
  
  // Send AJAX request
  fetch('checkin.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `ajax=1&booking_id=${encodeURIComponent(bookingId)}&event_id=${selectedEventId}`
  })
  .then(response => response.json())
  .then(data => {
    // Show result
    if (data.success) {
      resultDiv.className = 'checkin-result ok';
      document.getElementById('scanIcon').textContent = '✅';
      document.getElementById('scanMessage').textContent = data.message;
      
      if (data.booking) {
        document.getElementById('scanDetails').innerHTML = `
          <div><strong>${escapeHtml(data.booking.user_name)}</strong></div>
          <div>${escapeHtml(data.booking.user_email)}</div>
          <div>${data.booking.ticket_count} ticket(s)</div>
        `;
      }
      
      // Play success sound (optional)
      playSound('success');
      
      // Reload page after 2 seconds to update stats
      setTimeout(() => location.reload(), 2000);
    } else if (data.duplicate) {
      resultDiv.className = 'checkin-result warn';
      document.getElementById('scanIcon').textContent = '⚠️';
      document.getElementById('scanMessage').textContent = data.message;
      
      if (data.booking) {
        document.getElementById('scanDetails').innerHTML = `
          <div><strong>${escapeHtml(data.booking.user_name)}</strong></div>
          <div>Already checked in at ${data.booking.checked_in_at}</div>
        `;
      }
    } else {
      resultDiv.className = 'checkin-result err';
      document.getElementById('scanIcon').textContent = '❌';
      document.getElementById('scanMessage').textContent = data.message;
      document.getElementById('scanDetails').innerHTML = '';
    }
  })
  .catch(error => {
    console.error('Check-in error:', error);
    resultDiv.className = 'checkin-result err';
    document.getElementById('scanIcon').textContent = '❌';
    document.getElementById('scanMessage').textContent = 'Network error. Please try again.';
    document.getElementById('scanDetails').innerHTML = '';
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function playSound(type) {
  // Optional: Add sound effects
  // const audio = new Audio(type === 'success' ? '/sounds/success.mp3' : '/sounds/error.mp3');
  // audio.play().catch(() => {});
}

// Auto-submit when barcode scanner inputs booking ID (ends with Enter)
document.getElementById('bookingInput').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') {
    e.preventDefault();
    this.closest('form').submit();
  }
});
</script>
</body>
</html>
