<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();

// Revenue by day (last 30 days)
$dailyRevenue = [];
$result = $conn->query(
    "SELECT DATE(confirmed_at) AS day, COUNT(*) AS bookings, SUM(total_amount) AS revenue
     FROM confirmed_bookings
     WHERE confirmed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY DATE(confirmed_at)
     ORDER BY day ASC"
);
while ($row = $result->fetch_assoc()) {
    $dailyRevenue[] = $row;
}

// Revenue by event
$eventRevenue = [];
$result = $conn->query(
    "SELECT e.name, e.department, COUNT(cb.id) AS bookings,
            SUM(cb.ticket_count) AS tickets_sold, SUM(cb.total_amount) AS revenue
     FROM confirmed_bookings cb
     JOIN events e ON cb.event_id = e.id
     GROUP BY e.id ORDER BY revenue DESC"
);
while ($row = $result->fetch_assoc()) {
    $eventRevenue[] = $row;
}

// Summary
$summary = $conn->query(
    "SELECT COUNT(*) AS total_bookings, SUM(total_amount) AS total_revenue,
            SUM(ticket_count) AS total_tickets
     FROM confirmed_bookings"
)->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reports – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <style>
    .admin-layout { display:flex; min-height:100vh; }
    .sidebar { width:240px; background:#003087; color:#fff; padding:0; flex-shrink:0; display:flex; flex-direction:column; }
    .sidebar-brand { padding:16px 20px; border-bottom:1px solid rgba(255,255,255,0.15); background:#002060; }
    .sidebar-brand img { height:36px; filter:brightness(0) invert(1); display:block; margin-bottom:8px; }
    .sidebar-brand .app-title { font-size:15px; font-weight:800; color:#FFD700; }
    .sidebar-brand .college-name { font-size:9px; color:rgba(255,255,255,0.6); line-height:1.4; margin-top:3px; }
    .sidebar a { display:flex; align-items:center; gap:10px; padding:12px 20px; color:rgba(255,255,255,0.8); text-decoration:none; font-size:14px; border-left:3px solid transparent; transition:all .2s; }
    .sidebar a:hover, .sidebar a.active { background:rgba(255,215,0,0.15); color:#FFD700; border-left-color:#FFD700; }
    .main-content { flex:1; padding:24px; overflow-x:auto; background:#f4f6fb; }
    .page-title { font-size:22px; font-weight:700; margin-bottom:24px; color:#003087; }
    .stats-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(180px,1fr)); gap:16px; margin-bottom:28px; }
    .stat-card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.08); border-top:3px solid #003087; }
    .stat-card .label { font-size:12px; color:#888; text-transform:uppercase; letter-spacing:1px; margin-bottom:8px; }
    .stat-card .value { font-size:26px; font-weight:800; color:#003087; }
    .card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.06); margin-bottom:24px; }
    .card-title { font-size:16px; font-weight:700; margin-bottom:16px; color:#003087; }
    table { width:100%; border-collapse:collapse; font-size:13px; }
    th { text-align:left; padding:10px 12px; background:#e6edf8; color:#003087; font-weight:600; text-transform:uppercase; font-size:11px; }
    td { padding:10px 12px; border-bottom:1px solid #f0f0f0; }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <div class="app-title">🎟 VelTech EventPass</div>
      <div class="college-name">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology</div>
    </div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="events.php">🎉 Events</a>
    <a href="bookings.php">🎟 Bookings</a>
    <a href="reports.php" class="active">📈 Reports</a>
    <a href="users.php">👤 Registered Users</a>
    <a href="logout.php" style="color:#ff6b6b;margin-top:auto">🚪 Logout</a>
  </aside>

  <main class="main-content">
    <h1 class="page-title">Revenue Reports</h1>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="label">Total Revenue</div>
        <div class="value">₹<?= number_format($summary['total_revenue'] ?? 0, 0) ?></div>
      </div>
      <div class="stat-card">
        <div class="label">Total Bookings</div>
        <div class="value"><?= $summary['total_bookings'] ?? 0 ?></div>
      </div>
      <div class="stat-card">
        <div class="label">Tickets Sold</div>
        <div class="value"><?= $summary['total_tickets'] ?? 0 ?></div>
      </div>
    </div>

    <!-- Chart -->
    <div class="card">
      <div class="card-title">Daily Revenue (Last 30 Days)</div>
      <canvas id="revenueChart" height="80"></canvas>
    </div>

    <!-- Event Revenue Table -->
    <div class="card">
      <div class="card-title">Revenue by Event</div>
      <table>
        <thead>
          <tr><th>Event</th><th>Department</th><th>Bookings</th><th>Tickets Sold</th><th>Revenue</th></tr>
        </thead>
        <tbody>
          <?php foreach ($eventRevenue as $r): ?>
          <tr>
            <td><?= htmlspecialchars($r['name']) ?></td>
            <td><?= htmlspecialchars($r['department']) ?></td>
            <td><?= $r['bookings'] ?></td>
            <td><?= $r['tickets_sold'] ?></td>
            <td>₹<?= number_format($r['revenue'], 2) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($eventRevenue)): ?>
          <tr><td colspan="5" style="text-align:center;padding:30px;color:#888">No data yet</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<script>
const labels  = <?= json_encode(array_column($dailyRevenue, 'day')) ?>;
const revenue = <?= json_encode(array_map(fn($r) => (float)$r['revenue'], $dailyRevenue)) ?>;

new Chart(document.getElementById('revenueChart'), {
  type: 'bar',
  data: {
    labels,
    datasets: [{
      label: 'Revenue (₹)',
      data: revenue,
      backgroundColor: 'rgba(0,48,135,0.7)',
      borderColor: '#003087',
      borderWidth: 1,
      borderRadius: 4,
    }]
  },
  options: {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
      y: { beginAtZero: true, ticks: { callback: v => '₹' + v.toLocaleString('en-IN') } }
    }
  }
});
</script>
</body>
</html>
