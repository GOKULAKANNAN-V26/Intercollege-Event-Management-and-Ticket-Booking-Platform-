<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();

// Filters
$search   = trim($_GET['search'] ?? '');
$eventId  = (int)($_GET['event_id'] ?? 0);
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 20;
$offset   = ($page - 1) * $perPage;

$where  = ['1=1'];
$params = [];
$types  = '';

if ($search !== '') {
    $where[] = "(cb.booking_id LIKE ? OR cb.user_name LIKE ? OR cb.user_email LIKE ?)";
    $s = '%' . $search . '%';
    $params = array_merge($params, [$s, $s, $s]);
    $types .= 'sss';
}
if ($eventId > 0) {
    $where[] = "cb.event_id = ?";
    $params[] = $eventId;
    $types .= 'i';
}

$whereClause = implode(' AND ', $where);

// Count
$countStmt = $conn->prepare("SELECT COUNT(*) FROM confirmed_bookings cb WHERE $whereClause");
if (!empty($params)) $countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalRows = $countStmt->get_result()->fetch_row()[0];
$countStmt->close();
$totalPages = ceil($totalRows / $perPage);

// Fetch
$bookings = [];
$stmt = $conn->prepare(
    "SELECT cb.*, e.name AS event_name
     FROM confirmed_bookings cb
     JOIN events e ON cb.event_id = e.id
     WHERE $whereClause
     ORDER BY cb.confirmed_at DESC
     LIMIT ? OFFSET ?"
);
$allParams = array_merge($params, [$perPage, $offset]);
$allTypes  = $types . 'ii';
$stmt->bind_param($allTypes, ...$allParams);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}
$stmt->close();

// Events for filter
$events = [];
$evResult = $conn->query("SELECT id, name FROM events ORDER BY name");
while ($row = $evResult->fetch_assoc()) {
    $events[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bookings – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .admin-layout { display:flex; min-height:100vh; }
    .sidebar { width:240px; background:#003087; color:#fff; padding:0; flex-shrink:0; display:flex; flex-direction:column; }
    .sidebar-brand { padding:16px 20px; border-bottom:1px solid rgba(255,255,255,0.15); background:#002060; }
    .sidebar-brand img { height:36px; filter:brightness(0) invert(1); display:block; margin-bottom:8px; }
    .sidebar-brand .app-title { font-size:15px; font-weight:800; color:#FFD700; }
    .sidebar-brand .college-name { font-size:9px; color:rgba(255,255,255,0.6); line-height:1.4; margin-top:3px; }
    .sidebar a { display:flex; align-items:center; gap:10px; padding:12px 20px; color:rgba(255,255,255,0.8); text-decoration:none; font-size:14px; border-left:3px solid transparent; transition:all .2s; }
    .sidebar a:hover, .sidebar a.active { background:rgba(255,215,0,0.15); color:#FFD700; border-left-color:#FFD700; }
    .main-content { flex:1; padding:24px; overflow-x:auto; background:#f4f6fb; }
    .page-title { font-size:22px; font-weight:700; margin-bottom:20px; color:#003087; }
    .filters { display:flex; gap:12px; margin-bottom:20px; flex-wrap:wrap; }
    .card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.06); }
    table { width:100%; border-collapse:collapse; font-size:13px; }
    th { text-align:left; padding:10px 12px; background:#e6edf8; color:#003087; font-weight:600; text-transform:uppercase; font-size:11px; }
    td { padding:10px 12px; border-bottom:1px solid #f0f0f0; }
    .pagination { display:flex; gap:8px; margin-top:16px; align-items:center; }
    .pagination a { padding:6px 12px; border:1px solid #dde3ee; border-radius:6px; text-decoration:none; color:#333; font-size:13px; }
    .pagination a.active { background:#003087; color:#fff; border-color:#003087; }
    .pagination a:hover:not(.active) { background:#e6edf8; }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <div class="app-title">🎟 VelTech EventPass</div>
      <div class="college-name">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology</div>
    </div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="events.php">🎉 Events</a>
    <a href="bookings.php" class="active">🎟 Bookings</a>
    <a href="reports.php">📈 Reports</a>
    <a href="logout.php" style="color:#ff6b6b;margin-top:auto">🚪 Logout</a>
  </aside>

  <main class="main-content">
    <h1 class="page-title">Bookings (<?= $totalRows ?>)</h1>

    <form method="GET" class="filters">
      <input type="text" name="search" class="form-control" placeholder="Search name, email, booking ID..."
        value="<?= htmlspecialchars($search) ?>" style="flex:1;min-width:200px">
      <select name="event_id" class="filter-select">
        <option value="">All Events</option>
        <?php foreach ($events as $ev): ?>
        <option value="<?= $eventId == $ev['id'] ? 'selected' : '' ?>>
          <?= htmlspecialchars($ev['name']) ?>
        </option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-primary">Filter</button>
      <a href="bookings.php" class="btn btn-outline">Reset</a>
      <a href="export_bookings_csv.php?<?= http_build_query(['search' => $search, 'event_id' => $eventId]) ?>" 
         class="btn" style="background:#2e7d32;color:white">
        📥 Export CSV
      </a>
    </form>

    <div class="card">
      <table>
        <thead>
          <tr>
            <th>Booking ID</th><th>Name</th><th>Email</th><th>Event</th>
            <th>Tickets</th><th>Amount</th><th>Payment ID</th><th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($bookings as $b): ?>
          <tr>
            <td><code style="font-size:11px"><?= htmlspecialchars($b['booking_id']) ?></code></td>
            <td><?= htmlspecialchars($b['user_name']) ?></td>
            <td><?= htmlspecialchars($b['user_email']) ?></td>
            <td><?= htmlspecialchars($b['event_name']) ?></td>
            <td><?= $b['ticket_count'] ?></td>
            <td>₹<?= number_format($b['total_amount'], 2) ?></td>
            <td><code style="font-size:10px"><?= htmlspecialchars(substr($b['payment_id'], 0, 20)) ?>...</code></td>
            <td><?= date('d M Y, h:i A', strtotime($b['confirmed_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($bookings)): ?>
          <tr><td colspan="8" style="text-align:center;padding:30px;color:#888">No bookings found</td></tr>
          <?php endif; ?>
        </tbody>
      </table>

      <!-- Pagination -->
      <?php if ($totalPages > 1): ?>
      <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&event_id=<?= $eventId ?>"
           class="<?= $i === $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
    </div>
  </main>
</div>
</body>
</html>
