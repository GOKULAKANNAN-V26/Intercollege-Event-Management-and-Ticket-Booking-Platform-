<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();
$message = '';
$messageType = 'success';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name        = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $department  = trim($_POST['department'] ?? '');
        $venue       = trim($_POST['venue'] ?? '');
        $eventDate   = trim($_POST['event_date'] ?? '');
        $price       = (float)($_POST['ticket_price'] ?? 0);
        $totalTickets= (int)($_POST['total_tickets'] ?? 0);
        $status      = in_array($_POST['status'] ?? '', ['active','inactive','cancelled'])
                       ? $_POST['status'] : 'active';
        $regType     = in_array($_POST['registration_type'] ?? '', ['Individual','Team','Both'])
                       ? $_POST['registration_type'] : 'Individual';
        $minTeam     = !empty($_POST['min_team_members']) ? (int)($_POST['min_team_members']) : NULL;
        $maxTeam     = !empty($_POST['max_team_members']) ? (int)($_POST['max_team_members']) : NULL;

        if (empty($name) || empty($department) || empty($venue) || empty($eventDate)) {
            $message = 'Please fill in all required fields.';
            $messageType = 'danger';
        } else {
            if ($action === 'add') {
                $stmt = $conn->prepare(
                    "INSERT INTO events (name, description, department, venue, event_date, ticket_price, total_tickets, available_tickets, status, registration_type, min_team_members, max_team_members)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                $stmt->bind_param('sssss'. 'd' . 'ii' . 'ss' . 'ii', $name, $description, $department, $venue, $eventDate, $price, $totalTickets, $totalTickets, $status, $regType, $minTeam, $maxTeam);
                $stmt->execute();
                $stmt->close();
                $message = 'Event added successfully!';
            } else {
                $id = (int)($_POST['event_id'] ?? 0);
                $stmt = $conn->prepare(
                    "UPDATE events SET name=?, description=?, department=?, venue=?, event_date=?, ticket_price=?, total_tickets=?, status=?, registration_type=?, min_team_members=?, max_team_members=? WHERE id=?"
                );
                $stmt->bind_param('sssss'. 'd' . 'i' . 'ss' . 'iii', $name, $description, $department, $venue, $eventDate, $price, $totalTickets, $status, $regType, $minTeam, $maxTeam, $id);
                $stmt->execute();
                $stmt->close();
                $message = 'Event updated successfully!';
            }
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['event_id'] ?? 0);
        // Check for bookings
        $check = $conn->prepare("SELECT COUNT(*) FROM confirmed_bookings WHERE event_id = ?");
        $check->bind_param('i', $id);
        $check->execute();
        $count = $check->get_result()->fetch_row()[0];
        $check->close();

        if ($count > 0) {
            $stmt = $conn->prepare("UPDATE events SET status='cancelled' WHERE id=?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
            $message = 'Event cancelled (has existing bookings, cannot delete).';
            $messageType = 'warning';
        } else {
            $stmt = $conn->prepare("DELETE FROM events WHERE id=?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
            $message = 'Event deleted successfully.';
        }
    }
}

// Fetch events
$events = [];
$result = $conn->query(
    "SELECT e.*, 
     (SELECT COUNT(*) FROM confirmed_bookings WHERE event_id = e.id) AS booking_count
     FROM events e ORDER BY event_date DESC"
);
while ($row = $result->fetch_assoc()) {
    $events[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Events – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .admin-layout { display:flex; min-height:100vh; }
    .sidebar { width:240px; background:#003087; color:#fff; padding:0; flex-shrink:0; display:flex; flex-direction:column; }
    .sidebar-brand { padding:16px 20px; border-bottom:1px solid rgba(255,255,255,0.15); background:#002060; }
    .sidebar-brand img { height:36px; filter:brightness(0) invert(1); display:block; margin-bottom:8px; }
    .sidebar-brand .app-title { font-size:15px; font-weight:800; color:#FFD700; }
    .sidebar-brand .college-name { font-size:9px; color:rgba(255,255,255,0.6); line-height:1.4; margin-top:3px; }
    .sidebar a { display:flex; align-items:center; gap:10px; padding:12px 20px; color:rgba(255,255,255,0.8); text-decoration:none; font-size:14px; transition:all .2s; border-left:3px solid transparent; }
    .sidebar a:hover, .sidebar a.active { background:rgba(255,215,0,0.15); color:#FFD700; border-left-color:#FFD700; }
    .main-content { flex:1; padding:24px; overflow-x:auto; background:#f4f6fb; }
    .page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; }
    .page-title { font-size:22px; font-weight:700; color:#003087; }
    .card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.06); margin-bottom:24px; }
    table { width:100%; border-collapse:collapse; font-size:13px; }
    th { text-align:left; padding:10px 12px; background:#e6edf8; color:#003087; font-weight:600; text-transform:uppercase; font-size:11px; }
    td { padding:10px 12px; border-bottom:1px solid #f0f0f0; vertical-align:middle; }
    .badge { padding:3px 10px; border-radius:20px; font-size:11px; font-weight:600; }
    .badge-active   { background:#e8f5e9; color:#2e7d32; }
    .badge-inactive { background:#f5f5f5; color:#9e9e9e; }
    .badge-cancelled{ background:#fce4ec; color:#c62828; }
    .action-btns { display:flex; gap:6px; }
    .btn-sm { padding:5px 12px; font-size:12px; border-radius:6px; }
    .btn-edit   { background:#e3f2fd; color:#1565c0; border:none; cursor:pointer; }
    .btn-delete { background:#fce4ec; color:#c62828; border:none; cursor:pointer; }
    .modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:200; align-items:center; justify-content:center; padding:20px; }
    .modal-overlay.active { display:flex; }
    .modal { background:#fff; border-radius:12px; width:100%; max-width:520px; max-height:90vh; overflow-y:auto; padding:24px; }
    .form-row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <div class="app-title">🎟 VelTech EventPass</div>
      <div class="college-name">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology</div>
    </div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="events.php" class="active">🎉 Events</a>
    <a href="bookings.php">🎟 Bookings</a>
    <a href="reports.php">📈 Reports</a>
    <a href="logout.php" style="color:#ff6b6b;margin-top:auto">🚪 Logout</a>
  </aside>

  <main class="main-content">
    <div class="page-header">
      <h1 class="page-title">Manage Events</h1>
      <button class="btn btn-primary" onclick="openAddModal()">+ Add Event</button>
    </div>

    <?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?>" role="alert"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="card">
      <table>
        <thead>
          <tr>
            <th>Event</th><th>Department</th><th>Date</th>
            <th>Price</th><th>Tickets</th><th>Bookings</th><th>Status</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($events as $ev): ?>
          <tr>
            <td><strong><?= htmlspecialchars($ev['name']) ?></strong><br>
                <small style="color:#888"><?= htmlspecialchars($ev['venue']) ?></small></td>
            <td><?= htmlspecialchars($ev['department']) ?></td>
            <td><?= date('d M Y', strtotime($ev['event_date'])) ?></td>
            <td><?= $ev['ticket_price'] == 0 ? 'FREE' : '₹' . number_format($ev['ticket_price'], 2) ?></td>
            <td><?= $ev['available_tickets'] ?> / <?= $ev['total_tickets'] ?></td>
            <td><?= $ev['booking_count'] ?></td>
            <td><span class="badge badge-<?= $ev['status'] ?>"><?= ucfirst($ev['status']) ?></span></td>
            <td>
              <div class="action-btns">
                <button class="btn btn-sm btn-edit"
                  onclick="openEditModal(<?= htmlspecialchars(json_encode($ev)) ?>)">Edit</button>
                <form method="POST" style="display:inline"
                  onsubmit="return confirm('Delete/cancel this event?')">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="event_id" value="<?= $ev['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-delete">Delete</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($events)): ?>
          <tr><td colspan="8" style="text-align:center;padding:30px;color:#888">No events found</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<!-- Add/Edit Modal -->
<div id="eventModal" class="modal-overlay">
  <div class="modal">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
      <h2 id="modalTitle" style="font-size:18px;font-weight:700">Add Event</h2>
      <button onclick="closeModal()" style="background:none;border:none;font-size:22px;cursor:pointer;color:#888">✕</button>
    </div>
    <form method="POST" id="eventForm">
      <input type="hidden" name="action" id="formAction" value="add">
      <input type="hidden" name="event_id" id="formEventId" value="">

      <div class="form-group">
        <label class="form-label">Event Name *</label>
        <input type="text" name="name" id="fName" class="form-control" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" id="fDesc" class="form-control" rows="3"></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Department *</label>
          <input type="text" name="department" id="fDept" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Venue *</label>
          <input type="text" name="venue" id="fVenue" class="form-control" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Date & Time *</label>
          <input type="datetime-local" name="event_date" id="fDate" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Ticket Price (₹)</label>
          <input type="number" name="ticket_price" id="fPrice" class="form-control" min="0" step="0.01" value="0">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Total Tickets *</label>
          <input type="number" name="total_tickets" id="fTickets" class="form-control" min="1" required>
        </div>
        <div class="form-group">
          <label class="form-label">Registration Type</label>
          <select name="registration_type" id="fRegType" class="form-control">
            <option value="Individual">Individual</option>
            <option value="Team">Team</option>
            <option value="Both">Both</option>
          </select>
        </div>
      </div>
      <div class="form-row" id="teamFieldsRow" style="display:none">
        <div class="form-group">
          <label class="form-label">Min Team Members</label>
          <input type="number" name="min_team_members" id="fMinTeam" class="form-control" min="2">
        </div>
        <div class="form-group">
          <label class="form-label">Max Team Members</label>
          <input type="number" name="max_team_members" id="fMaxTeam" class="form-control" min="2">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" id="fStatus" class="form-control">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>
      <div style="display:flex;gap:12px;margin-top:8px">
        <button type="submit" class="btn btn-primary" style="flex:1">Save Event</button>
        <button type="button" onclick="closeModal()" class="btn btn-outline" style="flex:1">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAddModal() {
  document.getElementById('modalTitle').textContent = 'Add Event';
  document.getElementById('formAction').value = 'add';
  document.getElementById('eventForm').reset();
  document.getElementById('eventModal').classList.add('active');
}

function openEditModal(ev) {
  document.getElementById('modalTitle').textContent = 'Edit Event';
  document.getElementById('formAction').value = 'edit';
  document.getElementById('formEventId').value = ev.id;
  document.getElementById('fName').value    = ev.name;
  document.getElementById('fDesc').value    = ev.description || '';
  document.getElementById('fDept').value    = ev.department;
  document.getElementById('fVenue').value   = ev.venue;
  document.getElementById('fDate').value    = ev.event_date.replace(' ', 'T').slice(0, 16);
  document.getElementById('fPrice').value   = ev.ticket_price;
  document.getElementById('fTickets').value = ev.total_tickets;
  document.getElementById('fStatus').value  = ev.status;
  document.getElementById('eventModal').classList.add('active');
}

function closeModal() {
  document.getElementById('eventModal').classList.remove('active');
}
</script>
</body>
</html>
