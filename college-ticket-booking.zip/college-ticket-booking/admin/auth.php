<?php
/**
 * Admin authentication guard – include at top of every admin page.
 */
require_once __DIR__ . '/../config/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check session
if (empty($_SESSION['admin_id'])) {
    session_write_close();
    header('Location: login.php');
    exit;
}

// Session timeout
if ((time() - ($_SESSION['admin_ts'] ?? 0)) > ADMIN_SESSION_TIMEOUT) {
    session_destroy();
    header('Location: login.php?timeout=1');
    exit;
}

// Refresh timestamp
$_SESSION['admin_ts'] = time();
session_write_close();

$adminUser = $_SESSION['admin_user'] ?? 'Admin';
?>
