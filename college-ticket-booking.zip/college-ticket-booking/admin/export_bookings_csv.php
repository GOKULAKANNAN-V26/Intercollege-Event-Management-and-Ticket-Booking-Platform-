<?php
/**
 * Export Bookings to CSV
 * Exports all bookings (with optional filters) to a CSV file for download
 */
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();

// Get filters from query string
$search = trim($_GET['search'] ?? '');
$eventId = (int)($_GET['event_id'] ?? 0);

$where = ['1=1'];
$params = [];
$types = '';

if ($search !== '') {
    $where[] = "(cb.booking_id LIKE ? OR cb.user_name LIKE ? OR cb.user_email LIKE ?)";
    $s = '%' . $search . '%';
    $params = array_merge($params, [$s, $s, $s]);
    $types .= 'sss';
}
if ($eventId > 0) {
    $where[] = "cb.event_id = ?";
    $params[] = $eventId;
    $types .= 'i';
}

$whereClause = implode(' AND ', $where);

// Fetch all bookings matching filters
$stmt = $conn->prepare(
    "SELECT 
        cb.booking_id,
        cb.user_name,
        cb.user_email,
        cb.user_phone,
        cb.team_name,
        cb.team_members,
        cb.ticket_count,
        cb.total_amount,
        cb.payment_id,
        cb.razorpay_order_id,
        cb.status,
        cb.checked_in,
        cb.checked_in_at,
        cb.confirmed_at,
        e.name AS event_name,
        e.event_date,
        e.venue,
        e.department
     FROM confirmed_bookings cb
     JOIN events e ON cb.event_id = e.id
     WHERE $whereClause
     ORDER BY cb.confirmed_at DESC"
);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

// Set headers for CSV download
$filename = 'bookings_export_' . date('Y-m-d_His') . '.csv';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Create output stream
$output = fopen('php://output', 'w');

// Add BOM for Excel UTF-8 support
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Write CSV headers
fputcsv($output, [
    'Booking ID',
    'Customer Name',
    'Email',
    'Phone',
    'Event Name',
    'Event Date',
    'Venue',
    'Department',
    'Team Name',
    'Team Members',
    'Ticket Count',
    'Total Amount (₹)',
    'Payment ID',
    'Order ID',
    'Status',
    'Checked In',
    'Check-in Time',
    'Booking Date'
]);

// Write data rows
while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['booking_id'],
        $row['user_name'],
        $row['user_email'],
        $row['user_phone'],
        $row['event_name'],
        date('Y-m-d H:i', strtotime($row['event_date'])),
        $row['venue'],
        $row['department'],
        $row['team_name'] ?? '',
        $row['team_members'] ?? '',
        $row['ticket_count'],
        number_format($row['total_amount'], 2),
        $row['payment_id'],
        $row['razorpay_order_id'],
        $row['status'],
        $row['checked_in'] ? 'Yes' : 'No',
        $row['checked_in_at'] ? date('Y-m-d H:i', strtotime($row['checked_in_at'])) : '',
        date('Y-m-d H:i', strtotime($row['confirmed_at']))
    ]);
}

fclose($output);
$stmt->close();
exit;
?>
