<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();

if (isset($_GET['download']) && $_GET['download'] === '1') {
    $filename = 'registered_users_' . date('Ymd_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Name', 'Email', 'Phone', 'Department', 'Roll Number', 'Registered At']);

    $result = $conn->query(
        "SELECT id, name, email, phone, department, roll_number, created_at FROM users ORDER BY created_at DESC"
    );
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['id'], $row['name'], $row['email'], $row['phone'],
            $row['department'], $row['roll_number'], $row['created_at']
        ]);
    }
    fclose($output);
    exit;
}

$totalUsers = $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$users = [];
$result = $conn->query(
    "SELECT id, name, email, phone, department, roll_number, created_at FROM users ORDER BY created_at DESC LIMIT 250"
);
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registered Users – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .admin-layout { display:flex; min-height:100vh; }
    .sidebar { width:240px; background:#003087; color:#fff; padding:0; flex-shrink:0; display:flex; flex-direction:column; }
    .sidebar-brand { padding:16px 20px; border-bottom:1px solid rgba(255,255,255,0.15); background:#002060; }
    .sidebar-brand img { height:36px; filter:brightness(0) invert(1); display:block; margin-bottom:8px; }
    .sidebar-brand .app-title { font-size:15px; font-weight:800; color:#FFD700; }
    .sidebar-brand .college-name { font-size:9px; color:rgba(255,255,255,0.6); line-height:1.4; margin-top:3px; }
    .sidebar a { display:flex; align-items:center; gap:10px; padding:12px 20px; color:rgba(255,255,255,0.8); text-decoration:none; font-size:14px; border-left:3px solid transparent; transition:all .2s; }
    .sidebar a:hover, .sidebar a.active { background:rgba(255,215,0,0.15); color:#FFD700; border-left-color:#FFD700; }
    .main-content { flex:1; padding:24px; overflow-x:auto; background:#f4f6fb; }
    .page-title { font-size:22px; font-weight:700; margin-bottom:20px; color:#003087; }
    .top-row { display:flex; flex-wrap:wrap; justify-content:space-between; gap:14px; align-items:center; margin-bottom:20px; }
    .top-row .summary { color:#555; font-size:14px; }
    .btn { display:inline-flex; align-items:center; justify-content:center; padding:11px 16px; border-radius:10px; border:none; font-size:14px; font-weight:700; text-decoration:none; cursor:pointer; }
    .btn-primary { background:#003087; color:#fff; }
    .card { background:#fff; border-radius:14px; padding:20px; box-shadow:0 2px 18px rgba(0,48,135,0.08); }
    table { width:100%; border-collapse:collapse; font-size:13px; }
    th, td { padding:12px 14px; border-bottom:1px solid #f0f0f0; }
    th { text-align:left; background:#e6edf8; color:#003087; font-weight:700; font-size:12px; text-transform:uppercase; letter-spacing:.5px; }
    tr:hover td { background:#f7faff; }
    .empty-state { text-align:center; padding:40px; color:#777; }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar" role="navigation" aria-label="Admin navigation">
    <div class="sidebar-brand">
      <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <div class="app-title">🎟 VelTech EventPass</div>
      <div class="college-name">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute of Science and Technology</div>
    </div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="events.php">🎉 Events</a>
    <a href="bookings.php">🎟 Bookings</a>
    <a href="cancellations.php">❌ Cancellations</a>
    <a href="checkin.php">📷 Check-in</a>
    <a href="support-tickets.php">💬 Support</a>
    <a href="reports.php">📈 Reports</a>
    <a href="users.php" class="active">👤 Registered Users</a>
    <a href="logout.php" style="color:#ff6b6b;margin-top:auto">🚪 Logout</a>
  </aside>

  <main class="main-content">
    <div class="top-row">
      <div>
        <h1 class="page-title">Registered Users</h1>
        <div class="summary">Total registered users: <strong><?= number_format($totalUsers) ?></strong></div>
      </div>
      <div>
        <a href="users.php?download=1" class="btn btn-primary">Download CSV</a>
      </div>
    </div>

    <div class="card">
      <?php if (empty($users)): ?>
        <div class="empty-state">No registered users found yet.</div>
      <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Department</th>
            <th>Roll Number</th>
            <th>Registered At</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $user): ?>
          <tr>
            <td><?= htmlspecialchars($user['id']) ?></td>
            <td><?= htmlspecialchars($user['name']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= htmlspecialchars($user['phone']) ?></td>
            <td><?= htmlspecialchars($user['department']) ?></td>
            <td><?= htmlspecialchars($user['roll_number']) ?></td>
            <td><?= htmlspecialchars($user['created_at']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </main>
</div>
</body>
</html>
