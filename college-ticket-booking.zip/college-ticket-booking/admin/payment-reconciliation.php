<?php
/**
 * Payment Reconciliation Tool
 * Finds payments that succeeded at Razorpay but failed to create confirmed bookings
 * and attempts to reconcile them.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/BookingService.php';
require_once __DIR__ . '/../includes/Logger.php';
require_once __DIR__ . '/auth.php';

$reconciled = [];
$errors = [];
$action = $_GET['action'] ?? 'view';

if ($action === 'reconcile' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $paymentId = trim($_POST['payment_id'] ?? '');
    
    if ($paymentId) {
        $conn = getDBConnection();
        
        // Get payment details
        $stmt = $conn->prepare(
            "SELECT p.*, pb.booking_ref, pb.user_name, pb.user_email, pb.event_id, pb.ticket_count, pb.total_amount
             FROM payments p
             JOIN pending_bookings pb ON p.booking_ref = pb.booking_ref
             WHERE p.id = ? AND p.status = 'PAID'"
        );
        $stmt->bind_param('i', $paymentId);
        $stmt->execute();
        $payment = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($payment) {
            // Check if booking already exists
            $stmt = $conn->prepare(
                "SELECT booking_id FROM confirmed_bookings WHERE payment_id = ?"
            );
            $stmt->bind_param('s', $payment['razorpay_payment_id']);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if ($existing) {
                $errors[] = "Booking already exists: " . $existing['booking_id'];
            } else {
                // Attempt to confirm booking
                $result = BookingService::confirmBooking(
                    $payment['booking_ref'],
                    $payment['razorpay_payment_id'],
                    $payment['razorpay_order_id']
                );
                
                if ($result['success']) {
                    $reconciled[] = [
                        'booking_id' => $result['booking_id'],
                        'payment_id' => $payment['razorpay_payment_id'],
                        'amount' => $payment['amount'],
                        'email' => $payment['user_email']
                    ];
                    Logger::info('Reconciliation', "Reconciled payment: {$payment['razorpay_payment_id']}");
                } else {
                    $errors[] = "Failed to reconcile: " . ($result['message'] ?? 'Unknown error');
                    Logger::error('Reconciliation', "Failed: {$payment['razorpay_payment_id']}", $result);
                }
            }
        } else {
            $errors[] = "Payment not found or not in PAID status";
        }
    }
}

// Get orphaned payments (PAID but no confirmed booking)
$conn = getDBConnection();
$orphanedPayments = [];

$query = "
    SELECT 
        p.id,
        p.razorpay_order_id,
        p.razorpay_payment_id,
        p.booking_ref,
        p.amount,
        p.status,
        p.created_at,
        pb.user_name,
        pb.user_email,
        pb.user_phone,
        pb.ticket_count,
        e.name AS event_name,
        cb.booking_id AS confirmed_booking_id
    FROM payments p
    JOIN pending_bookings pb ON p.booking_ref = pb.booking_ref
    LEFT JOIN events e ON pb.event_id = e.id
    LEFT JOIN confirmed_bookings cb ON p.razorpay_payment_id = cb.payment_id
    WHERE p.status = 'PAID' 
      AND cb.booking_id IS NULL
    ORDER BY p.created_at DESC
    LIMIT 50
";

$result = $conn->query($query);
while ($row = $result->fetch_assoc()) {
    $orphanedPayments[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Reconciliation - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { background: #f5f5f5; font-family: system-ui; }
        .admin-container { max-width: 1200px; margin: 20px auto; padding: 20px; }
        .admin-header { background: #003087; color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .admin-header h1 { margin: 0; font-size: 24px; }
        .admin-header p { margin: 5px 0 0; opacity: 0.9; font-size: 14px; }
        .card { background: white; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .alert { padding: 12px 16px; border-radius: 6px; margin-bottom: 16px; }
        .alert-success { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
        .alert-error { background: #fce4ec; color: #c62828; border: 1px solid #f48fb1; }
        .alert-warning { background: #fff3e0; color: #e65100; border: 1px solid #ffcc80; }
        .alert-info { background: #e3f2fd; color: #1565c0; border: 1px solid #90caf9; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f5f5f5; font-weight: 600; font-size: 13px; color: #555; }
        td { font-size: 14px; }
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
        .badge-paid { background: #e8f5e9; color: #2e7d32; }
        .badge-orphaned { background: #fff3e0; color: #e65100; }
        .btn { padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600; text-decoration: none; display: inline-block; }
        .btn-primary { background: #003087; color: white; }
        .btn-primary:hover { background: #002060; }
        .btn-danger { background: #c62828; color: white; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 20px; }
        .stat-card { background: white; padding: 16px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .stat-card h3 { margin: 0 0 8px; font-size: 14px; color: #888; }
        .stat-card .value { font-size: 28px; font-weight: 800; color: #003087; }
        .code { font-family: monospace; background: #f5f5f5; padding: 2px 6px; border-radius: 4px; font-size: 12px; }
    </style>
</head>
<body>

<div class="admin-container">
    <div class="admin-header">
        <h1>💰 Payment Reconciliation</h1>
        <p>Find and fix payments that succeeded at Razorpay but failed to create bookings</p>
    </div>

    <?php if (!empty($reconciled)): ?>
        <div class="alert alert-success">
            <strong>✅ Successfully Reconciled!</strong><br>
            <?php foreach ($reconciled as $r): ?>
                Booking ID: <strong><?= htmlspecialchars($r['booking_id']) ?></strong> | 
                Payment: <?= htmlspecialchars($r['payment_id']) ?> | 
                Amount: ₹<?= number_format($r['amount'], 2) ?> | 
                Email: <?= htmlspecialchars($r['email']) ?><br>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <strong>⚠️ Errors:</strong><br>
            <?php foreach ($errors as $error): ?>
                • <?= htmlspecialchars($error) ?><br>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php
    // Calculate stats
    $totalOrphaned = count($orphanedPayments);
    $totalAmount = array_sum(array_column($orphanedPayments, 'amount'));
    ?>

    <div class="stats">
        <div class="stat-card">
            <h3>Orphaned Payments</h3>
            <div class="value"><?= $totalOrphaned ?></div>
        </div>
        <div class="stat-card">
            <h3>Total Amount</h3>
            <div class="value">₹<?= number_format($totalAmount, 2) ?></div>
        </div>
        <div class="stat-card">
            <h3>Status</h3>
            <div class="value" style="font-size: 20px; color: <?= $totalOrphaned > 0 ? '#e65100' : '#2e7d32' ?>">
                <?= $totalOrphaned > 0 ? 'Needs Attention' : 'All Clear' ?>
            </div>
        </div>
    </div>

    <div class="card">
        <h2 style="margin-top: 0;">Orphaned Payments</h2>
        
        <?php if (empty($orphanedPayments)): ?>
            <div class="alert alert-success">
                ✅ No orphaned payments found! All payments have corresponding bookings.
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <strong>⚠️ Found <?= $totalOrphaned ?> orphaned payment(s)</strong><br>
                These payments were marked as PAID but no confirmed booking was created. 
                This usually happens when the booking confirmation process failed after payment succeeded.
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Payment ID</th>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Event</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orphanedPayments as $payment): ?>
                    <tr>
                        <td>
                            <span class="code"><?= htmlspecialchars(substr($payment['razorpay_payment_id'], 0, 20)) ?>...</span>
                            <br>
                            <span class="badge badge-orphaned">ORPHANED</span>
                        </td>
                        <td>
                            <span class="code"><?= htmlspecialchars(substr($payment['razorpay_order_id'], 0, 20)) ?>...</span>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($payment['user_name']) ?></strong><br>
                            <small><?= htmlspecialchars($payment['user_email']) ?></small><br>
                            <small><?= htmlspecialchars($payment['user_phone']) ?></small>
                        </td>
                        <td>
                            <?= htmlspecialchars($payment['event_name']) ?><br>
                            <small><?= $payment['ticket_count'] ?> ticket(s)</small>
                        </td>
                        <td>
                            <strong>₹<?= number_format($payment['amount'], 2) ?></strong>
                        </td>
                        <td>
                            <?= date('d M Y', strtotime($payment['created_at'])) ?><br>
                            <small><?= date('h:i A', strtotime($payment['created_at'])) ?></small>
                        </td>
                        <td>
                            <form method="POST" action="?action=reconcile" style="margin: 0;">
                                <input type="hidden" name="payment_id" value="<?= $payment['id'] ?>">
                                <button type="submit" class="btn btn-primary btn-sm" 
                                        onclick="return confirm('Reconcile this payment and create booking?')">
                                    🔄 Reconcile
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="card">
        <h3>How This Works</h3>
        <p>This tool identifies payments that were successfully captured at Razorpay but failed to create a confirmed booking in the database. This can happen due to:</p>
        <ul>
            <li>Database errors during booking confirmation</li>
            <li>PHP errors or exceptions</li>
            <li>Server timeouts</li>
            <li>Code bugs (like the bind_param issue that was fixed)</li>
        </ul>
        <p><strong>Reconciliation Process:</strong></p>
        <ol>
            <li>Finds payments with status = 'PAID' that don't have a corresponding confirmed_bookings record</li>
            <li>Retrieves the original booking details from pending_bookings</li>
            <li>Attempts to create the confirmed booking using BookingService::confirmBooking()</li>
            <li>Updates all related tables and triggers notifications</li>
        </ol>
        <p><strong>Note:</strong> This is idempotent - running it multiple times won't create duplicate bookings.</p>
    </div>

    <div style="margin-top: 20px;">
        <a href="dashboard.php" class="btn btn-primary">← Back to Dashboard</a>
        <a href="bookings.php" class="btn btn-primary">View All Bookings</a>
    </div>
</div>

</body>
</html>
