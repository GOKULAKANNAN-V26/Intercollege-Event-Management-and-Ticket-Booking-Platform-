<?php
require_once 'auth.php';
require_once __DIR__ . '/../config/database.php';

$conn = getDBConnection();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticketId   = trim($_POST['ticket_id'] ?? '');
    $status     = trim($_POST['status'] ?? '');
    $adminReply = trim($_POST['admin_reply'] ?? '');

    $validStatuses = ['open','in_progress','resolved','closed'];
    if (in_array($status, $validStatuses) && !empty($ticketId)) {
        $stmt = $conn->prepare(
            "UPDATE support_tickets SET status=?, admin_reply=?, updated_at=NOW() WHERE ticket_id=?"
        );
        $stmt->bind_param('sss', $status, $adminReply, $ticketId);
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $message = "✅ Ticket $ticketId updated successfully.";
        } else {
            $message = "⚠ No changes made to ticket $ticketId.";
        }
        $stmt->close();
    } else {
        $message = "⚠ Invalid ticket ID or status.";
    }
}

$filter = $_GET['status'] ?? 'open';
$tickets = [];
$stmt = $conn->prepare(
    "SELECT * FROM support_tickets WHERE status = ? ORDER BY created_at DESC"
);
$stmt->bind_param('s', $filter);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) $tickets[] = $row;
$stmt->close();

$counts = [];
foreach (['open','in_progress','resolved','closed'] as $s) {
    $r = $conn->query("SELECT COUNT(*) FROM support_tickets WHERE status='$s'");
    $counts[$s] = $r->fetch_row()[0];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Support Tickets – VelTech EventPass</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .admin-layout { display:flex; min-height:100vh; }
    .sidebar { width:240px; background:#003087; color:#fff; padding:0; flex-shrink:0; display:flex; flex-direction:column; }
    .sidebar-brand { padding:16px 20px; border-bottom:1px solid rgba(255,255,255,0.15); background:#002060; }
    .sidebar-brand img { height:36px; filter:brightness(0) invert(1); display:block; margin-bottom:8px; }
    .sidebar-brand .app-title { font-size:15px; font-weight:800; color:#FFD700; }
    .sidebar-brand .college-name { font-size:9px; color:rgba(255,255,255,0.6); line-height:1.4; margin-top:3px; }
    .sidebar a { display:flex; align-items:center; gap:10px; padding:12px 20px; color:rgba(255,255,255,0.8); text-decoration:none; font-size:14px; border-left:3px solid transparent; transition:all .2s; }
    .sidebar a:hover, .sidebar a.active { background:rgba(255,215,0,0.15); color:#FFD700; border-left-color:#FFD700; }
    .main-content { flex:1; padding:24px; overflow-x:auto; background:#f4f6fb; }
    .page-title { font-size:22px; font-weight:700; margin-bottom:20px; color:#003087; }
    .tab-bar { display:flex; gap:8px; margin-bottom:20px; flex-wrap:wrap; }
    .tab { padding:8px 18px; border-radius:20px; font-size:13px; font-weight:600; text-decoration:none; background:#fff; color:#666; border:1px solid #dde3ee; }
    .tab.active { background:#003087; color:#fff; border-color:#003087; }
    .tab .cnt { background:#e6edf8; color:#003087; border-radius:10px; padding:1px 7px; font-size:11px; margin-left:4px; }
    .tab.active .cnt { background:rgba(255,255,255,0.25); color:#fff; }
    .card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 2px 12px rgba(0,48,135,0.06); margin-bottom:16px; }
    .ticket-id { font-family:monospace; font-size:13px; font-weight:700; color:#003087; }
    .badge { padding:3px 10px; border-radius:20px; font-size:11px; font-weight:700; }
    .badge-open        { background:#fff3e0; color:#e65100; }
    .badge-in_progress { background:#e3f2fd; color:#1565c0; }
    .badge-resolved    { background:#e8f5e9; color:#2e7d32; }
    .badge-closed      { background:#f5f5f5; color:#9e9e9e; }
    .cat-badge { padding:2px 8px; border-radius:4px; font-size:11px; background:#e6edf8; color:#003087; font-weight:600; }
    .message-box { background:#f4f6fb; border-radius:8px; padding:12px 14px; font-size:13px; color:#444; margin:10px 0; line-height:1.6; }
    .reply-form { background:#e8f5e9; border-radius:8px; padding:14px; margin-top:12px; }
    .reply-form h4 { font-size:13px; font-weight:700; color:#2e7d32; margin-bottom:10px; }
  </style>
</head>
<body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <img src="../assets/images/veltech-logo.svg" alt="Vel Tech Logo">
      <div class="app-title">🎟 VelTech EventPass</div>
      <div class="college-name">Vel Tech Rangarajan Dr. Sagunthala R&amp;D Institute</div>
    </div>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="events.php">🎉 Events</a>
    <a href="bookings.php">🎟 Bookings</a>
    <a href="cancellations.php">❌ Cancellations</a>
    <a href="support-tickets.php" class="active">💬 Support</a>
    <a href="reports.php">📈 Reports</a>
    <a href="logout.php" style="color:#ff6b6b;margin-top:auto">🚪 Logout</a>
  </aside>

  <main class="main-content">
    <h1 class="page-title">💬 Support Tickets</h1>

    <?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="tab-bar">
      <?php foreach (['open'=>'🔴 Open','in_progress'=>'🔵 In Progress','resolved'=>'✅ Resolved','closed'=>'⚫ Closed'] as $s => $label): ?>
      <a href="?status=<?= $s ?>" class="tab <?= $filter===$s?'active':'' ?>">
        <?= $label ?><span class="cnt"><?= $counts[$s] ?></span>
      </a>
      <?php endforeach; ?>
    </div>

    <?php if (empty($tickets)): ?>
    <div style="text-align:center;padding:40px;background:#fff;border-radius:12px;color:#888">
      No <?= $filter ?> tickets found.
    </div>
    <?php endif; ?>

    <?php foreach ($tickets as $t): ?>
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:10px">
        <div>
          <span class="ticket-id"><?= htmlspecialchars($t['ticket_id']) ?></span>
          &nbsp;
          <span class="cat-badge"><?= ucfirst($t['category']) ?></span>
        </div>
        <span class="badge badge-<?= $t['status'] ?>"><?= strtoupper(str_replace('_',' ',$t['status'])) ?></span>
      </div>

      <div style="font-size:15px;font-weight:700;color:#003087;margin-bottom:8px">
        <?= htmlspecialchars($t['subject']) ?>
      </div>

      <div style="font-size:13px;color:#666;display:flex;flex-wrap:wrap;gap:12px;margin-bottom:8px">
        <span>👤 <?= htmlspecialchars($t['user_name']) ?></span>
        <span>📧 <?= htmlspecialchars($t['user_email']) ?></span>
        <?php if ($t['user_phone']): ?><span>📞 <?= htmlspecialchars($t['user_phone']) ?></span><?php endif; ?>
        <?php if ($t['booking_id']): ?><span>🎟 <?= htmlspecialchars($t['booking_id']) ?></span><?php endif; ?>
        <span>🕐 <?= date('d M Y, h:i A', strtotime($t['created_at'])) ?></span>
      </div>

      <div class="message-box"><?= nl2br(htmlspecialchars($t['message'])) ?></div>

      <?php if ($t['admin_reply']): ?>
      <div style="background:#e8f5e9;border-radius:8px;padding:12px 14px;font-size:13px;color:#2e7d32;margin-top:8px">
        <strong>Admin Reply:</strong><br><?= nl2br(htmlspecialchars($t['admin_reply'])) ?>
      </div>
      <?php endif; ?>

      <?php if ($t['status'] !== 'closed'): ?>
      <div class="reply-form">
        <h4>Reply &amp; Update Status</h4>
        <form method="POST">
          <input type="hidden" name="ticket_id" value="<?= $t['ticket_id'] ?>">
          <div class="form-group" style="margin-bottom:10px">
            <textarea name="admin_reply" class="form-control" rows="3"
              placeholder="Type your reply to the user..."
              style="font-size:13px"><?= htmlspecialchars($t['admin_reply'] ?? '') ?></textarea>
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
            <select name="status" class="form-control" style="width:160px;font-size:13px">
              <option value="open"        <?= $t['status']==='open'?'selected':'' ?>>🔴 Open</option>
              <option value="in_progress" <?= $t['status']==='in_progress'?'selected':'' ?>>🔵 In Progress</option>
              <option value="resolved"    <?= $t['status']==='resolved'?'selected':'' ?>>✅ Resolved</option>
              <option value="closed"      <?= $t['status']==='closed'?'selected':'' ?>>⚫ Closed</option>
            </select>
            <button type="submit" class="btn btn-primary" style="font-size:13px;padding:9px 18px">
              💾 Save Reply
            </button>
          </div>
        </form>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </main>
</div>
</body>
</html>
