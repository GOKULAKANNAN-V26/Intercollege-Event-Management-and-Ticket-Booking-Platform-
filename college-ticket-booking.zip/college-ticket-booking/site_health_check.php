<?php
$urls = [
    'http://127.0.0.1:8000/index.php',
    'http://127.0.0.1:8000/login.php',
    'http://127.0.0.1:8000/register.php',
    'http://127.0.0.1:8000/my-bookings.php',
    'http://127.0.0.1:8000/admin/login.php',
    'http://127.0.0.1:8000/api/events.php',
    'http://127.0.0.1:8000/api/send_otp.php',
];

foreach ($urls as $u) {
    $headers = @get_headers($u);
    if ($headers === false) {
        echo "$u -> ERROR\n";
        continue;
    }
    echo "$u -> {$headers[0]}\n";
    if (strpos($u, 'login.php') !== false) {
        $content = @file_get_contents($u);
        if ($content !== false && preg_match('/<title[^>]*>.*Login/i', $content)) {
            echo "  OK: login page title found\n";
        }
    }
}
