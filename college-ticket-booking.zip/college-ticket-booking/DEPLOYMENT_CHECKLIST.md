# 🚀 VelTech EventPass - Deployment Checklist

## ✅ Pre-Deployment Fixes Applied

### 1. **OTP Service Fixed**
- ✅ Fixed incomplete `verifyOTP()` function in `includes/OTPService.php`
- ✅ Added proper error handling and rate limiting
- ✅ Supports MSG91, Firebase, and manual OTP entry

### 2. **Database Schema Fixed**
- ✅ Added `team_name` and `team_members` columns to `confirmed_bookings` table
- ✅ Created migration script for existing databases: `database/migration_add_team_columns.sql`

### 3. **Support Tickets Fixed**
- ✅ Fixed admin support ticket update functionality
- ✅ Added proper validation and feedback messages
- ✅ Fixed database update query with `updated_at` timestamp

### 4. **Cancellation System Fixed**
- ✅ Fixed cancellation request creation
- ✅ Added proper ticket restoration to events
- ✅ Fixed admin approval/rejection workflow

---

## 📋 Deployment Steps

### Step 1: Database Setup

#### Option A: Fresh Installation
```bash
# Import the complete schema
mysql -u root -p < database/schema_final.sql
```

#### Option B: Existing Database (Migration)
```bash
# Run migration to add missing columns
mysql -u root -p college_events < database/migration_add_team_columns.sql
```

### Step 2: Configuration

Edit `config/config.php` and update:

```php
// 1. App URL (CRITICAL)
define('APP_URL', 'https://yourdomain.com');

// 2. Razorpay Keys (Get from https://dashboard.razorpay.com/)
define('RAZORPAY_KEY_ID', 'rzp_live_XXXXXXXXXX');
define('RAZORPAY_KEY_SECRET', 'YOUR_SECRET_KEY');
define('RAZORPAY_WEBHOOK_SECRET', 'YOUR_WEBHOOK_SECRET');

// 3. MSG91 Configuration (Get from https://msg91.com/user/api)
define('MSG91_API_KEY', 'YOUR_MSG91_API_KEY');
define('MSG91_SENDER_ID', 'EVENTP'); // Must be 6 chars, approved by MSG91

// 4. Email Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USER', 'your_email@gmail.com');
define('SMTP_PASS', 'your_app_password'); // Use App Password, not regular password

// 5. Environment
define('APP_ENV', 'production'); // Change from 'development'
```

### Step 3: File Permissions

```bash
# Make uploads directory writable
chmod 755 uploads/
chmod 755 uploads/receipts/
chmod 755 uploads/qrcodes/
chmod 755 logs/

# Secure config files
chmod 644 config/config.php
chmod 644 config/database.php
```

### Step 4: Test All Functions

#### A. Test OTP System
1. Go to homepage and click "Book Tickets"
2. Fill in booking details
3. Click "Send OTP"
4. **Expected:** OTP should be sent via SMS (MSG91) or email
5. Enter OTP and verify
6. **Expected:** Should proceed to payment step

**If OTP fails:**
- Check `logs/error.log` for errors
- Verify MSG91 API key is correct
- Check phone number format (should be +91XXXXXXXXXX)
- Test with development mode: Set `APP_ENV` to 'development' in config.php

#### B. Test Support Tickets
1. Go to `support.php`
2. Fill in support form and submit
3. **Expected:** Ticket ID should be generated (e.g., ST20260505XXXX)
4. Login to admin panel: `admin/login.php` (username: `admin`, password: `password`)
5. Go to "Support" section
6. **Expected:** Your ticket should appear
7. Add admin reply and change status
8. Click "Save Reply"
9. **Expected:** "✅ Ticket updated successfully" message

**If support tickets don't update:**
- Check database connection in `config/database.php`
- Verify `support_tickets` table exists
- Check browser console for JavaScript errors

#### C. Test Ticket Cancellation
1. Login as user
2. Go to "My Bookings"
3. Click "Cancel Ticket" on any booking
4. Fill cancellation form and submit
5. **Expected:** Request ID generated (e.g., CR20260505XXXX)
6. Login to admin panel
7. Go to "Cancellations" section
8. **Expected:** Request appears in "Pending" tab
9. Enter refund amount and click "Approve"
10. **Expected:** Tickets restored to event, booking marked as CANCELLED

**If cancellation fails:**
- Check if `cancellation_requests` table exists
- Verify booking_id is correct
- Check `logs/error.log` for database errors

#### D. Test Payment Flow
1. Complete OTP verification
2. Click "Pay Now" button
3. **Expected:** Razorpay payment modal opens
4. Complete test payment (use Razorpay test cards)
5. **Expected:** Redirected to confirmation page with booking ID

**Test Cards (Razorpay Test Mode):**
- Success: `4111 1111 1111 1111`
- CVV: Any 3 digits
- Expiry: Any future date

---

## 🔍 Common Issues & Fixes

### Issue 1: OTP Not Sending

**Symptoms:** "Failed to send OTP" error

**Solutions:**
1. **Check MSG91 Configuration:**
   ```bash
   # Test MSG91 API directly
   curl -X GET "https://api.msg91.com/api/sendhttp.php?authkey=YOUR_KEY&mobiles=919876543210&message=Test&sender=EVENTP&route=4"
   ```

2. **Verify Sender ID:**
   - Must be exactly 6 characters
   - Must be approved by MSG91 for transactional route
   - Login to MSG91 dashboard → Sender IDs

3. **Check Phone Format:**
   - Should be: `+919876543210` or `919876543210`
   - Remove spaces, dashes, parentheses

4. **Enable Development Mode:**
   ```php
   // In config/config.php
   define('APP_ENV', 'development');
   ```
   - OTP will be shown in response for testing

### Issue 2: Support Tickets Not Updating

**Symptoms:** Admin clicks "Save Reply" but nothing happens

**Solutions:**
1. **Check Database Connection:**
   ```php
   // Test in admin/support-tickets.php
   var_dump($conn->error); // After UPDATE query
   ```

2. **Verify Table Structure:**
   ```sql
   DESCRIBE support_tickets;
   -- Should have: ticket_id, status, admin_reply, updated_at
   ```

3. **Check Browser Console:**
   - Open Developer Tools (F12)
   - Look for JavaScript errors
   - Check Network tab for failed requests

### Issue 3: Cancellation Not Working

**Symptoms:** "Booking not found" or tickets not restored

**Solutions:**
1. **Run Migration:**
   ```bash
   mysql -u root -p college_events < database/migration_add_team_columns.sql
   ```

2. **Check Booking Status:**
   ```sql
   SELECT booking_id, status FROM confirmed_bookings WHERE booking_id = 'YOUR_BOOKING_ID';
   -- Status should be 'PAID' or 'CONFIRMED', not 'CANCELLED'
   ```

3. **Verify Event Tickets:**
   ```sql
   SELECT id, name, available_tickets FROM events WHERE id = YOUR_EVENT_ID;
   -- Check if tickets are being restored after approval
   ```

### Issue 4: Payment Fails

**Symptoms:** Razorpay modal doesn't open or payment fails

**Solutions:**
1. **Check Razorpay Keys:**
   - Test mode: `rzp_test_XXXXXXXXXX`
   - Live mode: `rzp_live_XXXXXXXXXX`
   - Don't mix test and live keys

2. **Verify Webhook:**
   ```
   Razorpay Dashboard → Settings → Webhooks
   URL: https://yourdomain.com/api/webhook.php
   Secret: (copy to config.php)
   Events: payment.captured, payment.failed
   ```

3. **Check Browser Console:**
   - Error: "Razorpay is not defined" → Script not loaded
   - Solution: Check internet connection, CDN access

---

## 🧪 Testing Checklist

### User Flow Testing
- [ ] User registration works
- [ ] User login works
- [ ] Event listing displays correctly
- [ ] Booking form validation works
- [ ] OTP is sent and received
- [ ] OTP verification works
- [ ] Payment modal opens
- [ ] Payment completes successfully
- [ ] Confirmation email sent
- [ ] Booking appears in "My Bookings"
- [ ] Receipt can be downloaded
- [ ] Ticket cancellation works
- [ ] Support ticket submission works

### Admin Flow Testing
- [ ] Admin login works
- [ ] Dashboard shows correct stats
- [ ] Events can be created/edited
- [ ] Bookings list displays correctly
- [ ] Cancellation requests appear
- [ ] Cancellation approval works
- [ ] Tickets are restored to event
- [ ] Support tickets appear
- [ ] Support ticket replies work
- [ ] Status changes are saved

### Security Testing
- [ ] SQL injection protection (use prepared statements)
- [ ] XSS protection (htmlspecialchars on output)
- [ ] CSRF protection (session validation)
- [ ] Password hashing (bcrypt)
- [ ] Session timeout works
- [ ] Admin routes protected
- [ ] File upload validation
- [ ] Rate limiting works

---

## 📊 Monitoring & Logs

### Check Logs Regularly
```bash
# Application logs
tail -f logs/error.log

# Apache/Nginx logs
tail -f /var/log/apache2/error.log
tail -f /var/log/nginx/error.log

# MySQL logs
tail -f /var/log/mysql/error.log
```

### Database Monitoring
```sql
-- Check pending bookings
SELECT COUNT(*) FROM pending_bookings WHERE status = 'RESERVED';

-- Check failed payments
SELECT COUNT(*) FROM payments WHERE status = 'FAILED';

-- Check support tickets
SELECT status, COUNT(*) FROM support_tickets GROUP BY status;

-- Check cancellation requests
SELECT status, COUNT(*) FROM cancellation_requests GROUP BY status;
```

---

## 🔐 Security Hardening

### 1. Update Default Admin Password
```sql
-- Generate new password hash
-- In PHP: password_hash('your_new_password', PASSWORD_BCRYPT);

UPDATE admins SET password_hash = '$2y$10$NEW_HASH_HERE' WHERE username = 'admin';
```

### 2. Secure .htaccess Files
Already included in:
- `/.htaccess` - Blocks direct access to config files
- `/uploads/receipts/.htaccess` - Allows only PDF downloads
- `/admin/.htaccess` - Restricts admin access

### 3. Enable HTTPS
```apache
# In .htaccess
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 4. Database Security
```sql
-- Create dedicated database user (don't use root)
CREATE USER 'eventpass_user'@'localhost' IDENTIFIED BY 'strong_password_here';
GRANT SELECT, INSERT, UPDATE, DELETE ON college_events.* TO 'eventpass_user'@'localhost';
FLUSH PRIVILEGES;
```

Update `config/database.php`:
```php
define('DB_USER', 'eventpass_user');
define('DB_PASS', 'strong_password_here');
```

---

## 📞 Support & Troubleshooting

### If you encounter issues:

1. **Check error logs first:**
   ```bash
   tail -n 50 logs/error.log
   ```

2. **Enable debug mode temporarily:**
   ```php
   // In config/config.php
   define('APP_ENV', 'development');
   error_reporting(E_ALL);
   ini_set('display_errors', 1);
   ```

3. **Test database connection:**
   ```php
   // Create test.php in root
   <?php
   require_once 'config/database.php';
   try {
       $conn = getDBConnection();
       echo "✅ Database connected successfully!";
   } catch (Exception $e) {
       echo "❌ Database error: " . $e->getMessage();
   }
   ```

4. **Verify file permissions:**
   ```bash
   ls -la uploads/
   ls -la logs/
   ```

---

## ✅ Final Deployment Checklist

Before going live:

- [ ] Database imported/migrated successfully
- [ ] All config values updated (APP_URL, Razorpay, MSG91, SMTP)
- [ ] APP_ENV set to 'production'
- [ ] Default admin password changed
- [ ] File permissions set correctly
- [ ] HTTPS enabled
- [ ] All functions tested (OTP, payment, cancellation, support)
- [ ] Error logs checked and cleared
- [ ] Backup database created
- [ ] Webhook configured in Razorpay dashboard
- [ ] Email sending tested
- [ ] SMS sending tested

---

## 🎉 You're Ready to Deploy!

All critical issues have been fixed:
- ✅ OTP system working
- ✅ Support tickets updating properly
- ✅ Cancellation system functional
- ✅ Database schema complete

**Need help?** Check the logs first, then review this checklist.

**Good luck with your deployment! 🚀**
