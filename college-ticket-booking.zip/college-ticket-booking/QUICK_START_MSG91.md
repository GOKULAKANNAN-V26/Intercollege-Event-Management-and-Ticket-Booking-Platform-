# 🚀 Quick Start - MSG91 OTP Fix

## Problem
❌ Users not receiving OTP via SMS

## Root Causes
1. Backend was using **Twilio** (not MSG91)
2. Twilio credentials were **placeholder values**
3. Development mode had a **bypass** that prevented actual SMS sending

## Solution Applied
✅ Backend updated to use **MSG91 API** for SMS

## What You Need To Do (5 Minutes)

### 1️⃣ Get MSG91 API Key
- Go to https://www.msg91.com/user/api
- Copy your **Auth Key** (API Key)

### 2️⃣ Update config/config.php
Find this section and fill in your details:
```php
define('MSG91_API_KEY', 'PASTE_YOUR_API_KEY_HERE');  // ← Add your key
define('MSG91_SENDER_ID', 'EVENTAPP');              // ← Keep or change
```

### 3️⃣ Request Sender ID Approval
- Go to MSG91 Dashboard → Settings → Sender IDs
- Submit your sender ID (e.g., "EVENTAPP") for approval
- Wait for approval (usually 2-4 hours in India)

### 4️⃣ Test It
- Keep `define('APP_ENV', 'development');` while testing
- Try booking an event
- You should see SMS delivery confirmation in logs

### 5️⃣ Go Live
- Change to `define('APP_ENV', 'production');`
- Users will now receive real SMS OTP!

---

## Files Modified
- ✏️ `config/config.php` - Updated SMS configuration
- ✏️ `includes/OTPService.php` - Replaced Twilio with MSG91

## Files Created (Documentation)
- 📄 `MSG91_SETUP_GUIDE.md` - Complete setup guide
- 📄 `OTP_INTEGRATION_FIX_SUMMARY.md` - Before/After comparison

---

## Troubleshooting

**Q: Users still not getting SMS?**
- ✅ Check if MSG91_API_KEY is correctly pasted (no extra spaces)
- ✅ Verify sender ID is approved in MSG91 dashboard
- ✅ Check `logs/error.log` for MSG91 error messages

**Q: How to test without waiting for SMS?**
- Keep development mode on: `define('APP_ENV', 'development');`
- OTP will be shown in browser console

**Q: SMS goes to wrong provider?**
- MSG91 sometimes routes through other operators
- This is normal and controlled by MSG91

---

## API Key Security ⚠️
- Never commit `config/config.php` to public repositories
- In production, use environment variables instead:
  ```php
  define('MSG91_API_KEY', getenv('MSG91_API_KEY'));
  ```

## Need Help?
- MSG91 Docs: https://www.msg91.com/api
- Check logs: `logs/error.log`
- Test manually: Use curl command in `MSG91_SETUP_GUIDE.md`
