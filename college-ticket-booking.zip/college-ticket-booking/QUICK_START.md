# 🚀 Quick Start Guide - VelTech EventPass

## ⚡ 5-Minute Setup

### Step 1: Import Database (1 minute)

```bash
# Fresh installation
mysql -u root -p < database/schema_final.sql

# OR if you have existing database
mysql -u root -p college_events < database/migration_add_team_columns.sql
```

### Step 2: Update Config (2 minutes)

Edit `config/config.php`:

```php
// Line 7: Your domain
define('APP_URL', 'https://yourdomain.com');

// Line 11-13: Razorpay keys
define('RAZORPAY_KEY_ID', 'rzp_live_XXXXXXXXXX');
define('RAZORPAY_KEY_SECRET', 'YOUR_SECRET_KEY');

// Line 21-23: MSG91 for OTP
define('MSG91_API_KEY', 'YOUR_MSG91_API_KEY');
define('MSG91_SENDER_ID', 'EVENTP'); // 6 chars, approved by MSG91

// Line 16-19: Email
define('SMTP_USER', 'your_email@gmail.com');
define('SMTP_PASS', 'your_app_password');

// Line 5: Environment
define('APP_ENV', 'production'); // Change from 'development'
```

### Step 3: Test System (1 minute)

Visit: `http://yourdomain.com/test_system.php`

✅ All tests should pass!

### Step 4: Test Functions (1 minute)

1. **Test OTP:** Book a ticket → Verify OTP works
2. **Test Support:** Submit ticket → Admin can reply
3. **Test Cancel:** Cancel booking → Admin can approve

### Step 5: Go Live!

```bash
# Delete test files
rm test_system.php test_msg91.php temp_msg91_test.php

# Change admin password
mysql -u root -p college_events
UPDATE admins SET password_hash = '$2y$10$NEW_HASH' WHERE username = 'admin';
```

---

## 🎯 What Was Fixed

### ✅ OTP System
- Fixed incomplete `verifyOTP()` function
- Now works with MSG91, Firebase, and manual entry

### ✅ Support Tickets
- Admin can now update tickets properly
- Shows success/error messages
- Updates database correctly

### ✅ Ticket Cancellation
- Added missing database columns
- Full workflow now functional
- Tickets restore to events after approval

---

## 📁 Important Files

| File | Purpose |
|------|---------|
| `FIXES_APPLIED.md` | Detailed list of all fixes |
| `DEPLOYMENT_CHECKLIST.md` | Complete deployment guide |
| `test_system.php` | Automated health check |
| `database/schema_final.sql` | Fresh database schema |
| `database/migration_add_team_columns.sql` | Update existing database |

---

## 🆘 Quick Troubleshooting

### OTP not sending?
```bash
# Check logs
tail -f logs/error.log

# Test in development mode
# In config.php: define('APP_ENV', 'development');
```

### Support tickets not updating?
- Check database connection in `config/database.php`
- Verify `support_tickets` table exists
- Check browser console for errors

### Cancellation failing?
```bash
# Run migration first
mysql -u root -p college_events < database/migration_add_team_columns.sql
```

---

## 🎉 You're Ready!

**All critical issues fixed. System is production-ready.**

For detailed instructions, see:
- `DEPLOYMENT_CHECKLIST.md` - Full deployment guide
- `FIXES_APPLIED.md` - What was fixed and why

**Need help?** Check the logs first: `logs/error.log`

---

**Default Admin Login:**
- URL: `http://yourdomain.com/admin/login.php`
- Username: `admin`
- Password: `password`

⚠️ **Change this password immediately after first login!**
